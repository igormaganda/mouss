export const legalContent = {
  mentionsLegales: {
    title: "Mentions Légales",
    sections: [
      {
        heading: "Éditeur du site",
        content: `Le site aquabion-mag.com est édité par :\n\nNFD sàrl - AQUABION\nSociété à responsabilité limitée\nN° TVA : FR23517423935\nSiège social : 100 route de Nîmes, 30132 Caissargues, France\nTéléphone : +33 9 77 55 03 59\nEmail : contact@aquabion-mag.com\nSite : https://aquabion-mag.com\n\nDirecteur de la publication : Cyrille Gerhardt`,
      },
      {
        heading: "Hébergement",
        content: `Le site est hébergé par :\n[ Nom de l'hébergeur ]\n[ Adresse de l'hébergeur ]\n[ Téléphone de l'hébergeur ]`,
      },
      {
        heading: "Propriété intellectuelle",
        content: `L'ensemble des contenus présents sur le site aquabion-mag.com (textes, images, vidéos, logos, icônes, graphismes, sons, logiciels, etc.) est la propriété exclusive de NFD sàrl - AQUABION ou de ses partenaires et est protégé par les lois françaises et internationales relatives à la propriété intellectuelle.\n\nToute reproduction, représentation, modification, publication, adaptation, totale ou partielle, de l'un quelconque de ces éléments, quel que soit le moyen ou le procédé utilisé, est interdite sans l'autorisation écrite préalable de NFD sàrl - AQUABION.\n\nAQUABION® est une marque déposée. Toute utilisation non autorisée de la marque constitue une contrefaçon sanctionnée par le Code de la propriété intellectuelle.`,
      },
      {
        heading: "Responsabilité",
        content: `NFD sàrl - AQUABION s'efforce de fournir des informations aussi précises que possible sur le site. Toutefois, elle ne pourra être tenue responsable des omissions, des inexactitudes ou des carences dans la mise à jour de ces informations, qu'elles soient de son fait ou du fait de tiers.\n\nLes informations et conseils diffusés sur ce site le sont à titre indicatif et ne sauraient se substituer à un diagnostic professionnel. AQUABION® ne saurait être tenu responsable de l'utilisation qui pourrait être faite de ces informations.\n\nToute utilisation non autorisée du site relève de la seule responsabilité de l'utilisateur.`,
      },
      {
        heading: "Liens hypertextes",
        content: `Le site peut contenir des liens hypertextes vers d'autres sites internet. NFD sàrl - AQUABION ne dispose d'aucun moyen de contrôle du contenu de ces sites tiers et n'assume aucune responsabilité quant à leur contenu.`,
      },
      {
        heading: "Droit applicable et juridiction",
        content: `Les présentes mentions légales sont régies par le droit français. En cas de litige, les tribunaux français compétents seront seuls compétents, sous réserve des dispositions applicables en matière de compétence juridictionnelle.`,
      },
      {
        heading: "Contact",
        content: `Pour toute question relative aux présentes mentions légales, vous pouvez nous contacter :\nPar email : contact@aquabion-mag.com\nPar téléphone : +33 9 77 55 03 59\nPar courrier : NFD sàrl - AQUABION, 100 route de Nîmes, 30132 Caissargues, France`,
      },
    ],
  },
  politiqueConfidentialite: {
    title: "Politique de Confidentialité",
    lastUpdated: "1er janvier 2025",
    sections: [
      {
        heading: "Introduction",
        content: `NFD sàrl - AQUABION (ci-après "nous", "notre" ou "AQUABION") s'engage à protéger la vie privée de ses utilisateurs conformément au Règlement Général sur la Protection des Données (RGPD - Règlement UE 2016/679) et à la loi Informatique et Libertés du 6 janvier 1978 modifiée.\n\nLa présente politique de confidentialité a pour objectif d'informer les utilisateurs du site aquabion-mag.com sur la manière dont nous collectons, utilisons, stockons et protégeons leurs données personnelles.`,
      },
      {
        heading: "Responsable du traitement",
        content: `Le responsable du traitement des données personnelles est :\n\nNFD sàrl - AQUABION\n100 route de Nîmes, 30132 Caissargues, France\nEmail : contact@aquabion-mag.com\nTéléphone : +33 9 77 55 03 59\nN° TVA : FR23517423935`,
      },
      {
        heading: "Données collectées",
        content: `Nous pouvons collecter les données personnelles suivantes :\n\n1. Données fournies volontairement :\n- Nom et prénom\n- Adresse email\n- Numéro de téléphone\n- Adresse postale\n- Informations relatives à votre demande (simulateur, devis)\n\n2. Données collectées automatiquement :\n- Adresse IP\n- Type et version du navigateur\n- Pages visitées et durée de visite\n- Source de trafic\n- Données de cookies (voir section dédiée)\n\n3. Données de contact via formulaires :\n- Messages envoyés via le formulaire de contact\n- Demandes de devis`,
      },
      {
        heading: "Finalités du traitement",
        content: `Vos données personnelles sont traitées pour les finalités suivantes :\n\n- Répondre à vos demandes de contact et de devis\n- Vous fournir les services et informations demandés\n- Gérer la relation client\n- Améliorer notre site et nos services\n- Vous envoyer des communications commerciales (avec votre consentement)\n- Respecter nos obligations légales\n- Mesurer l'audience de notre site (statistiques anonymisées)`,
      },
      {
        heading: "Base légale du traitement",
        content: `Le traitement de vos données repose sur :\n\n- Votre consentement (art. 6.1.a du RGPD) pour les cookies non essentiels et les communications commerciales\n- L'exécution d'un contrat ou de mesures précontractuelles (art. 6.1.b du RGPD)\n- Notre intérêt légitime (art. 6.1.f du RGPD) pour l'amélioration de nos services et les statistiques anonymisées\n- Nos obligations légales (art. 6.1.c du RGPD)`,
      },
      {
        heading: "Durée de conservation",
        content: `Vos données personnelles sont conservées :\n\n- Pour la durée nécessaire à la finalité pour laquelle elles ont été collectées\n- Pendant 3 ans à compter du dernier contact avec vous (prospection)\n- Pendant 5 ans à compter de la fin de la relation contractuelle (données contractuelles)\n- Pendant la durée légale requise pour les données comptables (10 ans)\n- Les cookies sont conservés selon leur durée de validité (voir politique cookies)`,
      },
      {
        heading: "Destinataires des données",
        content: `Vos données sont destinées à :\n\n- NFD sàrl - AQUABION et ses employés habilités\n- Nos prestataires techniques (hébergeur, outils d'analyse)\n- Les autorités compétentes en cas d'obligation légale\n\nNous ne vendons pas et ne transférons pas vos données personnelles à des tiers à des fins commerciales.`,
      },
      {
        heading: "Vos droits",
        content: `Conformément au RGPD, vous disposez des droits suivants :\n\n- Droit d'accès (art. 15) : obtenir la confirmation que vos données sont traitées et en recevoir une copie\n- Droit de rectification (art. 16) : corriger des données inexactes\n- Droit à l'effacement (art. 17) : demander la suppression de vos données\n- Droit à la limitation (art. 18) : limiter le traitement de vos données\n- Droit à la portabilité (art. 20) : recevoir vos données dans un format structuré\n- Droit d'opposition (art. 21) : vous opposer au traitement de vos données\n- Droit de retirer votre consentement à tout moment\n\nPour exercer vos droits, contactez-nous à : dpo@aquabion-mag.com\n\nVous pouvez également introduire une réclamation auprès de la CNIL : www.cnil.fr`,
      },
      {
        heading: "Sécurité des données",
        content: `Nous mettons en œuvre des mesures techniques et organisationnelles appropriées pour protéger vos données personnelles contre tout accès non autorisé, toute modification, divulgation ou destruction.\n\nCes mesures incluent :\n- Chiffrement des données sensibles\n- Contrôle d'accès restreint\n- Sauvegardes régulières\n- Mises à jour de sécurité\n- Sensibilisation de nos équipes`,
      },
      {
        heading: "Modifications",
        content: `Nous nous réservons le droit de modifier la présente politique de confidentialité à tout moment. Les modifications seront publiées sur cette page avec la date de mise à jour. Nous vous invitons à consulter régulièrement cette page.`,
      },
      {
        heading: "Contact DPO",
        content: `Pour toute question relative à la protection de vos données personnelles, vous pouvez contacter notre Délégué à la Protection des Données :\n\nEmail : dpo@aquabion-mag.com\nCourrier : NFD sàrl - AQUABION, À l'attention du DPO, 100 route de Nîmes, 30132 Caissargues, France`,
      },
    ],
  },
  cgv: {
    title: "Conditions Générales de Vente",
    lastUpdated: "1er janvier 2025",
    sections: [
      {
        heading: "Objet",
        content: `Les présentes Conditions Générales de Vente (CGV) régissent les ventes de produits et services AQUABION® effectuées par NFD sàrl - AQUABION (ci-après le "Vendeur") à ses clients (ci-après le "Client"), qu'ils soient particuliers ou professionnels.\n\nToute commande implique l'acceptation sans réserve des présentes CGV.`,
      },
      {
        heading: "Produits",
        content: `Les produits AQUABION® sont des systèmes de traitement de l'eau par galvanisation brevetée. Les caractéristiques techniques, les dimensions et les performances des produits sont décrites sur notre site et dans nos documentation techniques.\n\nLe Vendeur se réserve le droit de modifier les caractéristiques de ses produits pour des raisons techniques. Ces modifications n'entraîneront pas de modification substantielle des performances annoncées.\n\nLes photographies et illustrations ne sont pas contractuelles.`,
      },
      {
        heading: "Commande",
        content: `Le Client peut passer commande :\n- Via notre site internet\n- Par email à contact@aquabion-mag.com\n- Par téléphone au +33 9 77 55 03 59\n\nToute commande passée par le Client constitue un contrat de vente entre le Client et le Vendeur.\n\nLe Vendeur se réserve le droit de refuser ou d'annuler toute commande en cas de litige antérieur ou d'information erronée.`,
      },
      {
        heading: "Prix",
        content: `Les prix de nos produits sont indiqués en euros (€) toutes taxes comprises (TTC) pour les particuliers et hors taxes (HT) pour les professionnels.\n\nLes prix peuvent être modifiés à tout moment. Le prix applicable est celui en vigueur au moment de la validation de la commande.\n\nLes frais de livraison sont calculés en fonction de la destination et sont précisés lors de la commande.`,
      },
      {
        heading: "Paiement",
        content: `Le paiement s'effectue :\n- Par carte bancaire\n- Par virement bancaire\n- Par chèque (pour les professionnels)\n\nPour les commandes supérieures à un certain montant, un acompte peut être demandé.\n\nLa commande est confirmée après réception du paiement intégral ou de l'acompte requis.`,
      },
      {
        heading: "Livraison",
        content: `Les délais de livraison sont donnés à titre indicatif et peuvent varier en fonction de la destination et du mode de livraison choisi.\n\nLe Vendeur s'engage à expédier les commandes dans un délai maximum de 30 jours à compter de la réception du paiement.\n\nLe transfert des risques s'effectue au moment de la remise du produit au transporteur.`,
      },
      {
        heading: "Droit de rétractation (Particuliers)",
        content: `Conformément à l'article L221-18 du Code de la consommation, le Client dispose d'un délai de 14 jours calendaires à compter de la réception du produit pour exercer son droit de rétractation, sans avoir à justifier de motif ni à payer de pénalité.\n\nLe Client doit notifier sa décision de rétractation par email à contact@aquabion-mag.com.\n\nLe produit doit être retourné dans son emballage d'origine, en parfait état, accompagné de tous les accessoires et documents.\n\nLes frais de retour sont à la charge du Client.`,
      },
      {
        heading: "Garantie",
        content: `Les produits AQUABION® bénéficient d'une garantie constructeur de :\n- 5 ans pour une utilisation résidentielle\n- 3 ans pour une utilisation professionnelle/industrielle\n\nLa garantie couvre les défauts de fabrication et de matière. Elle ne couvre pas les dommages résultant d'une mauvaise installation, d'une utilisation non conforme ou de l'usure normale.\n\nLa garantie est conditionnée à l'installation par un professionnel agréé AQUABION®.`,
      },
      {
        heading: "Installation",
        content: `L'installation des produits AQUABION® doit être réalisée par un professionnel qualifié, idéalement un installateur agréé AQUABION®.\n\nUne installation non conforme peut entraîner la perte de la garantie.\n\nLe Vendeur peut mettre à disposition du Client un réseau d'installateurs agréés sur demande.`,
      },
      {
        heading: "Responsabilité",
        content: `Le Vendeur ne saurait être tenu responsable de :\n- L'inadaptation du produit aux besoins spécifiques du Client\n- Les dommages indirects résultant de l'utilisation du produit\n- Le non-respect des conditions d'installation\n\nLa responsabilité totale du Vendeur est limitée au montant de la commande.`,
      },
      {
        heading: "Données personnelles",
        content: `Le traitement des données personnelles est régi par notre Politique de Confidentialité disponible sur notre site.`,
      },
      {
        heading: "Litige",
        content: `En cas de litige, le Client peut recourir à une médiation conventionnelle ou à tout mode alternatif de règlement des différends.\n\nLe droit applicable est le droit français. Les tribunaux français compétents seront seuls compétents pour connaître de tout litige relatif aux présentes CGV.`,
      },
      {
        heading: "Contact",
        content: `Pour toute question relative aux présentes CGV, contactez-nous :\nEmail : contact@aquabion-mag.com\nTéléphone : +33 9 77 55 03 59\nAdresse : NFD sàrl - AQUABION, 100 route de Nîmes, 30132 Caissargues, France`,
      },
    ],
  },
  cookies: {
    title: "Politique de Cookies",
    lastUpdated: "1er janvier 2025",
    sections: [
      {
        heading: "Qu'est-ce qu'un cookie ?",
        content: `Un cookie est un petit fichier texte déposé sur votre terminal (ordinateur, tablette, smartphone) lors de votre visite sur notre site. Il permet au site de mémoriser certaines informations relatives à votre visite pour faciliter la navigation et améliorer l'expérience utilisateur.`,
      },
      {
        heading: "Types de cookies utilisés",
        content: `1. Cookies strictement nécessaires\nCes cookies sont indispensables au bon fonctionnement du site. Ils ne peuvent pas être désactivés.\n\n2. Cookies de mesure d'audience (Google Analytics)\nCes cookies collectent des informations anonymes sur la façon dont les visiteurs utilisent le site. Ils nous permettent d'améliorer nos services.\n\n3. Cookies marketing (Facebook Pixel, Google Ads, Taboola, LinkedIn)\nCes cookies sont utilisés pour vous proposer des publicités pertinentes et mesurer l'efficacité de nos campagnes publicitaires.\n\n4. Cookies de réseaux sociaux\nCes cookies permettent de partager du contenu sur les réseaux sociaux et de suivre l'interaction des utilisateurs avec nos contenus.`,
      },
      {
        heading: "Durée de conservation",
        content: `La durée de vie des cookies varie selon leur finalité :\n- Cookies de session : supprimés à la fermeture du navigateur\n- Cookies persistants : de quelques mois à 2 ans maximum\n\nVous pouvez configurer votre navigateur pour supprimer les cookies automatiquement.`,
      },
      {
        heading: "Vos choix",
        content: `Vous pouvez à tout moment modifier vos préférences en matière de cookies :\n\n- Via le bandeau de consentement affiché lors de votre première visite\n- Dans les paramètres de votre navigateur\n- En nous contactant à dpo@aquabion-mag.com\n\nPour en savoir plus sur la gestion des cookies, consultez l'aide de votre navigateur.`,
      },
      {
        heading: "Base légale",
        content: `Le dépôt de cookies strictement nécessaires ne nécessite pas votre consentement.\nLe dépôt des autres cookies est soumis à votre consentement préalable, conformément à la recommandation CNIL et à l'ePrivacy Directive.`,
      },
    ],
  },
} as const;
