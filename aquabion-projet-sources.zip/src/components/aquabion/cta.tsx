"use client";

import { useState } from "react";
import Image from "next/image";
import { Star, Phone, Mail, MapPin, Send, MessageSquare } from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

const testimonials = [
  {
    quote:
      "Depuis l'installation d'AQUABION®, plus de traces de calcaire sur nos robinetteries. L'eau est plus douce et nos appareils fonctionnent mieux. Vraiment bluffant !",
    name: "Marie D.",
    location: "Montpellier",
  },
  {
    quote:
      "Installation rapide et professionnelle. On remarque la différence au bout de quelques semaines. Les dépôts de calcaire dans la douche ont quasiment disparu.",
    name: "Thomas L.",
    location: "Lyon",
  },
  {
    quote:
      "En tant que plombier, je recommande AQUABION® à tous mes clients. C'est fiable, écologique et ça marche vraiment. Le rapport qualité-prix est excellent.",
    name: "Pierre M.",
    location: "Toulouse",
    badge: "Installateur agréé",
  },
];

function StarRating() {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className="h-4 w-4 fill-amber-400 text-amber-400"
        />
      ))}
    </div>
  );
}

export default function CTA() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setIsSubmitted(true);
    setFormData({ name: "", email: "", phone: "", message: "" });

    setTimeout(() => setIsSubmitted(false), 5000);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <section id="contact">
      {/* ─────────────────────── Testimonials ─────────────────────── */}
      <div className="py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mx-auto mb-8 max-w-2xl text-center md:mb-10">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Ce que disent nos clients
            </h2>
            <p className="mt-4 text-lg text-muted-foreground">
              Des milliers de foyers et professionnels nous font déjà confiance
            </p>
          </div>

          {/* Testimonial Cards - show 1 on mobile, 3 on md+ */}
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {testimonials.map((testimonial, index) => (
              <Card
                key={index}
                className={`group border-border/50 transition-all duration-300 hover:-translate-y-1 hover:border-teal-200 hover:shadow-lg hover:shadow-teal-100/50 dark:hover:border-teal-800 dark:hover:shadow-teal-900/30 ${index > 0 ? 'hidden md:block' : ''}`}
              >
                <CardContent className="flex h-full flex-col gap-4 p-6 sm:p-8">
                  {/* Quote icon */}
                  <MessageSquare className="h-8 w-8 shrink-0 text-teal-500/20" />

                  {/* Quote text */}
                  <p className="flex-1 text-sm leading-relaxed text-muted-foreground sm:text-base">
                    &ldquo;{testimonial.quote}&rdquo;
                  </p>

                  {/* Divider */}
                  <div className="h-px w-full bg-border" />

                  {/* Rating */}
                  <StarRating />

                  {/* Author */}
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-foreground">
                        {testimonial.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {testimonial.location}
                      </p>
                    </div>
                    {testimonial.badge && (
                      <span className="inline-flex items-center rounded-full bg-teal-100 px-3 py-1 text-xs font-medium text-teal-700 dark:bg-teal-950/60 dark:text-teal-300">
                        {testimonial.badge}
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* ─────────────────────── Contact / CTA ─────────────────────── */}
      <div className="relative overflow-hidden py-10 md:py-16">
        {/* Background image with teal gradient overlay */}
        <div className="pointer-events-none absolute inset-0 z-0">
          <Image
            src="https://images.unsplash.com/photo-1559839914-17aae19cec71?auto=format&fit=crop&w=1600&q=80"
            alt=""
            fill
            className="object-cover"
            aria-hidden
          />
          <div className="absolute inset-0 bg-gradient-to-br from-teal-900/95 via-teal-800/90 to-cyan-900/95" />
        </div>

        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-start gap-12 lg:grid-cols-2 lg:gap-16">
            {/* Left: Contact info */}
            <div className="text-white">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Prêt à dire adieu au calcaire ?
              </h2>
              <p className="mt-4 text-lg leading-relaxed text-teal-100/80">
                Contactez-nous pour un devis gratuit et personnalisé
              </p>

              {/* Contact details */}
              <div className="mt-10 space-y-6">
                <div className="flex items-start gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/10 backdrop-blur-sm ring-1 ring-white/20">
                    <Phone className="h-5 w-5 text-teal-200" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-teal-200/70">
                      Téléphone
                    </p>
                    <a
                      href="tel:+33977550359"
                      className="mt-1 text-lg font-semibold transition-colors hover:text-teal-200"
                    >
                      +33 9 77 55 03 59
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/10 backdrop-blur-sm ring-1 ring-white/20">
                    <Mail className="h-5 w-5 text-teal-200" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-teal-200/70">
                      Email
                    </p>
                    <a
                      href="mailto:contact@aquabion-mag.com"
                      className="mt-1 text-lg font-semibold transition-colors hover:text-teal-200"
                    >
                      contact@aquabion-mag.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/10 backdrop-blur-sm ring-1 ring-white/20">
                    <MapPin className="h-5 w-5 text-teal-200" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-teal-200/70">
                      Adresse
                    </p>
                    <p className="mt-1 text-lg font-semibold">
                      100 route de Nîmes
                    </p>
                    <p className="text-sm text-teal-100/70">
                      30132 Caissargues, France
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Contact form */}
            <Card className="border-white/10 bg-white/10 shadow-2xl backdrop-blur-xl">
              <CardHeader className="pb-0">
                <CardTitle className="text-xl font-bold text-white sm:text-2xl">
                  Demande de devis gratuit
                </CardTitle>
                <CardDescription className="text-teal-200/70">
                  Remplissez le formulaire ci-dessous et nous vous répondrons
                  sous 24h
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 sm:p-8">
                {isSubmitted ? (
                  <div className="flex flex-col items-center gap-3 py-8 text-center">
                    <div className="flex h-14 w-14 items-center justify-center rounded-full bg-teal-500/20">
                      <Send className="h-7 w-7 text-teal-300" />
                    </div>
                    <p className="text-lg font-semibold text-white">
                      Demande envoyée avec succès !
                    </p>
                    <p className="text-sm text-teal-200/70">
                      Nous vous recontacterons dans les plus brefs délais.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    {/* Nom complet */}
                    <div className="space-y-2">
                      <Label
                        htmlFor="name"
                        className="text-sm font-medium text-teal-100"
                      >
                        Nom complet
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        placeholder="Votre nom et prénom"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="border-white/20 bg-white/10 text-white placeholder:text-white/40 focus-visible:border-teal-300 focus-visible:ring-teal-300/30"
                      />
                    </div>

                    {/* Email */}
                    <div className="space-y-2">
                      <Label
                        htmlFor="email"
                        className="text-sm font-medium text-teal-100"
                      >
                        Email
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="votre@email.com"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="border-white/20 bg-white/10 text-white placeholder:text-white/40 focus-visible:border-teal-300 focus-visible:ring-teal-300/30"
                      />
                    </div>

                    {/* Téléphone */}
                    <div className="space-y-2">
                      <Label
                        htmlFor="phone"
                        className="text-sm font-medium text-teal-100"
                      >
                        Téléphone
                      </Label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        placeholder="+33 6 00 00 00 00"
                        value={formData.phone}
                        onChange={handleChange}
                        className="border-white/20 bg-white/10 text-white placeholder:text-white/40 focus-visible:border-teal-300 focus-visible:ring-teal-300/30"
                      />
                    </div>

                    {/* Message */}
                    <div className="space-y-2">
                      <Label
                        htmlFor="message"
                        className="text-sm font-medium text-teal-100"
                      >
                        Message
                      </Label>
                      <Textarea
                        id="message"
                        name="message"
                        placeholder="Décrivez votre besoin (type de logement, consommation d'eau, problème rencontré...)"
                        rows={4}
                        required
                        value={formData.message}
                        onChange={handleChange}
                        className="border-white/20 bg-white/10 text-white placeholder:text-white/40 focus-visible:border-teal-300 focus-visible:ring-teal-300/30"
                      />
                    </div>

                    {/* Submit */}
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      size="lg"
                      className="w-full bg-white text-teal-800 font-semibold shadow-lg transition-all hover:bg-teal-50 hover:shadow-xl"
                    >
                      {isSubmitting ? (
                        <span className="flex items-center gap-2">
                          <span className="h-4 w-4 animate-spin rounded-full border-2 border-teal-800/30 border-t-teal-800" />
                          Envoi en cours...
                        </span>
                      ) : (
                        <span className="flex items-center gap-2">
                          <Send className="h-4 w-4" />
                          Envoyer ma demande
                        </span>
                      )}
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
