"use client";

import Image from "next/image";
import { Droplets, Sparkles, RefreshCw, ShieldCheck, Award } from "lucide-react";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const steps = [
  {
    number: 1,
    icon: Droplets,
    title: "Eau traverse le noyau galvanique",
    description:
      "L'eau passe à travers le corps galvanique en alliage de zinc.",
  },
  {
    number: 2,
    icon: Sparkles,
    title: "Réaction électrochimique",
    description:
      "Une réaction galvanique naturelle libère des ions zinc qui modifient les cristaux de calcaire.",
  },
  {
    number: 3,
    icon: RefreshCw,
    title: "Transformation du calcaire",
    description:
      "Le calcaire (calcite) se transforme en aragonite, une forme non incrustante.",
  },
  {
    number: 4,
    icon: ShieldCheck,
    title: "Eau protégée",
    description:
      "L'eau conserve ses minéraux sans former de dépôts dans vos canalisations et appareils.",
  },
];

export default function Technology() {
  return (
    <section
      id="technologie"
      className="relative overflow-hidden py-12 md:py-16">
      {/* Subtle background texture */}
      <div className="pointer-events-none absolute inset-0 z-0">
        <Image
          src="https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?auto=format&fit=crop&w=800&q=80"
          alt=""
          fill
          className="object-cover opacity-[0.04]"
          aria-hidden
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="mb-8 max-w-2xl md:mb-10">
          <Badge
            variant="secondary"
            className="mb-4 border-teal-200 bg-teal-50 text-teal-700 dark:border-teal-800 dark:bg-teal-950/50 dark:text-teal-300"
          >
            Technologie brevetée
          </Badge>
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Comment fonctionne AQUABION® ?
          </h2>
          <p className="text-lg leading-relaxed text-muted-foreground">
            AQUABION® utilise une technologie galvanique brevetée
            unique qui modifie la structure cristalline du calcaire, empêchant
            son dépôt sans modifier la composition chimique de l&apos;eau.
          </p>
        </div>

        {/* Two-part layout */}
        <div className="grid items-start gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Left: Steps */}
          <div className="space-y-5">
            {steps.map((step) => {
              const Icon = step.icon;
              return (
                <Card
                  key={step.number}
                  className="group border border-border/60 bg-card/80 backdrop-blur-sm transition-all duration-300 hover:border-teal-300/60 hover:shadow-md"
                >
                  <CardContent className="flex gap-4 p-4 sm:p-5">
                    {/* Step number + icon */}
                    <div className="flex flex-shrink-0 items-center justify-center gap-2">
                      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-50 text-teal-600 ring-1 ring-teal-100 transition-colors group-hover:bg-teal-100 group-hover:ring-teal-200 dark:bg-teal-950/60 dark:text-teal-400 dark:ring-teal-800 dark:group-hover:bg-teal-900/60">
                        <Icon className="h-5 w-5" />
                      </div>
                      <span className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-teal-600 text-xs font-bold text-white dark:bg-teal-500">
                        {step.number}
                      </span>
                    </div>

                    {/* Text */}
                    <div className="min-w-0 pt-1">
                      <h3 className="mb-1 text-sm font-semibold leading-snug text-foreground sm:text-base">
                        {step.title}
                      </h3>
                      <p className="text-sm leading-relaxed text-muted-foreground">
                        {step.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            {/* Feature highlight box */}
            <div className="mt-8 flex items-start gap-3 rounded-xl border border-teal-200 bg-gradient-to-r from-teal-50 to-cyan-50 p-4 dark:border-teal-800 dark:from-teal-950/40 dark:to-cyan-950/40">
              <Award className="mt-0.5 h-5 w-5 flex-shrink-0 text-teal-600 dark:text-teal-400" />
              <p className="text-sm font-medium leading-relaxed text-teal-800 dark:text-teal-300">
                Breveté depuis 2002, fabriqué en Allemagne, testé
                et certifié par des laboratoires indépendants
              </p>
            </div>
          </div>

          {/* Right: Image - hidden on mobile for performance */}
          <div className="relative hidden lg:flex lg:sticky lg:top-28 items-start">
            <div className="relative h-[710px] w-full max-w-[676px] overflow-hidden rounded-2xl shadow-lg ring-1 ring-border/50">
              <div className="absolute inset-x-0 -top-[75px] bottom-0">
                <Image
                  src="https://images.pexels.com/photos/19980252/pexels-photo-19980252.jpeg?auto=compress&cs=tinysrgb&w=1600"
                  alt="Système AQUABION® - traitement anti-calcaire par galvanisation"
                  fill
                  className="object-cover object-top transition-transform duration-700 hover:scale-[1.02]"
                  sizes="50vw"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
