"use client";

import {
  Leaf,
  PiggyBank,
  Zap,
  Settings,
  Heart,
  Shield,
  type LucideIcon,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface Benefit {
  title: string;
  description: string;
  icon: LucideIcon;
}

const benefits: Benefit[] = [
  {
    title: "Écologique",
    description:
      "AQUABION® respecte l'environnement. Aucun rejet dans les eaux usées, aucun produit chimique.",
    icon: Leaf,
  },
  {
    title: "Économique",
    description:
      "Protégez vos appareils et réduisez votre facture d'énergie grâce à un entretien réduit.",
    icon: PiggyBank,
  },
  {
    title: "Efficace",
    description:
      "La technologie galvanique brevetée empêche la formation de calcaire et dissout les incrustations existantes.",
    icon: Zap,
  },
  {
    title: "Sans entretien",
    description:
      "Aucun sel à recharger, aucun réglage, aucun entretien. Installez et oubliez.",
    icon: Settings,
  },
  {
    title: "Santé",
    description:
      "Contrairement aux adoucisseurs, AQUABION® préserve le calcium et le magnésium essentiels à la santé.",
    icon: Heart,
  },
  {
    title: "Garantie",
    description:
      "Fabriqué en Allemagne avec des matériaux de qualité, AQUABION® bénéficie d'une garantie de 5 ans.",
    icon: Shield,
  },
];

export default function Benefits() {
  return (
    <section id="avantages" className="py-12 md:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto mb-8 max-w-2xl text-center md:mb-10">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Pourquoi choisir AQUABION® ?
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            <span className="whitespace-nowrap">Une technologie unique aux multiples bénéfices pour votre habitat et votre bien-être</span>
          </p>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {benefits.map((benefit) => {
            const Icon = benefit.icon;
            return (
              <Card
                key={benefit.title}
                className="group border-border/50 transition-all duration-300 hover:-translate-y-1 hover:border-teal-200 hover:shadow-lg hover:shadow-teal-100/50"
              >
                <CardContent className="flex flex-col items-start gap-4 pt-6">
                  {/* Icon */}
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-teal-100 text-teal-700 transition-colors duration-300 group-hover:bg-teal-600 group-hover:text-white">
                    <Icon className="h-6 w-6" />
                  </div>

                  {/* Text */}
                  <div>
                    <h3 className="text-lg font-semibold">{benefit.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                      {benefit.description}
                    </p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
