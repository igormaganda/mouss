'use client';

import { useState, useCallback } from 'react';
import { Cookie, X, Settings, ShieldCheck, BarChart3, Megaphone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';

const CONSENT_KEY = 'aquabion_cookie_consent';

interface CookiePreferences {
  necessary: boolean;
  analytics: boolean;
  marketing: boolean;
}

const defaultPreferences: CookiePreferences = {
  necessary: true,
  analytics: false,
  marketing: false,
};

const ALL_ACCEPTED: CookiePreferences = {
  necessary: true,
  analytics: true,
  marketing: true,
};

function readConsentFromStorage(): CookiePreferences | null {
  if (typeof window === 'undefined') return null;
  try {
    const stored = localStorage.getItem(CONSENT_KEY);
    if (stored) return JSON.parse(stored) as CookiePreferences;
  } catch {
    // ignore
  }
  return null;
}

function saveConsent(prefs: CookiePreferences): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(CONSENT_KEY, JSON.stringify(prefs));
    const expires = new Date();
    expires.setFullYear(expires.getFullYear() + 1);
    document.cookie = `${CONSENT_KEY}=accepted;expires=${expires.toUTCString()};path=/;SameSite=Lax`;
  } catch {
    // ignore
  }
}

const cookieCategories = [
  {
    key: 'analytics' as const,
    label: 'Cookies analytiques',
    description: 'Google Analytics — Mesure d\'audience anonymisée pour comprendre l\'utilisation du site.',
    icon: BarChart3,
  },
  {
    key: 'marketing' as const,
    label: 'Cookies marketing',
    description: 'Facebook, Google Ads, Taboola, LinkedIn — Publicités et contenus personnalisés.',
    icon: Megaphone,
  },
];

export default function CookieConsent() {
  // null = not yet checked (show banner), object = consent saved (hide banner)
  // Use a lazy initializer so localStorage is read once on mount (client-only)
  const [hasConsented, setHasConsented] = useState<CookiePreferences | null>(() => readConsentFromStorage());
  const [showSettings, setShowSettings] = useState(false);
  const [preferences, setPreferences] = useState<CookiePreferences>(defaultPreferences);

  const MINIMAL_CONSENT: CookiePreferences = { necessary: true, analytics: false, marketing: false };

  const handleDismiss = useCallback(() => {
    saveConsent(MINIMAL_CONSENT);
    setHasConsented(MINIMAL_CONSENT);
  }, []);

  const handleAcceptAll = useCallback(() => {
    saveConsent(ALL_ACCEPTED);
    setHasConsented(ALL_ACCEPTED);
  }, []);

  const handleSavePreferences = useCallback(() => {
    saveConsent(preferences);
    setHasConsented(preferences);
  }, [preferences]);

  const togglePreference = useCallback(
    (key: keyof Omit<CookiePreferences, 'necessary'>) => {
      setPreferences((prev) => ({
        ...prev,
        [key]: !prev[key],
      }));
    },
    [],
  );

  // Don't render anything during SSR or if consent already given
  if (hasConsented !== null) return null;

  return (
    <div
      className={cn(
        'fixed inset-x-0 bottom-0 z-[100] transition-all duration-500',
        showSettings ? 'inset-0' : 'inset-x-0 bottom-0',
      )}
    >
      {/* Overlay when settings are open */}
      {showSettings && (
        <div
          className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          onClick={() => setShowSettings(false)}
        />
      )}

      <div
        className={cn(
          'relative mx-auto transition-all duration-300',
          showSettings
            ? 'inset-4 flex flex-col overflow-hidden rounded-2xl border bg-white shadow-2xl sm:inset-8 lg:inset-y-12 lg:mx-auto lg:max-w-2xl'
            : 'mx-4 mb-4 max-w-3xl rounded-xl border bg-white p-5 shadow-xl sm:p-6 lg:mx-auto',
        )}
      >
        {/* Close button */}
        <button
          onClick={handleDismiss}
          className="absolute top-3 right-3 z-10 flex size-8 items-center justify-center rounded-full text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
          aria-label="Fermer"
        >
          <X className="size-4" />
        </button>

        {/* Header */}
        <div className="flex items-start gap-4">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-600">
            <Cookie className="size-6" />
          </div>
          <div className="pr-8">
            <h3 className="text-base font-semibold text-gray-900">
              Nous respectons votre vie privée
            </h3>
            <p className="mt-1 text-sm leading-relaxed text-gray-500">
              Nous utilisons des cookies pour améliorer votre expérience,
              mesurer l&apos;audience et vous proposer des contenus adaptés.
              Vous pouvez personnaliser vos choix à tout moment.
            </p>
          </div>
        </div>

        {/* Default view — Accept / Customize buttons */}
        {!showSettings && (
          <div className="mt-5 flex flex-col gap-3 sm:flex-row">
            <Button
              onClick={handleAcceptAll}
              className="flex-1 bg-emerald-600 text-white hover:bg-emerald-700"
              size="default"
            >
              Tout accepter
            </Button>
            <Button
              onClick={() => setShowSettings(true)}
              variant="outline"
              className="flex-1 border-gray-200 hover:bg-gray-50"
              size="default"
            >
              <Settings className="size-4" />
              Personnaliser
            </Button>
          </div>
        )}

        {/* Settings / Customize view */}
        {showSettings && (
          <div className="mt-6 flex flex-1 flex-col overflow-hidden">
            {/* Necessary cookies — always on */}
            <div className="mb-4 flex items-start gap-3 rounded-lg bg-gray-50 p-4">
              <Checkbox
                checked
                disabled
                id="cookie-necessary"
                className="mt-0.5"
              />
              <div className="flex items-start gap-3">
                <ShieldCheck className="mt-0.5 size-4 shrink-0 text-emerald-600" />
                <div>
                  <label
                    htmlFor="cookie-necessary"
                    className="text-sm font-medium text-gray-900"
                  >
                    Cookies nécessaires
                  </label>
                  <p className="mt-0.5 text-xs text-gray-500">
                    Indispensables au bon fonctionnement du site. Ils ne peuvent
                    pas être désactivés.
                  </p>
                </div>
              </div>
            </div>

            {/* Optional cookie categories */}
            <div className="flex-1 space-y-3 overflow-y-auto">
              {cookieCategories.map((category) => {
                const Icon = category.icon;
                return (
                  <div
                    key={category.key}
                    className="flex items-start gap-3 rounded-lg border border-gray-100 p-4 transition-colors hover:bg-gray-50/50"
                  >
                    <Checkbox
                      id={`cookie-${category.key}`}
                      checked={preferences[category.key]}
                      onCheckedChange={() => togglePreference(category.key)}
                      className="mt-0.5"
                    />
                    <div className="flex items-start gap-3">
                      <Icon className="mt-0.5 size-4 shrink-0 text-gray-400" />
                      <div>
                        <label
                          htmlFor={`cookie-${category.key}`}
                          className="cursor-pointer text-sm font-medium text-gray-900"
                        >
                          {category.label}
                        </label>
                        <p className="mt-0.5 text-xs text-gray-500">
                          {category.description}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Save preferences */}
            <div className="mt-5 flex flex-col gap-3 border-t border-gray-100 pt-5 sm:flex-row">
              <Button
                onClick={handleSavePreferences}
                className="flex-1 bg-emerald-600 text-white hover:bg-emerald-700"
              >
                Enregistrer mes choix
              </Button>
              <Button
                onClick={handleAcceptAll}
                variant="outline"
                className="flex-1 border-gray-200 hover:bg-gray-50"
              >
                Tout accepter
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
