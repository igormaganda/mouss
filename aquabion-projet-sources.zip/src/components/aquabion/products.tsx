"use client";

import { Check, ArrowRight, Building2, Home } from "lucide-react";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface Product {
  title: string;
  image: string;
  imageAlt: string;
  badge: string;
  icon: typeof Home;
  features: string[];
  price: string;
  cta: string;
  highlighted?: boolean;
}

const products: Product[] = [
  {
    title: "AQUABION® Résidentiel",
    image:
      "https://www.jenningsph.com/wp-content/uploads/2025/12/aquabion.webp",
    imageAlt: "AQUABION Résidentiel - Dispositif anti-calcaire pour particuliers",
    badge: "Particuliers",
    icon: Home,
    features: [
      "Idéal pour maisons et appartements",
      "Débit jusqu'à 6 m³/h",
      "Raccordement universel ¾'' - 1¼''",
      "Garantie 5 ans",
      "Sans sel, sans électricité, sans entretien",
    ],
    price: "Entre 900€ et 1 300€ TTC (pose comprise)",
    cta: "Demander un devis",
    highlighted: true,
  },
  {
    title: "AQUABION® S-15 Industriel",
    image:
      "https://static.ticimax.cloud/cdn-cgi/image/width=-,quality=85/76448/uploads/urunresimleri/buyuk/aquabion-s-15-galvanik-kirec-ve-korozy--8d80-.png",
    imageAlt:
      "AQUABION S-15 Industriel - Dispositif anti-calcaire pour professionnels",
    badge: "Professionnels",
    icon: Building2,
    features: [
      "Conçu pour les bâtiments commerciaux et industriels",
      "Débit jusqu'à 15 m³/h",
      "Protection anticorrosion renforcée",
      "Garantie 3 ans",
      "Installation par nos techniciens certifiés",
    ],
    price: "Sur devis",
    cta: "Contactez-nous",
  },
];

export default function Products() {
  return (
    <section
      id="produits"
      className="relative py-12 md:py-16"
    >
      {/* Subtle pattern background */}
      <div
        className="absolute inset-0 -z-10 opacity-[0.03]"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)",
          backgroundSize: "24px 24px",
        }}
      />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto mb-8 max-w-2xl text-center md:mb-10">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Nos Solutions AQUABION®
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Une gamme complète pour tous les besoins, du particulier à
            l&apos;industriel
          </p>
        </div>

        {/* Product Cards */}
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:gap-10">
          {products.map((product) => {
            const Icon = product.icon;
            return (
              <Card
                key={product.title}
                className={`group overflow-hidden border-border/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${
                  product.highlighted
                    ? "hover:border-teal-300 hover:shadow-teal-100/60 ring-1 ring-teal-100"
                    : "hover:border-slate-300 hover:shadow-slate-100/60"
                }`}
              >
                {/* Product Image */}
                <div className="relative overflow-hidden bg-gradient-to-b from-slate-50 to-white px-6 pt-8 pb-4">
                  <div className="relative mx-auto flex h-48 items-center justify-center sm:h-56">
                  <img
                    src={product.image}
                    alt={product.imageAlt}
                    className="h-auto max-h-48 w-auto max-w-full object-contain transition-transform duration-500 group-hover:scale-105 sm:max-h-56"
                  />
                  </div>
                </div>

                <CardHeader className="gap-3 pb-2">
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        product.highlighted ? "default" : "secondary"
                      }
                      className={
                        product.highlighted
                          ? "bg-teal-600 hover:bg-teal-700 text-white"
                          : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                      }
                    >
                      <Icon className="size-3" />
                      {product.badge}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl sm:text-2xl">
                    {product.title}
                  </CardTitle>
                </CardHeader>

                <CardContent className="flex flex-col gap-5">
                  {/* Features */}
                  <ul className="flex flex-col gap-3">
                    {product.features.map((feature) => (
                      <li
                        key={feature}
                        className="flex items-start gap-3 text-sm text-muted-foreground"
                      >
                        <span
                          className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${
                            product.highlighted
                              ? "bg-teal-100 text-teal-700"
                              : "bg-slate-100 text-slate-600"
                          }`}
                        >
                          <Check className="size-3" strokeWidth={3} />
                        </span>
                        <span className="leading-relaxed">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Price */}
                  <div className="border-t border-border/50 pt-4">
                    <p
                      className={`text-sm font-medium ${
                        product.highlighted
                          ? "text-teal-700"
                          : "text-slate-700"
                      }`}
                    >
                      {product.price}
                    </p>
                  </div>
                </CardContent>

                <CardFooter>
                  <Button
                    variant={product.highlighted ? "default" : "outline"}
                    size="lg"
                    className={`w-full transition-all duration-300 ${
                      product.highlighted
                        ? "bg-teal-600 hover:bg-teal-700 text-white shadow-md hover:shadow-lg hover:shadow-teal-200/40"
                        : "hover:bg-slate-50 hover:text-slate-900 hover:border-slate-300"
                    }`}
                  >
                    {product.cta}
                    <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
