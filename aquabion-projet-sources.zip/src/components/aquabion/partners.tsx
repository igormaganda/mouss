"use client";

import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";

const logos = [
  {
    src: "https://aquabion-distribution.com/img/preprod/image%20160.png",
    alt: "Certification partenaire AQUABION®",
  },
  {
    src: "https://aquabion-distribution.com/img/preprod/image%20159.png",
    alt: "Certification partenaire AQUABION®",
  },
  {
    src: "https://aquabion-distribution.com/img/preprod/image%20161.png",
    alt: "Certification partenaire AQUABION®",
  },
  {
    src: "https://aquabion-distribution.com/img/preprod/image%20162.png",
    alt: "Certification partenaire AQUABION®",
  },
  {
    src: "https://aquabion-distribution.com/img/preprod/image%20163.png",
    alt: "Certification partenaire AQUABION®",
  },
];

export default function Partners() {
  return (
    <section className="hidden md:block bg-muted/40 py-12 md:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto mb-8 max-w-2xl text-center md:mb-10">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Ils nous font confiance
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            AQUABION® est certifié et reconnu par des organismes indépendants
          </p>
        </div>

        {/* Logos Grid */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {logos.map((logo, index) => (
            <Card
              key={index}
              className="group border-border/50 bg-card/80 backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:border-teal-200 hover:shadow-lg hover:shadow-teal-100/50 dark:hover:border-teal-800 dark:hover:shadow-teal-900/30"
            >
              <CardContent className="flex items-center justify-center p-4 sm:p-6">
                <div className="relative h-20 w-full sm:h-24">
                  <Image
                    src={logo.src}
                    alt={logo.alt}
                    fill
                    className="object-contain transition-all duration-300 grayscale opacity-70 group-hover:grayscale-0 group-hover:opacity-100"
                    sizes="(max-width: 640px) 45vw, (max-width: 1024px) 30vw, 18vw"
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
