'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Droplets, Shield, Zap, Leaf, ArrowDown } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    // Trigger a re-render after hydration for smooth animations
    const t = requestAnimationFrame(() => setVisible(true));
    return () => cancelAnimationFrame(t);
  }, []);

  const scrollTo = useCallback((id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const badges: { icon: typeof Droplets; label: string }[] = [
    { icon: Droplets, label: 'Sans sel' },
    { icon: Zap, label: 'Sans électricité' },
    { icon: Leaf, label: 'Sans produits chimiques' },
    { icon: Shield, label: 'Garantie 5 ans' },
  ];

  return (
    <section
      id="accueil"
      ref={sectionRef}
      className="relative min-h-screen w-full overflow-hidden flex items-center justify-center"
    >
      {/* ─── Background Image ─── */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-105 transition-transform duration-[20s] ease-out"
        aria-hidden="true"
        style={{
          backgroundImage:
            'url(https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1600&q=80)',
        }}
      />

      {/* ─── Gradient Overlays ─── */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/80" aria-hidden="true" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-black/40" aria-hidden="true" />

      {/* ─── Floating Particles ─── */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        {[
          { size: 6, top: '15%', left: '10%', dur: 18, delay: 0 },
          { size: 4, top: '25%', left: '80%', dur: 22, delay: 2 },
          { size: 8, top: '65%', left: '20%', dur: 20, delay: 4 },
          { size: 5, top: '55%', left: '72%', dur: 24, delay: 1 },
          { size: 3, top: '40%', left: '5%', dur: 16, delay: 3 },
          { size: 7, top: '78%', left: '85%', dur: 19, delay: 5 },
        ].map((p, i) => (
          <span
            key={i}
            className="absolute rounded-full bg-cyan-400/30"
            style={{
              width: p.size,
              height: p.size,
              top: p.top,
              left: p.left,
              boxShadow: '0 0 12px 2px rgba(34,211,238,0.25)',
              animation: `particleDrift ${p.dur}s ease-in-out ${p.delay}s infinite`,
            }}
          />
        ))}
      </div>

      {/* ─── Main Content ─── */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center gap-4 sm:gap-5 py-16 sm:py-20">
        {/* Pre‑headline */}
        <div
          className={cn(
            'inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 backdrop-blur-md px-4 py-1.5 text-xs sm:text-sm font-medium tracking-wider uppercase text-white/90 transition-all duration-500',
            visible
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-4',
          )}
        >
          <Droplets className="size-4 text-cyan-400" />
          Solution anti‑calcaire française
        </div>

        {/* Headline */}
        <h1
          className={cn(
            'text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold leading-tight tracking-tight max-w-4xl transition-all duration-500',
            visible
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-4',
          )}
        >
          <span className="bg-gradient-to-r from-white via-cyan-200 to-teal-300 bg-clip-text text-transparent drop-shadow-[0_2px_12px_rgba(34,211,238,0.25)] animate-gradient-x">
            Protégez votre maison{' '}
          </span>
          <br className="hidden sm:block" />
          <span className="bg-gradient-to-r from-teal-300 via-cyan-200 to-white bg-clip-text text-transparent drop-shadow-[0_2px_12px_rgba(34,211,238,0.25)] animate-gradient-x">
            contre le calcaire
          </span>
        </h1>

        {/* Sub‑headline */}
        <p
          className={cn(
            'max-w-2xl text-base sm:text-lg md:text-xl text-white/75 leading-relaxed font-light transition-all duration-500',
            visible
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-4',
          )}
        >
          <span className="font-semibold text-white">AQUABION®</span> : la
          solution écologique, sans sel et sans entretien pour un eau saine et
          des installations protégées
        </p>

        {/* CTA Buttons */}
        <div
          className={cn(
            'flex flex-col sm:flex-row items-center gap-4 transition-all duration-500',
            visible
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-4',
          )}
        >
          <Button
            size="lg"
            onClick={() => scrollTo('avantages')}
            className="group h-13 sm:h-14 rounded-full px-8 sm:px-10 text-base font-semibold bg-gradient-to-r from-cyan-500 to-teal-500 text-white shadow-lg shadow-cyan-500/25 border-0 hover:shadow-xl hover:shadow-cyan-500/35 hover:scale-[1.04] active:scale-[0.97] transition-all duration-300"
          >
            Découvrir AQUABION
            <ArrowDown className="size-4 ml-1 group-hover:translate-y-0.5 transition-transform duration-300" />
          </Button>

          <Button
            size="lg"
            variant="outline"
            onClick={() => scrollTo('simulateur')}
            className="group h-13 sm:h-14 rounded-full px-8 sm:px-10 text-base font-semibold border-white/30 bg-white/10 backdrop-blur-sm text-white shadow-lg hover:bg-white/20 hover:border-white/50 hover:scale-[1.04] active:scale-[0.97] transition-all duration-300"
          >
            Simuler vos économies
            <Zap className="size-4 ml-1 text-yellow-300 group-hover:rotate-12 transition-transform duration-300" />
          </Button>
        </div>

        {/* Trust Badges */}
        <div
          className={cn(
            'mt-4 sm:mt-6 grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-5 w-full max-w-2xl transition-all duration-500',
            visible
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-4',
          )}
        >
          {badges.map(({ icon: Icon, label }) => (
            <div
              key={label}
              className="group flex flex-col items-center gap-2.5 rounded-2xl border border-white/10 bg-white/[0.06] backdrop-blur-md px-3 py-4 sm:px-5 sm:py-5 hover:bg-white/10 hover:border-white/20 hover:-translate-y-1 transition-all duration-300 cursor-default"
            >
              <div className="flex size-11 items-center justify-center rounded-full bg-cyan-500/15 text-cyan-400 group-hover:bg-cyan-500/25 transition-colors duration-300">
                <Icon className="size-5" strokeWidth={1.8} />
              </div>
              <span className="text-[11px] sm:text-sm font-medium text-white/75 leading-tight text-center">
                {label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* ─── Scroll Indicator ─── */}
      <button
        onClick={() => scrollTo('avantages')}
        aria-label="Défiler vers le bas"
        className={cn(
          'absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-white/40 hover:text-white/70 transition-colors duration-300 cursor-pointer transition-all duration-500',
          visible
            ? 'opacity-100 translate-y-0'
            : 'opacity-0 translate-y-4',
        )}
      >
        <span className="text-[10px] uppercase tracking-[0.25em] font-medium">
          Défiler
        </span>
        <ArrowDown className="size-4 animate-bounce" />
      </button>

      {/* ─── Keyframe Styles ─── */}
      <style>{`
        @keyframes particleDrift {
          0%, 100% {
            transform: translateY(0) translateX(0) scale(1);
            opacity: 0.4;
          }
          25% {
            transform: translateY(-40px) translateX(20px) scale(1.2);
            opacity: 0.8;
          }
          50% {
            transform: translateY(-80px) translateX(-10px) scale(0.8);
            opacity: 0.5;
          }
          75% {
            transform: translateY(-50px) translateX(30px) scale(1.1);
            opacity: 0.7;
          }
        }

        @keyframes gradient-x {
          0%, 100% {
            background-size: 200% 200%;
            background-position: 0% 50%;
          }
          50% {
            background-size: 200% 200%;
            background-position: 100% 50%;
          }
        }

        .animate-gradient-x {
          animation: gradient-x 8s ease-in-out infinite;
          background-size: 200% 200%;
        }
      `}</style>
    </section>
  );
}
