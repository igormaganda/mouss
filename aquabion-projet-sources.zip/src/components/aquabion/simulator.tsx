'use client';

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Calculator,
  TrendingDown,
  Thermometer,
  Home,
  Bath,
  ArrowRight,
  Users,
  Droplets,
  Leaf,
  Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';

/* ─── Constants ─── */
const HABITATION_MULTIPLIERS: Record<string, number> = {
  appartement: 0.7,
  maison: 1.0,
  grande_maison: 1.3,
  villa: 1.6,
};

const HABITATION_LABELS: Record<string, string> = {
  appartement: 'Appartement',
  maison: 'Maison moyenne',
  grande_maison: 'Grande maison',
  villa: 'Villa / Piscine',
};

function getHardnessLabel(value: number): string {
  if (value <= 15) return 'Douce';
  if (value <= 25) return 'Moyenne';
  if (value <= 35) return 'Dure';
  return 'Très dure';
}

function getHardnessColor(value: number): string {
  if (value <= 15) return 'text-green-500';
  if (value <= 25) return 'text-yellow-500';
  if (value <= 35) return 'text-orange-500';
  return 'text-red-500';
}

function getHardnessBg(value: number): string {
  if (value <= 15) return 'bg-green-100 dark:bg-green-950';
  if (value <= 25) return 'bg-yellow-100 dark:bg-yellow-950';
  if (value <= 35) return 'bg-orange-100 dark:bg-orange-950';
  return 'bg-red-100 dark:bg-red-950';
}

/* ─── Animated Counter Hook ─── */
function useAnimatedCounter(target: number, duration = 600): number {
  const [display, setDisplay] = useState(target);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const start = performance.now();
    const from = display;

    function tick(now: number) {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      // ease-out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.round(from + (target - from) * eased));

      if (progress < 1) {
        rafRef.current = requestAnimationFrame(tick);
      }
    }

    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [target, duration]);

  return display;
}

/* ─── Animated Number Component ─── */
function AnimatedNumber({
  value,
  prefix = '',
  suffix = '',
  decimals = 0,
}: {
  value: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
}) {
  const display = useAnimatedCounter(value, 500);
  return (
    <span>
      {prefix}
      {decimals > 0 ? display.toFixed(decimals) : display}
      {suffix}
    </span>
  );
}

/* ─── Main Component ─── */
export default function Simulator() {
  const [persons, setPersons] = useState(4);
  const [hardness, setHardness] = useState(25);
  const [habitation, setHabitation] = useState('maison');
  const [bathrooms, setBathrooms] = useState(2);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  /* ─── Intersection Observer for fade-in ─── */
  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.15 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  /* ─── Calculations ─── */
  const results = useMemo(() => {
    const basePerPerson = 50;
    const hardnessMult = hardness / 25;
    const habMult = HABITATION_MULTIPLIERS[habitation] ?? 1.0;
    const bathMult = bathrooms / 2;

    const rawSavings = basePerPerson * persons * hardnessMult * habMult * bathMult;
    const annualSavings = Math.round(Math.max(150, Math.min(1200, rawSavings)));

    // Limescale reduction: 85-99%, higher hardness = slightly better (more to remove)
    const limescaleReduction = hardness >= 36 ? 99 : hardness >= 26 ? 97 : hardness >= 16 ? 94 : 85;

    // Appliance lifespan: +30% to +50%
    const lifespanIncrease = hardness >= 26 ? 50 : hardness >= 16 ? 40 : 30;

    // CO2 savings based on habitation type
    const co2Savings = Math.round(
      (habMult === 0.7 ? 50 : habMult === 1.0 ? 100 : habMult === 1.3 ? 150 : 200) *
        (persons / 4) *
        (bathrooms / 2),
    );

    // ROI: average installation cost 900-1300€ TTC
    const avgCost = 1100;
    const paybackMonths = Math.ceil((avgCost / annualSavings) * 12);
    const net8Years = annualSavings * 8 - avgCost;

    return { annualSavings, limescaleReduction, lifespanIncrease, co2Savings, paybackMonths, net8Years };
  }, [persons, hardness, habitation, bathrooms]);

  const scrollToContact = useCallback(() => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  /* ─── Result Cards Data ─── */
  const resultCards = [
    {
      icon: Calculator,
      label: 'Économies annuelles estimées',
      value: <AnimatedNumber value={results.annualSavings} prefix="" suffix="€" />,
      sublabel: 'par an',
      color: 'from-emerald-500 to-teal-500',
      bgLight: 'bg-emerald-50',
      bgDark: 'dark:bg-emerald-950/40',
      iconBg: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300',
    },
    {
      icon: TrendingDown,
      label: 'Réduction calcaire',
      value: <AnimatedNumber value={results.limescaleReduction} suffix="%" />,
      sublabel: 'efficacité mesurée',
      color: 'from-cyan-500 to-blue-500',
      bgLight: 'bg-cyan-50',
      bgDark: 'dark:bg-cyan-950/40',
      iconBg: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/50 dark:text-cyan-300',
    },
    {
      icon: Thermometer,
      label: 'Durée de vie prolongée des appareils',
      value: <AnimatedNumber value={results.lifespanIncrease} prefix="+" suffix="%" />,
      sublabel: 'de durée de vie supplémentaire',
      color: 'from-amber-500 to-orange-500',
      bgLight: 'bg-amber-50',
      bgDark: 'dark:bg-amber-950/40',
      iconBg: 'bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300',
    },
    {
      icon: Leaf,
      label: 'CO₂ économisé par an',
      value: <AnimatedNumber value={results.co2Savings} suffix=" kg" />,
      sublabel: "d'émissions évitées",
      color: 'from-green-500 to-emerald-600',
      bgLight: 'bg-green-50',
      bgDark: 'dark:bg-green-950/40',
      iconBg: 'bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300',
    },
  ];

  return (
    <section
      id="simulateur"
      ref={sectionRef}
      className="relative py-12 md:py-16 overflow-hidden"
    >
      {/* ─── Background Image (low opacity) ─── */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        aria-hidden="true"
        style={{
          backgroundImage:
            'url(https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=1600&q=80)',
          opacity: 0.06,
        }}
      />

      {/* ─── Teal tint overlay ─── */}
      <div
        className="absolute inset-0 bg-gradient-to-br from-teal-50/90 via-cyan-50/85 to-sky-50/90 dark:from-teal-950/90 dark:via-cyan-950/85 dark:to-sky-950/90"
        aria-hidden="true"
      />

      {/* ─── Subtle water pattern (CSS) ─── */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        <svg className="absolute bottom-0 left-0 w-full opacity-[0.04] dark:opacity-[0.06]" viewBox="0 0 1440 320">
          <path
            fill="currentColor"
            className="text-teal-700"
            d="M0,224L48,213.3C96,203,192,181,288,181.3C384,181,480,203,576,224C672,245,768,267,864,261.3C960,256,1056,224,1152,197.3C1248,171,1344,149,1392,138.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
          />
        </svg>
        <svg className="absolute bottom-0 left-0 w-full opacity-[0.03] dark:opacity-[0.05]" viewBox="0 0 1440 320">
          <path
            fill="currentColor"
            className="text-cyan-600"
            d="M0,288L60,272C120,256,240,224,360,213.3C480,203,600,213,720,229.3C840,245,960,267,1080,261.3C1200,256,1320,224,1380,208L1440,192L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"
          />
        </svg>
      </div>

      {/* ─── Content ─── */}
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* ─── Section Header ─── */}
        <div
          className={cn(
            'mx-auto mb-8 max-w-2xl text-center transition-all duration-700 md:mb-10',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8',
          )}
        >
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-teal-200 bg-white/70 px-4 py-1.5 text-xs font-medium tracking-wider uppercase text-teal-700 shadow-sm backdrop-blur-sm dark:border-teal-800 dark:bg-teal-900/40 dark:text-teal-300">
            <Calculator className="size-4" />
            Outil interactif
          </div>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl text-gray-900 dark:text-white">
            Simulez vos{' '}
            <span className="bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent dark:from-teal-400 dark:to-cyan-400">
              économies
            </span>
          </h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
            Découvrez combien vous pouvez économiser avec AQUABION® en quelques clics
          </p>
        </div>

        {/* ─── Two-Column Layout ─── */}
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-2 lg:gap-12">
          {/* ─── Left: Form ─── */}
          <div
            className={cn(
              'transition-all duration-700 delay-100',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8',
            )}
          >
            <Card className="border-teal-100 bg-white/80 shadow-lg shadow-teal-900/5 backdrop-blur-sm dark:border-teal-900/50 dark:bg-gray-900/80 dark:shadow-teal-900/20">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900 dark:text-white">
                  <Droplets className="mr-2 inline-block size-5 text-teal-600 dark:text-teal-400" />
                  Paramètres de simulation
                </CardTitle>
                <CardDescription>
                  Ajustez les paramètres ci-dessous pour obtenir une estimation personnalisée
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col gap-7">
                {/* ─── 1. Number of persons ─── */}
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                      <Users className="size-4 text-teal-600 dark:text-teal-400" />
                      Nombre de personnes dans le foyer
                    </Label>
                    <span className="flex h-8 w-12 items-center justify-center rounded-lg bg-teal-50 text-sm font-bold text-teal-700 dark:bg-teal-900/50 dark:text-teal-300">
                      {persons}
                    </span>
                  </div>
                  <Slider
                    min={1}
                    max={8}
                    step={1}
                    value={[persons]}
                    onValueChange={(v) => setPersons(v[0])}
                    className="py-2 [&_[data-slot=slider-track]]:h-2 [&_[data-slot=slider-range]]:bg-gradient-to-r [&_[data-slot=slider-range]]:from-teal-500 [&_[data-slot=slider-range]]:to-cyan-500 [&_[data-slot=slider-thumb]]:size-5 [&_[data-slot=slider-thumb]]:border-teal-500 [&_[data-slot=slider-thumb]]:ring-teal-200 [&_[data-slot=slider-thumb]]:hover:ring-teal-300"
                  />
                  <div className="flex justify-between text-xs text-gray-400">
                    <span>1</span>
                    <span>8</span>
                  </div>
                </div>

                {/* ─── 2. Water hardness ─── */}
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                      <Thermometer className="size-4 text-teal-600 dark:text-teal-400" />
                      Dureté de l&apos;eau
                    </Label>
                    <div className="flex items-center gap-2">
                      <span
                        className={cn(
                          'rounded-full px-3 py-0.5 text-xs font-semibold',
                          getHardnessBg(hardness),
                          getHardnessColor(hardness),
                        )}
                      >
                        {getHardnessLabel(hardness)}
                      </span>
                      <span className="flex h-8 w-14 items-center justify-center rounded-lg bg-teal-50 text-sm font-bold text-teal-700 dark:bg-teal-900/50 dark:text-teal-300">
                        {hardness}°f
                      </span>
                    </div>
                  </div>
                  <Slider
                    min={5}
                    max={50}
                    step={1}
                    value={[hardness]}
                    onValueChange={(v) => setHardness(v[0])}
                    className="py-2 [&_[data-slot=slider-track]]:h-2 [&_[data-slot=slider-range]]:bg-gradient-to-r [&_[data-slot=slider-range]]:from-green-400 [&_[data-slot=slider-range]]:via-yellow-400 [&_[data-slot=slider-range]]:to-red-400 [&_[data-slot=slider-thumb]]:size-5 [&_[data-slot=slider-thumb]]:border-orange-500 [&_[data-slot=slider-thumb]]:ring-orange-200 [&_[data-slot=slider-thumb]]:hover:ring-orange-300"
                  />
                  <div className="flex justify-between text-xs text-gray-400">
                    <span>5°f Douce</span>
                    <span>50°f Très dure</span>
                  </div>
                </div>

                {/* ─── 3. Type of habitation ─── */}
                <div className="flex flex-col gap-3">
                  <Label className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                    <Home className="size-4 text-teal-600 dark:text-teal-400" />
                    Type d&apos;habitation
                  </Label>
                  <Select value={habitation} onValueChange={setHabitation}>
                    <SelectTrigger className="h-12 w-full rounded-lg border-teal-200 bg-white text-gray-700 shadow-sm transition-colors focus:ring-teal-200 dark:border-teal-800 dark:bg-gray-900 dark:text-gray-200">
                      <Home className="mr-2 size-4 text-gray-400" />
                      <SelectValue placeholder="Sélectionnez..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="appartement">
                        <span className="flex items-center gap-2">
                          <Home className="size-4 text-gray-400" />
                          Appartement
                        </span>
                      </SelectItem>
                      <SelectItem value="maison">
                        <span className="flex items-center gap-2">
                          <Home className="size-4 text-gray-400" />
                          Maison moyenne
                        </span>
                      </SelectItem>
                      <SelectItem value="grande_maison">
                        <span className="flex items-center gap-2">
                          <Home className="size-4 text-gray-400" />
                          Grande maison
                        </span>
                      </SelectItem>
                      <SelectItem value="villa">
                        <span className="flex items-center gap-2">
                          <Home className="size-4 text-gray-400" />
                          Villa / Piscine
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* ─── 4. Number of bathrooms ─── */}
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                      <Bath className="size-4 text-teal-600 dark:text-teal-400" />
                      Nombre de salles de bain
                    </Label>
                    <span className="flex h-8 w-12 items-center justify-center rounded-lg bg-teal-50 text-sm font-bold text-teal-700 dark:bg-teal-900/50 dark:text-teal-300">
                      {bathrooms}
                    </span>
                  </div>
                  <Slider
                    min={1}
                    max={5}
                    step={1}
                    value={[bathrooms]}
                    onValueChange={(v) => setBathrooms(v[0])}
                    className="py-2 [&_[data-slot=slider-track]]:h-2 [&_[data-slot=slider-range]]:bg-gradient-to-r [&_[data-slot=slider-range]]:from-teal-500 [&_[data-slot=slider-range]]:to-cyan-500 [&_[data-slot=slider-thumb]]:size-5 [&_[data-slot=slider-thumb]]:border-teal-500 [&_[data-slot=slider-thumb]]:ring-teal-200 [&_[data-slot=slider-thumb]]:hover:ring-teal-300"
                  />
                  <div className="flex justify-between text-xs text-gray-400">
                    <span>1</span>
                    <span>5</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* ─── Right: Results ─── */}
          <div
            className={cn(
              'flex flex-col gap-6 transition-all duration-700 delay-200',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8',
            )}
          >
            <div className="mb-2 flex items-center gap-2 text-sm font-medium text-teal-700 dark:text-teal-300">
              <Zap className="size-4" />
              Vos résultats personnalisés
            </div>

            {/* ─── Main Savings Card (highlighted) ─── */}
            <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-teal-500 to-cyan-600 text-white shadow-xl shadow-teal-500/20">
              {/* Decorative circles */}
              <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-white/10" aria-hidden="true" />
              <div className="absolute -bottom-4 -left-4 h-16 w-16 rounded-full bg-white/5" aria-hidden="true" />
              <CardContent className="relative flex flex-col items-center gap-2 py-8 text-center">
                <Calculator className="mb-2 size-8 text-white/80" />
                <p className="text-sm font-medium uppercase tracking-wider text-white/80">
                  Économies annuelles estimées
                </p>
                <div className="flex items-end gap-3 sm:gap-5">
                  <p className="text-5xl font-extrabold tabular-nums sm:text-6xl">
                    <AnimatedNumber value={results.annualSavings} suffix="€" />
                  </p>
                  <div className="pb-2 border-l border-white/25 pl-3 sm:pl-5">
                    <p className="text-xs uppercase tracking-wider text-white/60">
                      sur 8 ans
                    </p>
                    <p className="text-xl font-bold tabular-nums sm:text-2xl">
                      <AnimatedNumber value={results.annualSavings * 8} suffix="€" />
                    </p>
                  </div>
                </div>
                <p className="text-sm text-white/70">
                  avec AQUABION® installé chez vous
                </p>
              </CardContent>
            </Card>

            {/* ─── ROI / Payback Card ─── */}
            <Card className="border-teal-100 bg-gradient-to-r from-teal-50 to-cyan-50 dark:border-teal-900/50 dark:from-teal-950/40 dark:to-cyan-950/40">
              <CardContent className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-5 pb-5">
                <div className="flex items-center gap-3">
                  <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-teal-100 text-teal-700 dark:bg-teal-900/50 dark:text-teal-300">
                    <Zap className="size-5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">
                      Retour sur investissement
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Pour une installation estimée entre 900€ et 1 300€ TTC
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-5 sm:gap-8">
                  <div className="text-center">
                    <p className="text-2xl font-bold tabular-nums text-teal-700 dark:text-teal-300">
                      {results.paybackMonths} mois
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">amortissement</p>
                  </div>
                  <div className="hidden sm:block h-8 w-px bg-teal-200/60 dark:bg-teal-700/40" />
                  <div className="text-center">
                    <p className="text-2xl font-bold tabular-nums text-teal-700 dark:text-teal-300">
                      +<AnimatedNumber value={results.net8Years} suffix="€" />
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">gain net / 8 ans</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* ─── Three detail cards - hidden on mobile ─── */}
            <div className="hidden sm:grid grid-cols-1 gap-4 sm:grid-cols-3">
              {resultCards.slice(1).map((card) => {
                const Icon = card.icon;
                return (
                  <Card
                    key={card.label}
                    className={cn(
                      'group border-border/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-md',
                      card.bgLight,
                      card.bgDark,
                    )}
                  >
                    <CardContent className="flex flex-col items-center gap-3 pt-6 pb-4 text-center">
                      <div
                        className={cn(
                          'flex size-10 items-center justify-center rounded-full transition-colors duration-300',
                          card.iconBg,
                        )}
                      >
                        <Icon className="size-5" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold tabular-nums text-gray-900 dark:text-white">
                          {card.value}
                        </p>
                        <p className="mt-1 text-xs text-gray-500 dark:text-gray-400 leading-snug">
                          {card.sublabel}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* ─── Summary highlight - hidden on mobile ─── */}
            <Card className="hidden sm:block border-teal-100 bg-white/60 backdrop-blur-sm dark:border-teal-900/40 dark:bg-gray-900/60">
              <CardContent className="flex items-start gap-3 pt-5">
                <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-teal-100 text-teal-600 dark:bg-teal-900/50 dark:text-teal-300">
                  <Zap className="size-4" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">
                    {HABITATION_LABELS[habitation]} · {persons}{' '}
                    {persons > 1 ? 'personnes' : 'personne'} · {bathrooms}{' '}
                    {bathrooms > 1 ? 'salles de bain' : 'salle de bain'} · Eau{' '}
                    {getHardnessLabel(hardness).toLowerCase()}
                  </p>
                  <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                    Estimation basée sur les données moyennes du marché français.
                    Les résultats réels peuvent varier selon votre consommation.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* ─── CTA ─── */}
            <Button
              size="lg"
              onClick={scrollToContact}
              className="group h-13 rounded-full bg-gradient-to-r from-teal-500 to-cyan-600 px-8 text-base font-semibold text-white shadow-lg shadow-teal-500/25 hover:shadow-xl hover:shadow-teal-500/35 hover:scale-[1.03] active:scale-[0.97] transition-all duration-300 w-full sm:w-auto"
            >
              Demander un devis personnalisé
              <ArrowRight className="ml-2 size-4 group-hover:translate-x-1 transition-transform duration-300" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
