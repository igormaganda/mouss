'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
} from '@/components/ui/sheet';
import { Menu, Phone } from 'lucide-react';
import { cn } from '@/lib/utils';

const NAV_LINKS = [
  { label: 'Accueil', href: '#accueil' },
  { label: 'Avantages', href: '#avantages' },
  { label: 'Technologie', href: '#technologie' },
  { label: 'Simulateur', href: '#simulateur' },
  { label: 'Produits', href: '#produits' },
  { label: 'Contact', href: '#contact' },
] as const;

function handleSmoothScroll(href: string) {
  const id = href.replace('#', '');
  const el = document.getElementById(id);
  if (el) {
    const headerHeight = 80;
    const y = el.getBoundingClientRect().top + window.scrollY - headerHeight;
    window.scrollTo({ top: y, behavior: 'smooth' });
  }
}

function NavLink({
  label,
  href,
  onClick,
  className,
}: {
  label: string;
  href: string;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <a
      href={href}
      onClick={(e) => {
        e.preventDefault();
        handleSmoothScroll(href);
        onClick?.();
      }}
      className={cn(
        'relative text-sm font-medium text-slate-700 transition-colors duration-200 hover:text-teal-600 dark:text-slate-200 dark:hover:text-teal-400',
        'after:absolute after:-bottom-1 after:left-0 after:h-0.5 after:w-0 after:bg-teal-500 after:transition-all after:duration-300 after:ease-out hover:after:w-full',
        className,
      )}
    >
      {label}
    </a>
  );
}

function MobileNavLink({
  label,
  href,
  onClose,
}: {
  label: string;
  href: string;
  onClose: () => void;
}) {
  return (
    <a
      href={href}
      onClick={(e) => {
        e.preventDefault();
        handleSmoothScroll(href);
        onClose();
      }}
      className="flex items-center rounded-lg px-4 py-3 text-base font-medium text-slate-700 transition-all duration-200 hover:bg-teal-50 hover:text-teal-700 dark:text-slate-200 dark:hover:bg-teal-950/30 dark:hover:text-teal-400"
    >
      {label}
    </a>
  );
}

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [activeHash, setActiveHash] = useState('#accueil');

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 20);

      // Track active section
      const sections = NAV_LINKS.map((l) => l.href.replace('#', ''));
      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 120) {
            setActiveHash(`#${sections[i]}`);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-50 w-full transition-all duration-300 ease-out',
        scrolled
          ? 'border-b border-teal-100 bg-white shadow-sm dark:border-teal-900/50 dark:bg-slate-900'
          : 'bg-white shadow-sm dark:bg-slate-900',
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8 md:h-20">
        {/* Logo */}
        <a
          href="#accueil"
          onClick={(e) => {
            e.preventDefault();
            handleSmoothScroll('#accueil');
          }}
          className="flex-shrink-0 transition-opacity duration-200 hover:opacity-80"
        >
          <img
            src="https://aquabion-distribution.com/img/logo-aquabion.png"
            alt="AQUABION"
            className="h-10 md:h-12"
          />
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.href}
              label={link.label}
              href={link.href}
              className={cn(
                'px-3 py-2',
                activeHash === link.href &&
                  '!text-teal-600 after:!w-full dark:!text-teal-400',
              )}
            />
          ))}
        </nav>

        {/* Desktop CTA + Phone */}
        <div className="hidden items-center gap-3 lg:flex">
          <a
            href="tel:+33977550359"
            className="mr-1 flex items-center gap-2 text-sm font-medium text-slate-600 transition-colors hover:text-teal-600 dark:text-slate-300 dark:hover:text-teal-400"
          >
            <Phone className="size-4" />
            <span className="hidden xl:inline">09 77 55 03 59</span>
          </a>
          <Button
            asChild
            size="lg"
            className="bg-teal-600 font-semibold text-white shadow-md shadow-teal-600/20 transition-all duration-200 hover:bg-teal-700 hover:shadow-lg hover:shadow-teal-600/30"
          >
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                handleSmoothScroll('#contact');
              }}
            >
              Demander un Devis
            </a>
          </Button>
        </div>

        {/* Mobile: Hamburger Menu + CTA */}
        <div className="flex items-center gap-2 lg:hidden">
          <Button
            asChild
            size="sm"
            className="bg-teal-600 text-xs font-semibold text-white shadow-sm transition-colors hover:bg-teal-700"
          >
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                handleSmoothScroll('#contact');
              }}
            >
              <Phone className="size-3.5 sm:mr-1.5 sm:hidden" />
              <span className="hidden sm:inline">Devis</span>
            </a>
          </Button>

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                aria-label="Ouvrir le menu"
              >
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>

            <SheetContent side="right" className="w-[280px] overflow-y-auto p-0">
              <SheetTitle className="sr-only">Menu de navigation</SheetTitle>

              {/* Mobile Header */}
              <div className="border-b border-slate-100 px-5 py-6 dark:border-slate-800">
                <img
                  src="https://aquabion-distribution.com/img/logo-aquabion.png"
                  alt="AQUABION"
                  className="h-8"
                />
              </div>

              {/* Mobile Nav Links */}
              <nav className="flex flex-col gap-1 px-3 py-4">
                {NAV_LINKS.map((link) => (
                  <MobileNavLink
                    key={link.href}
                    label={link.label}
                    href={link.href}
                    onClose={() => setOpen(false)}
                  />
                ))}
              </nav>

              {/* Mobile Footer */}
              <div className="mt-auto border-t border-slate-100 px-5 py-5 dark:border-slate-800">
                <Button
                  asChild
                  className="w-full bg-teal-600 font-semibold text-white shadow-md shadow-teal-600/20 transition-all duration-200 hover:bg-teal-700"
                >
                  <a
                    href="#contact"
                    onClick={(e) => {
                      e.preventDefault();
                      handleSmoothScroll('#contact');
                      setOpen(false);
                    }}
                  >
                    Demander un Devis
                  </a>
                </Button>
                <a
                  href="tel:+33977550359"
                  className="mt-3 flex items-center justify-center gap-2 text-sm font-medium text-slate-500 transition-colors hover:text-teal-600 dark:text-slate-400 dark:hover:text-teal-400"
                >
                  <Phone className="size-4" />
                  09 77 55 03 59
                </a>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
