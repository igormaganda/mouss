'use client';

import Image from 'next/image';
import {
  Phone,
  Mail,
  MapPin,
  Facebook,
  Instagram,
  Linkedin,
  Youtube,
} from 'lucide-react';

interface FooterProps {
  onOpenLegal: (page: string) => void;
}

const quickLinks = [
  { label: 'Avantages', href: '#avantages' },
  { label: 'Technologie', href: '#technologie' },
  { label: 'Simulateur', href: '#simulateur' },
  { label: 'Produits', href: '#produits' },
  { label: 'Contact', href: '#contact' },
];

const legalLinks = [
  { label: 'Mentions Légales', page: 'mentions-legales' },
  { label: 'Politique de Confidentialité', page: 'confidentialite' },
  { label: 'CGV', page: 'cgv' },
  { label: 'Cookies', page: 'cookies' },
];

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Youtube, href: '#', label: 'YouTube' },
];

export default function Footer({ onOpenLegal }: FooterProps) {
  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* Main Footer Content */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-3">
          {/* Column 1: Logo & About */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Image
                src="https://aquabion-distribution.com/img/logo-aquabion.png"
                alt="AQUABION"
                width={140}
                height={32}
                className="h-8 w-auto brightness-0 invert"
              />
            </div>
            <p className="text-sm leading-relaxed text-gray-400">
              AQUABION® est un système innovant de traitement anti-calcaire par
              galvanisation brevetée. Protégez vos installations, économisez
              l&apos;énergie et préservez l&apos;environnement avec une solution
              100% écologique, sans sel, sans électricité et sans entretien.
            </p>
            {/* Social Media */}
            <div className="flex items-center gap-3 pt-2">
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    aria-label={social.label}
                    className="flex size-9 items-center justify-center rounded-full bg-gray-800 text-gray-400 transition-colors hover:bg-emerald-600 hover:text-white"
                  >
                    <Icon className="size-4" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Column 2: Liens rapides - hidden on mobile (in hamburger menu) */}
          <div className="hidden md:block space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
              Liens rapides
            </h3>
            <nav aria-label="Liens rapides">
              <ul className="space-y-2.5">
                {quickLinks.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="text-sm text-gray-400 transition-colors hover:text-emerald-400"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          </div>

          {/* Column 3: Contact & Legal */}
          <div className="space-y-6">
            {/* Contact Info */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                Contact
              </h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Phone className="mt-0.5 size-4 shrink-0 text-emerald-500" />
                  <a
                    href="tel:+33977550359"
                    className="text-sm text-gray-400 transition-colors hover:text-emerald-400"
                  >
                    +33 9 77 55 03 59
                  </a>
                </li>
                <li className="flex items-start gap-3">
                  <Mail className="mt-0.5 size-4 shrink-0 text-emerald-500" />
                  <a
                    href="mailto:contact@aquabion-mag.com"
                    className="text-sm text-gray-400 transition-colors hover:text-emerald-400"
                  >
                    contact@aquabion-mag.com
                  </a>
                </li>
                <li className="flex items-start gap-3">
                  <MapPin className="mt-0.5 size-4 shrink-0 text-emerald-500" />
                  <span className="text-sm text-gray-400">
                    100 route de Nîmes,
                    <br />
                    30132 Caissargues, France
                  </span>
                </li>
              </ul>
            </div>

            {/* Legal Links */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                Informations légales
              </h3>
              <ul className="space-y-2">
                {legalLinks.map((link) => (
                  <li key={link.page}>
                    <button
                      onClick={() => onOpenLegal(link.page)}
                      className="cursor-pointer text-left text-sm text-gray-400 transition-colors hover:text-emerald-400"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="mx-auto max-w-7xl px-4 py-5 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center gap-2 text-center sm:flex-row sm:justify-between sm:text-left">
            <p className="text-xs text-gray-500">
              Copyright &copy; {new Date().getFullYear()} NFD sàrl - AQUABION.
              Tous droits réservés.
            </p>
            <p className="text-xs text-gray-500">
              SIRET : 517 423 935 00018 &nbsp;|&nbsp; TVA : FR23 517423935
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
