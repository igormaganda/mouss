'use client';

import { useMemo } from 'react';
import { legalContent } from '@/lib/legal-content';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';

interface LegalModalsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  page: string;
}

type LegalPage = {
  title: string;
  sections: readonly {
    heading: string;
    content: string;
  }[];
  lastUpdated?: string;
};

function getLegalPage(page: string): LegalPage | null {
  switch (page) {
    case 'mentions-legales':
      return legalContent.mentionsLegales;
    case 'confidentialite':
      return legalContent.politiqueConfidentialite;
    case 'cgv':
      return legalContent.cgv;
    case 'cookies':
      return legalContent.cookies;
    default:
      return null;
  }
}

export default function LegalModals({
  open,
  onOpenChange,
  page,
}: LegalModalsProps) {
  const legalPage = useMemo(() => getLegalPage(page), [page]);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="w-full sm:max-w-xl lg:max-w-2xl"
      >
        <SheetHeader className="border-b border-gray-100 pb-4">
          <SheetTitle className="text-lg text-gray-900">
            {legalPage?.title ?? 'Informations légales'}
          </SheetTitle>
          {legalPage && 'lastUpdated' in legalPage && legalPage.lastUpdated && (
            <SheetDescription className="text-xs text-gray-400">
              Dernière mise à jour : {legalPage.lastUpdated}
            </SheetDescription>
          )}
        </SheetHeader>

        {legalPage ? (
          <ScrollArea className="h-[calc(100vh-5rem)]">
            <div className="px-4 pb-8 pt-6 sm:px-6">
              {legalPage.sections.map((section, index) => (
                <section key={index} className="mb-8 last:mb-0">
                  <h2 className="mb-3 text-base font-semibold text-gray-800">
                    {section.heading}
                  </h2>
                  <p className="whitespace-pre-line text-sm leading-relaxed text-gray-600">
                    {section.content}
                  </p>
                  {index < legalPage.sections.length - 1 && (
                    <hr className="mt-6 border-gray-100" />
                  )}
                </section>
              ))}
            </div>
          </ScrollArea>
        ) : (
          <div className="flex flex-1 items-center justify-center p-8">
            <p className="text-sm text-gray-400">
              Contenu non disponible.
            </p>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
