import type { Metadata } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AQUABION® - Système Anti-Calcaire Écologique | Traitement de l'Eau sans Sel",
  description:
    "AQUABION® est un système anti-calcaire breveté, écologique et sans entretien. Protégez votre maison, économisez l'énergie et préservez vos installations avec notre technologie galvanique unique.",
  keywords: [
    "anti calcaire",
    "traitement eau",
    "aquabion",
    "adoucisseur écologique",
    "anti tartre",
    "calcaire",
    "économie énergie",
    "protection canalisations",
    "traitement eau sans sel",
    "alternative adoucisseur",
  ],
  authors: [{ name: "NFD sàrl - AQUABION" }],
    icons: {
    icon: "https://aquabion-distribution.com/img/logo-aquabion.png",
  },
  openGraph: {
    title: "AQUABION® - Système Anti-Calcaire Écologique",
    description:
      "Technologie brevetée pour traiter le calcaire sans sel, sans électricité, sans produits chimiques. Solution écologique pour votre maison.",
    type: "website",
    siteName: "AQUABION®",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://images.unsplash.com" />
        <link rel="preconnect" href="https://aquabion-distribution.com" />
      </head>
      <body className={`${geistSans.variable} antialiased bg-background text-foreground`}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
