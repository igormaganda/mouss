'use client';

import { useState } from 'react';
import Header from '@/components/aquabion/header';
import Hero from '@/components/aquabion/hero';
import Benefits from '@/components/aquabion/benefits';
import Technology from '@/components/aquabion/technology';
import Simulator from '@/components/aquabion/simulator';
import Products from '@/components/aquabion/products';
import Partners from '@/components/aquabion/partners';
import CTA from '@/components/aquabion/cta';
import Footer from '@/components/aquabion/footer';
import CookieConsent from '@/components/aquabion/cookie-consent';
import LegalModals from '@/components/aquabion/legal-modals';

export default function Home() {
  const [legalPage, setLegalPage] = useState<string | null>(null);
  const [legalOpen, setLegalOpen] = useState(false);

  const handleOpenLegal = (page: string) => {
    setLegalPage(page);
    setLegalOpen(true);
  };

  const handleCloseLegal = (open: boolean) => {
    setLegalOpen(open);
    if (!open) {
      setLegalPage(null);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <Benefits />
        <Technology />
        <Simulator />
        <Products />
        <Partners />
        <CTA />
      </main>
      <Footer onOpenLegal={handleOpenLegal} />
      <CookieConsent />
      <LegalModals
        open={legalOpen}
        onOpenChange={handleCloseLegal}
        page={legalPage || ''}
      />
    </div>
  );
}
