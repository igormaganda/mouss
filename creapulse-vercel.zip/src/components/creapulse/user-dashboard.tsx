'use client'

import { useState, useRef, useCallback, useEffect } from 'react'
import { motion } from 'framer-motion'
import { useAppStore } from '@/hooks/use-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Checkbox } from '@/components/ui/checkbox'
import { Alert, AlertDescription } from '@/components/ui/alert'
import KiviatChart from './kiviat-chart'
import SwipeGame from './swipe-game'
import ScaleChangePanel from './scale-change-panel'
import StrategyPanel from './strategy-panel'
import FinancingPanel from './financing-panel'
import TriptychSwipe from './triptych-swipe'
import RiasecQuiz from './riasec-quiz'
import MessagingPanel from './messaging-panel'
import AiAssistantPanel from './ai-assistant-panel'
import AgendaPanel from './agenda-panel'
import BpQuestionnaire from './bp-questionnaire'
import BpOverview from './bp-overview'
import BpMarketDashboard from './bp-market-dashboard'
import BpCanvas from './bp-canvas'
import BpFinancials from './bp-financials'
import BpPitch from './bp-pitch'
import BpRadar from './bp-radar'
import BpGuides from './bp-guides'
import {
  User,
  FileSearch,
  Compass,
  Briefcase,
  LayoutDashboard,
  Trophy,
  Target,
  Clock,
  TrendingUp,
  Upload,
  ArrowRight,
  CheckCircle2,
  Circle,
  Loader2,
  Sparkles,
  Heart,
  Scale,
  Building2,
  ShoppingCart,
  Landmark,
  AlertTriangle,
  Calculator,
  Lightbulb,
  Star,
  FolderOpen,
  FolderPlus,
  FileText,
  FileSpreadsheet,
  FileImage,
  File,
  Trash2,
  ChevronRight,
  ChevronLeft,
  Plus,
  Download,
  Edit3,
  X,
  Save,
  Users,
  Globe,
  BarChart3,
  Tag,
  Gamepad2,
  MessageCircle,
  Calendar,
  ClipboardList,
  Search,
  LayoutTemplate,
  Presentation,
  Radar,
  BookMarked,
  BookOpen,
  type LucideIcon,
} from 'lucide-react'

const fadeIn = {
  hidden: { opacity: 0, y: 12 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
}

const stagger = {
  visible: { transition: { staggerChildren: 0.06 } },
}

// Simple skeleton component
function Skeleton({ className }: { className?: string }) {
  return <div className={`animate-pulse rounded-lg bg-gray-200 ${className || ''}`} />
}

// Helper to safely fetch JSON
async function fetchJson<T>(url: string, fallback: T): Promise<T> {
  try {
    const res = await fetch(url)
    if (!res.ok) return fallback
    return await res.json()
  } catch {
    return fallback
  }
}

// ====================== PROFIL TAB ======================
function ProfilTab() {
  const userId = useAppStore((s) => s.userId)
  const userName = useAppStore((s) => s.userName)
  const [loading, setLoading] = useState(!!userId)
  const [profileData, setProfileData] = useState<{
    progressPercent: number
    modulesCompleted: number
    totalModules: number
    averageScore: number
    evolution: { month: string; score: number; modulesCompleted: number }[]
    userCreatedAt: string | null
    userRole: string | null
    activity: { text: string; time: string; type: string }[]
  } | null>(null)

  useEffect(() => {
    if (!userId) return
    let cancelled = false

    const load = async () => {
      setLoading(true)
      // Fetch user progress
      const progress = await fetchJson<{
        kpis: { modulesCompleted: number; totalModules: number; progressPercent: number; averageScore: number }
        evolution: { month: string; score: number; modulesCompleted: number }[]
      }>(`/api/dashboard/user-progress?userId=${encodeURIComponent(userId)}`, null)

      // Fetch user profile for createdAt and role
      const userRes = await fetchJson<{ user: { createdAt: string; role: string } }>(
        `/api/users/${encodeURIComponent(userId)}`, null
      )

      if (cancelled) return

      // Compute trend from last 2 months of evolution
      const evolution = progress?.evolution || []
      let trend = '—'
      if (evolution.length >= 2) {
        const last = evolution[evolution.length - 1]
        const prev = evolution[evolution.length - 2]
        if (prev.score > 0) {
          const pct = Math.round(((last.score - prev.score) / prev.score) * 100)
          trend = pct >= 0 ? `+${pct}%` : `${pct}%`
        } else if (last.score > 0) {
          trend = '+100%'
        }
      }

      // Compute active days from createdAt
      let activeDays = 0
      const createdAt = userRes?.user?.createdAt
      if (createdAt) {
        activeDays = Math.max(1, Math.ceil((Date.now() - new Date(createdAt).getTime()) / (1000 * 60 * 60 * 24)))
      }

      // Build activity from modules
      const activity = [
        ...(progress ? [{ text: 'Progression du parcours mise à jour', time: "Aujourd'hui", type: 'success' }] : []),
        { text: `${progress?.kpis.modulesCompleted || 0} module(s) complété(s) sur ${progress?.kpis.totalModules || 0}`, time: 'Parcours', type: 'info' },
      ]

      setProfileData({
        progressPercent: progress?.kpis.progressPercent ?? 0,
        modulesCompleted: progress?.kpis.modulesCompleted ?? 0,
        totalModules: progress?.kpis.totalModules ?? 0,
        averageScore: progress?.kpis.averageScore ?? 0,
        evolution,
        userCreatedAt: createdAt || null,
        userRole: userRes?.user?.role || null,
        activity,
      })
      setLoading(false)
    }

    load()
    return () => { cancelled = true }
  }, [userId])

  // Compute values
  const activeDays = profileData?.userCreatedAt
    ? Math.max(1, Math.ceil((Date.now() - new Date(profileData.userCreatedAt).getTime()) / (1000 * 60 * 60 * 24)))
    : '—'

  const trend = (() => {
    const evolution = profileData?.evolution || []
    if (evolution.length >= 2) {
      const last = evolution[evolution.length - 1]
      const prev = evolution[evolution.length - 2]
      if (prev.score > 0) {
        const pct = Math.round(((last.score - prev.score) / prev.score) * 100)
        return pct >= 0 ? `+${pct}%` : `${pct}%`
      } else if (last.score > 0) {
        return '+100%'
      }
    }
    return '—'
  })()

  const profileStats = [
    { label: 'Jours actifs', value: String(activeDays), icon: Clock },
    { label: 'Modules complétés', value: `${profileData?.modulesCompleted ?? 0}/${profileData?.totalModules ?? 0}`, icon: Trophy },
    { label: 'Score global', value: `${profileData?.averageScore ?? 0}/100`, icon: Target },
    { label: 'Tendance', value: trend, icon: TrendingUp },
  ]

  const roleLabel = profileData?.userRole === 'counselor' ? 'Conseiller' : profileData?.userRole === 'admin' ? 'Administrateur' : 'Porteur de projet'
  const formattedDate = profileData?.userCreatedAt
    ? new Date(profileData.userCreatedAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })
    : ''
  const progressPercent = profileData?.progressPercent ?? 0
  const remainingModules = (profileData?.totalModules ?? 0) - (profileData?.modulesCompleted ?? 0)

  if (loading) {
    return (
      <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
        <motion.div variants={fadeIn}>
          <Card className="border-0 shadow-sm"><CardContent className="p-6"><div className="flex items-center gap-6"><Skeleton className="w-20 h-20 rounded-full" /><div className="flex-1 space-y-3"><Skeleton className="h-5 w-48" /><Skeleton className="h-4 w-72" /><Skeleton className="h-2.5 w-full" /></div></div></CardContent></Card>
        </motion.div>
        <motion.div variants={stagger} className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <motion.div key={i} variants={fadeIn}><Card className="border-0 shadow-sm"><CardContent className="p-4 space-y-2"><Skeleton className="w-5 h-5" /><Skeleton className="h-8 w-16" /><Skeleton className="h-3 w-24" /></CardContent></Card></motion.div>
          ))}
        </motion.div>
      </motion.div>
    )
  }

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <Avatar className="w-20 h-20">
                <AvatarFallback className="bg-gradient-to-br from-emerald-400 to-teal-500 text-white text-2xl font-bold">
                  {userName.split(' ').map((n) => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="text-center sm:text-left flex-1">
                <h3 className="text-xl font-bold text-gray-900">{userName}</h3>
                <p className="text-sm text-gray-500 mb-4">
                  {roleLabel}{formattedDate ? ` · Inscrit(e) le ${formattedDate}` : ''}
                </p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 font-medium">Progression du parcours</span>
                    <span className="text-emerald-600 font-semibold">{Math.round(progressPercent)}%</span>
                  </div>
                  <Progress value={progressPercent} className="h-2.5 bg-gray-100" />
                  <p className="text-xs text-gray-400">
                    {remainingModules > 0
                      ? `${remainingModules} module(s) restant(s) pour compléter votre diagnostic`
                      : 'Parcours complété !'}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={stagger} className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {profileStats.map((stat) => (
          <motion.div key={stat.label} variants={fadeIn}>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <stat.icon className="w-5 h-5 text-emerald-500 mb-2" />
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.label}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Activité récente</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {(profileData?.activity || []).length > 0 ? (
              profileData!.activity.map((activity, i) => (
                <div key={i} className="flex items-start gap-3 py-2">
                  <div
                    className={`w-2 h-2 rounded-full mt-2 shrink-0 ${
                      activity.type === 'success' ? 'bg-emerald-500' : activity.type === 'info' ? 'bg-violet-500' : 'bg-gray-300'
                    }`}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-700">{activity.text}</p>
                    <p className="text-xs text-gray-400">{activity.time}</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-400 py-4 text-center">Aucune activité récente</p>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

// ====================== BILAN TAB ======================
function BilanTab() {
  const userId = useAppStore((s) => s.userId)
  const [loading, setLoading] = useState(!!userId)
  const [kiviatData, setKiviatData] = useState<Array<{ label: string; value: number; maxValue: number }>>([])

  useEffect(() => {
    if (!userId) return
    let cancelled = false

    const load = async () => {
      setLoading(true)
      const results = await fetchJson<Array<{ dimension: string; value: number; maxValue: number }>>(
        `/api/modules/kiviat?userId=${encodeURIComponent(userId)}`, []
      )
      if (cancelled) return
      if (results.length > 0) {
        setKiviatData(results.map((r) => ({ label: r.dimension, value: r.value, maxValue: r.maxValue })))
      } else {
        setKiviatData([])
      }
      setLoading(false)
    }
    load()
    return () => { cancelled = true }
  }, [userId])

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <CardTitle className="text-base">Jeu des Pépites</CardTitle>
            </div>
            <p className="text-sm text-gray-500 mt-1">Découvrez vos soft skills en glissant les cartes.</p>
          </CardHeader>
          <CardContent><SwipeGame /></CardContent>
        </Card>
      </motion.div>

      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <FileSearch className="w-5 h-5 text-emerald-500" />
              <CardTitle className="text-base">Diagramme de Kiviat</CardTitle>
            </div>
            <p className="text-sm text-gray-500 mt-1">Visualisation de vos compétences entrepreneuriales sur 6 dimensions.</p>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            {loading ? (
              <div className="flex flex-col items-center py-12 space-y-4">
                <Skeleton className="w-64 h-64 rounded-full" />
                <p className="text-sm text-gray-400">Chargement des données...</p>
              </div>
            ) : kiviatData.length > 0 ? (
              <>
                <KiviatChart data={kiviatData} />
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-6 w-full max-w-md">
                  {kiviatData.map((d) => (
                    <div key={d.label} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                      <span className="text-xs text-gray-600">{d.label}</span>
                      <Badge variant="secondary" className="text-xs bg-emerald-50 text-emerald-700">{d.value}/{d.maxValue}</Badge>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center py-12 text-center">
                <FileSearch className="w-12 h-12 text-gray-300 mb-3" />
                <p className="text-sm text-gray-500">Aucune donnée Kiviat disponible.</p>
                <p className="text-xs text-gray-400 mt-1">Complétez le Jeu des Pépites pour générer votre diagramme.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

// ====================== RIASEC TAB ======================
const RIASEC_META: Record<string, { title: string; color: string; barColor: string; description: string }> = {
  R: { title: 'Réaliste', color: 'bg-amber-100 text-amber-700 border-amber-200', barColor: 'bg-amber-500', description: 'Préfère les activités concrètes et manuelles.' },
  I: { title: 'Investigateur', color: 'bg-blue-100 text-blue-700 border-blue-200', barColor: 'bg-blue-500', description: "Attiré par la recherche, l'analyse et l'observation." },
  A: { title: 'Artistique', color: 'bg-rose-100 text-rose-700 border-rose-200', barColor: 'bg-rose-500', description: "Créatif et imaginatif. Valorise l'originalité." },
  S: { title: 'Social', color: 'bg-emerald-100 text-emerald-700 border-emerald-200', barColor: 'bg-emerald-500', description: "Centré sur l'humain et les relations." },
  E: { title: 'Entrepreneurial', color: 'bg-violet-100 text-violet-700 border-violet-200', barColor: 'bg-violet-500', description: 'Persuasif avec un leadership naturel.' },
  C: { title: 'Conventionnel', color: 'bg-sky-100 text-sky-700 border-sky-200', barColor: 'bg-sky-500', description: 'Organisé et méthodique.' },
}

function RiasecTab() {
  const userId = useAppStore((s) => s.userId)
  const [loading, setLoading] = useState(!!userId)
  const [riasecProfiles, setRiasecProfiles] = useState<Array<{
    type: string; title: string; color: string; barColor: string; progress: number; description: string
  }>>([])
  const [selectedKeywords, setSelectedKeywords] = useState<string[]>([])

  useEffect(() => {
    if (!userId) return
    let cancelled = false

    const load = async () => {
      setLoading(true)
      // Fetch RIASEC results
      const riasecRes = await fetchJson<Array<{ profileType: string; score: number; isDominant: boolean }>>(
        `/api/modules/riasec?userId=${encodeURIComponent(userId)}`, []
      )

      // Fetch keyword selections
      const keywordsRes = await fetchJson<Array<{ keyword: string; selected: boolean }>>(
        `/api/modules/keywords?userId=${encodeURIComponent(userId)}`, []
      )

      if (cancelled) return

      if (riasecRes.length > 0) {
        setRiasecProfiles(riasecRes.map((r) => ({
          type: r.profileType,
          title: RIASEC_META[r.profileType]?.title || r.profileType,
          color: RIASEC_META[r.profileType]?.color || 'bg-gray-100 text-gray-700 border-gray-200',
          barColor: RIASEC_META[r.profileType]?.barColor || 'bg-gray-500',
          progress: r.score,
          description: RIASEC_META[r.profileType]?.description || '',
        })))
      } else {
        // Show all RIASEC profiles with 0
        setRiasecProfiles(
          Object.entries(RIASEC_META).map(([type, meta]) => ({
            type,
            title: meta.title,
            color: meta.color,
            barColor: meta.barColor,
            progress: 0,
            description: meta.description,
          }))
        )
      }

      // Set initial selected keywords from API
      const selected = keywordsRes.filter((k) => k.selected).map((k) => k.keyword)
      setSelectedKeywords(selected)
      setLoading(false)
    }
    load()
    return () => { cancelled = true }
  }, [userId])

  const keywords = [
    'Innovation', 'Management', 'Finance', 'Marketing', 'Technologie',
    'RH', 'Écologie', 'Commerce', 'Design', 'Data', 'Handicap',
    'Social', 'International', 'Agroalimentaire', 'Santé', 'BTP',
    'Éducation', 'Culture', 'Tourisme', 'Digital',
  ]

  const toggleKeyword = useCallback((kw: string) => {
    setSelectedKeywords((prev) => {
      const next = prev.includes(kw) ? prev.filter((k) => k !== kw) : [...prev, kw]
      // Persist keyword selections to API
      if (userId) {
        const selections = keywords.map((k) => ({ keyword: k, selected: next.includes(k) }))
        fetch('/api/modules/keywords', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId, selections }),
        }).catch(() => {})
      }
      return next
    })
  }, [userId])

  if (loading) {
    return (
      <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
        <motion.div variants={fadeIn}>
          <Card className="border-0 shadow-sm"><CardContent className="p-6"><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">{[1, 2, 3, 4, 5, 6].map((i) => (<Skeleton key={i} className="h-32 rounded-xl" />))}</div></CardContent></Card>
        </motion.div>
        <motion.div variants={fadeIn}><Card className="border-0 shadow-sm"><CardContent className="p-6"><div className="flex flex-wrap gap-2">{[1, 2, 3, 4, 5].map((i) => (<Skeleton key={i} className="h-9 w-28 rounded-full" />))}</div></CardContent></Card></motion.div>
      </motion.div>
    )
  }

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Compass className="w-5 h-5 text-violet-500" />
              <CardTitle className="text-base">Profils RIASEC</CardTitle>
            </div>
            <p className="text-sm text-gray-500 mt-1">Découvrez votre profil dominant parmi les 6 dimensions RIASEC.</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {riasecProfiles.map((profile) => (
                <motion.div key={profile.type} whileHover={{ y: -2 }} className={`p-4 rounded-xl border ${profile.color} transition-all`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold">{profile.type}</span>
                      <span className="text-sm font-semibold">{profile.title}</span>
                    </div>
                    <span className="text-sm font-bold">{profile.progress}%</span>
                  </div>
                  <div className="w-full bg-white/50 rounded-full h-2 mb-3">
                    <motion.div initial={{ width: 0 }} animate={{ width: `${profile.progress}%` }} transition={{ duration: 0.8, delay: 0.2 }} className={`h-2 rounded-full ${profile.barColor}`} />
                  </div>
                  <p className="text-xs leading-relaxed opacity-80">{profile.description}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Loterie de mots-clés</CardTitle>
            <p className="text-sm text-gray-500 mt-1">Sélectionnez les domaines qui vous intéressent.</p>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {keywords.map((kw) => {
                const isSelected = selectedKeywords.includes(kw)
                return (
                  <motion.button key={kw} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => toggleKeyword(kw)}
                    className={`px-3.5 py-2 rounded-full text-sm font-medium transition-all border ${isSelected ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm' : 'bg-white text-gray-600 border-gray-200 hover:border-emerald-300'}`}>
                    {kw}
                  </motion.button>
                )
              })}
            </div>
            {selectedKeywords.length > 0 && (
              <p className="text-sm text-gray-500 mt-4"><span className="font-semibold text-emerald-600">{selectedKeywords.length}</span> mot(s)-clé(s) sélectionné(s)</p>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

// ====================== MOTIVATIONS TAB ======================
function MotivationsTab() {
  const userId = useAppStore((s) => s.userId)
  const [responses, setResponses] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState(!!userId)
  const [initialLoaded, setInitialLoaded] = useState(false)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const motivations = [
    { id: 'independence', label: "Indépendance et autonomie", description: "Être mon propre patron, gérer mon temps librement", icon: User },
    { id: 'impact', label: "Impact positif", description: "Créer de la valeur pour la société et mon territoire", icon: Heart },
    { id: 'income', label: "Revenus financiers", description: "Améliorer ma situation financière personnelle", icon: TrendingUp },
    { id: 'passion', label: "Passion et réalisation", description: "Transformer une passion en activité professionnelle", icon: Sparkles },
    { id: 'challenge', label: "Défi personnel", description: "Me dépasser, apprendre et grandir en tant qu'entrepreneur", icon: Target },
    { id: 'legacy', label: "Transmission", description: "Bâtir quelque chose de durable à transmettre", icon: Building2 },
  ]

  // Fetch existing motivations on mount
  useEffect(() => {
    if (!userId) return
    let cancelled = false

    const load = async () => {
      setLoading(true)
      const result = await fetchJson<{ data: Record<string, number> } | null>(
        `/api/modules/motivations?userId=${encodeURIComponent(userId)}`, null
      )
      if (cancelled) return
      if (result?.data) {
        setResponses(result.data)
      } else {
        // Start with all 0s
        const zeros: Record<string, number> = {}
        motivations.forEach((m) => { zeros[m.id] = 0 })
        setResponses(zeros)
      }
      setInitialLoaded(true)
      setLoading(false)
    }
    load()
    return () => { cancelled = true }
  }, [userId])

  const handleSetResponse = useCallback((id: string, value: number) => {
    setResponses((prev) => {
      const next = { ...prev, [id]: value }
      // Debounced save
      if (userId && initialLoaded) {
        if (debounceRef.current) clearTimeout(debounceRef.current)
        debounceRef.current = setTimeout(() => {
          fetch('/api/modules/motivations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId, motivations: next }),
          }).catch(() => {})
        }, 800)
      }
      return next
    })
  }, [userId, initialLoaded])

  if (loading) {
    return (
      <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
        <motion.div variants={fadeIn}>
          <Card className="border-0 shadow-sm"><CardContent className="p-6 space-y-4">{[1, 2, 3, 4, 5, 6].map((i) => (<Skeleton key={i} className="h-24 rounded-xl" />))}</CardContent></Card>
        </motion.div>
      </motion.div>
    )
  }

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-rose-500" />
              <CardTitle className="text-base">Vos motivations entrepreneuriales</CardTitle>
            </div>
            <p className="text-sm text-gray-500 mt-1">Évaluez l'importance de chaque motivation sur une échelle de 1 à 5.</p>
          </CardHeader>
          <CardContent className="space-y-4">
            {motivations.map((m) => (
              <div key={m.id} className="p-4 rounded-xl border border-gray-100">
                <div className="flex items-center gap-3 mb-3">
                  <m.icon className="w-5 h-5 text-rose-500" />
                  <div>
                    <p className="font-semibold text-sm text-gray-900">{m.label}</p>
                    <p className="text-xs text-gray-500">{m.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button key={s} onClick={() => handleSetResponse(m.id, s)}
                      className={`flex-1 h-9 rounded-lg text-xs font-semibold transition-all ${s <= (responses[m.id] || 0) ? 'bg-rose-500 text-white' : 'bg-gray-100 text-gray-400 hover:bg-gray-200'}`}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

// ====================== JURIDIQUE TAB ======================
interface SimulationComparison {
  id: string
  name: string
  chargesSociales: number
  resultatNet: number
  margeNette: number
  isBest: boolean
}

interface SimulationData {
 selected: {
    regime: { id: string; name: string }
    sorties: { chargesSociales: number; chargesOperatoires: number; impotEstime: number; totalCharges: number }
    resultatNet: number
    margeNette: number
    avantagesFiscaux: string[]
    recommandation: string
    alertes: string[]
  }
  comparison: SimulationComparison[]
  bestRegime: { id: string; name: string }
}

function JuridiqueTab() {
  const [selectedStatus, setSelectedStatus] = useState<string | null>('sarl')
  const [caAnnuel, setCaAnnuel] = useState(50000)
  const [chargesReelles, setChargesReelles] = useState(10000)
  const [versementLiberatoire, setVersementLiberatoire] = useState(false)
  const [simulating, setSimulating] = useState(false)
  const [simulationData, setSimulationData] = useState<SimulationData | null>(null)
  const [simulationError, setSimulationError] = useState<string | null>(null)

  const statuses = [
    { id: 'auto-entrepreneur', name: 'Auto-entrepreneur', capital: 'Pas de capital minimum', charges: '~22% CA', avantages: ['Simple et rapide', 'Charges sociales réduites', 'Comptabilité simplifiée'], inconvenients: ['Plafond de CA', 'Pas de déduction des charges', 'Statut social limité'], color: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
    { id: 'sarl', name: 'SARL / EURL', capital: '1 EUR minimum', charges: '~45% bénéfice', avantages: ['Protection du patrimoine', 'Crédibilité accrue', 'Flexibilité'], inconvenients: ['Charges sociales élevées', 'Formalités complexes', 'Rédaction statuts obligatoire'], color: 'bg-blue-100 text-blue-700 border-blue-200' },
    { id: 'sas', name: 'SAS / SASU', capital: '1 EUR minimum', charges: '~50% rémunération', avantages: ['Grande flexibilité', 'Statut assimilé-salarié', 'Facilité de levée de fonds'], inconvenients: ['Charges sociales plus élevées', 'Formalités lourdes', 'Expert-comptable recommandé'], color: 'bg-violet-100 text-violet-700 border-violet-200' },
    { id: 'association', name: 'Association (loi 1901)', capital: 'Pas de capital', charges: 'Variable', avantages: ['But non lucratif', 'Subventions possibles', 'Agréments disponibles'], inconvenients: ['Pas de partage bénéfices', 'Gouvernance contraignante', 'Comptabilité spécifique'], color: 'bg-amber-100 text-amber-700 border-amber-200' },
  ]

  const current = statuses.find(s => s.id === selectedStatus)

  const runSimulation = useCallback(async () => {
    if (!selectedStatus || caAnnuel <= 0) return
    setSimulating(true)
    setSimulationError(null)
    try {
      const res = await fetch('/api/juridique/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caAnnuel,
          chargesReelles,
          regimeId: selectedStatus,
          versementLiberatoire: selectedStatus === 'auto-entrepreneur' ? versementLiberatoire : undefined,
        }),
      })
      if (!res.ok) {
        const err = await res.json()
        setSimulationError(err.error || 'Erreur lors de la simulation')
        return
      }
      const data = await res.json()
      setSimulationData(data)
    } catch {
      setSimulationError('Erreur réseau. Veuillez réessayer.')
    } finally {
      setSimulating(false)
    }
  }, [selectedStatus, caAnnuel, chargesReelles, versementLiberatoire])

  // Auto-trigger simulation when regime changes
  const handleStatusChange = (id: string) => {
    setSelectedStatus(id)
    setSimulationError(null)
  }

  const formatEur = (n: number) => n.toLocaleString('fr-FR') + ' EUR'

  const regimeColorMap: Record<string, string> = {
    'auto-entrepreneur': 'border-emerald-400 bg-emerald-50',
    'sar': 'border-blue-400 bg-blue-50',
    'sas': 'border-violet-400 bg-violet-50',
    'association': 'border-amber-400 bg-amber-50',
  }

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
      {/* Existing regime comparison card */}
      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Scale className="w-5 h-5 text-blue-500" />
              <CardTitle className="text-base">Choix du statut juridique</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
              {statuses.map((s) => (
                <button key={s.id} onClick={() => handleStatusChange(s.id)}
                  className={`p-4 rounded-xl border-2 text-center transition-all ${selectedStatus === s.id ? s.color : 'bg-white border-gray-100 hover:border-gray-200'}`}>
                  <p className="font-semibold text-sm">{s.name}</p>
                  <p className="text-[10px] opacity-70 mt-1">{s.capital}</p>
                </button>
              ))}
            </div>
            {current && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                  <p className="font-semibold text-sm text-emerald-800 mb-2">Avantages</p>
                  <div className="space-y-1.5">{current.avantages.map((a, i) => <p key={i} className="text-sm text-emerald-700 flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />{a}</p>)}</div>
                </div>
                <div className="p-4 rounded-xl bg-red-50 border border-red-200">
                  <p className="font-semibold text-sm text-red-800 mb-2">Points de vigilance</p>
                  <div className="space-y-1.5">{current.inconvenients.map((d, i) => <p key={i} className="text-sm text-red-700 flex items-center gap-2"><Circle className="w-3.5 h-3.5 text-red-400" />{d}</p>)}</div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Simulation panel */}
      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Calculator className="w-5 h-5 text-teal-500" />
              <CardTitle className="text-base">Simulateur de charges</CardTitle>
            </div>
            <p className="text-sm text-gray-500 mt-1">Estimez l&apos;impact financier de chaque régime juridique selon votre activité.</p>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-medium text-gray-600">CA annuel estimé (EUR)</label>
                <Input type="number" min={0} value={caAnnuel} onChange={(e) => setCaAnnuel(Number(e.target.value))} className="rounded-xl" placeholder="ex: 50000" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-gray-600">Charges réelles annuelles (EUR)</label>
                <Input type="number" min={0} value={chargesReelles} onChange={(e) => setChargesReelles(Number(e.target.value))} className="rounded-xl" placeholder="ex: 10000" />
              </div>
            </div>

            {/* Versement libératoire checkbox (only for auto-entrepreneur) */}
            {selectedStatus === 'auto-entrepreneur' && (
              <div className="flex items-center gap-3 p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                <Checkbox
                  id="versement-lib"
                  checked={versementLiberatoire}
                  onCheckedChange={(checked) => setVersementLiberatoire(checked === true)}
                />
                <label htmlFor="versement-lib" className="text-sm text-emerald-800 cursor-pointer select-none">
                  <span className="font-medium">Versement libératoire</span>
                  <span className="text-xs text-emerald-600 block">IR forfaitaire à 1,7% du CA (services)</span>
                </label>
              </div>
            )}

            {/* Simulate button */}
            <div className="flex items-center gap-3">
              <Button
                onClick={runSimulation}
                disabled={simulating || caAnnuel <= 0 || !selectedStatus}
                className="rounded-xl bg-teal-600 hover:bg-teal-700 text-white"
              >
                {simulating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Calculator className="w-4 h-4 mr-2" />}
                {simulating ? 'Calcul en cours...' : 'Simuler'}
              </Button>
              {selectedStatus && (
                <span className="text-xs text-gray-400">
                  Régime sélectionné : <span className="font-medium text-gray-600">{statuses.find(s => s.id === selectedStatus)?.name}</span>
                </span>
              )}
            </div>

            {/* Error */}
            {simulationError && (
              <Alert variant="destructive">
                <AlertTriangle className="w-4 h-4" />
                <AlertDescription>{simulationError}</AlertDescription>
              </Alert>
            )}

            {/* Results */}
            {simulationData && (
              <div className="space-y-4">
                {/* Best regime banner */}
                <div className="flex items-center gap-3 p-4 rounded-xl bg-teal-50 border border-teal-200">
                  <Star className="w-5 h-5 text-teal-600 shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-teal-800">
                      Régime recommandé : {simulationData.bestRegime.name}
                    </p>
                    <p className="text-xs text-teal-600 mt-0.5">
                      {simulationData.selected.recommandation}
                    </p>
                  </div>
                </div>

                {/* Alerts */}
                {simulationData.selected.alertes.length > 0 && (
                  <div className="space-y-2">
                    {simulationData.selected.alertes.map((alerte, i) => (
                      <Alert key={i} className="border-amber-200 bg-amber-50">
                        <AlertTriangle className="w-4 h-4 text-amber-600" />
                        <AlertDescription className="text-amber-800 text-sm">{alerte}</AlertDescription>
                      </Alert>
                    ))}
                  </div>
                )}

                {/* Comparison table - horizontal scroll on mobile */}
                <div className="overflow-x-auto -mx-1">
                  <div className="min-w-[600px]">
                    <table className="w-full text-sm">
                      <thead>
                        <tr>
                          <th className="text-left py-3 px-3 font-medium text-gray-500 text-xs uppercase tracking-wider">Régime</th>
                          <th className="text-right py-3 px-3 font-medium text-gray-500 text-xs uppercase tracking-wider">Charges sociales</th>
                          <th className="text-right py-3 px-3 font-medium text-gray-500 text-xs uppercase tracking-wider">Résultat net</th>
                          <th className="text-right py-3 px-3 font-medium text-gray-500 text-xs uppercase tracking-wider">Marge nette</th>
                          <th className="text-center py-3 px-3 font-medium text-gray-500 text-xs uppercase tracking-wider"></th>
                        </tr>
                      </thead>
                      <tbody>
                        {simulationData.comparison.map((regime) => (
                          <tr
                            key={regime.id}
                            className={`border-t border-gray-100 transition-colors ${
                              regime.isBest
                                ? 'bg-teal-50/60'
                                : selectedStatus === regime.id
                                  ? 'bg-gray-50'
                                  : ''
                            }`}
                          >
                            <td className="py-3 px-3">
                              <div className="flex items-center gap-2">
                                <span className={`w-2 h-2 rounded-full shrink-0 ${
                                  regime.id === 'auto-entrepreneur' ? 'bg-emerald-500' :
                                  regime.id === 'sar' ? 'bg-blue-500' :
                                  regime.id === 'sas' ? 'bg-violet-500' : 'bg-amber-500'
                                }`} />
                                <span className={`font-medium ${regime.isBest ? 'text-teal-800' : 'text-gray-700'}`}>{regime.name}</span>
                              </div>
                            </td>
                            <td className="py-3 px-3 text-right font-mono text-gray-600">
                              {formatEur(regime.chargesSociales)}
                            </td>
                            <td className="py-3 px-3 text-right font-mono font-semibold text-gray-900">
                              {formatEur(regime.resultatNet)}
                            </td>
                            <td className="py-3 px-3 text-right">
                              <span className={`inline-flex items-center gap-1 font-semibold ${
                                regime.margeNette >= 40 ? 'text-emerald-600' :
                                regime.margeNette >= 25 ? 'text-amber-600' : 'text-red-500'
                              }`}>
                                {regime.margeNette}%
                              </span>
                            </td>
                            <td className="py-3 px-3 text-center">
                              {regime.isBest && (
                                <Badge className="bg-teal-100 text-teal-800 border-teal-300 text-xs font-medium">
                                  Recommandé
                                </Badge>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Recommendations */}
                {simulationData.selected.avantagesFiscaux.length > 0 && (
                  <div className="p-4 rounded-xl bg-blue-50 border border-blue-200">
                    <div className="flex items-center gap-2 mb-3">
                      <Lightbulb className="w-4 h-4 text-blue-600" />
                      <p className="font-semibold text-sm text-blue-800">Recommandations fiscales</p>
                    </div>
                    <div className="space-y-1.5">
                      {simulationData.selected.avantagesFiscaux.map((rec, i) => (
                        <p key={i} className="text-sm text-blue-700 flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 mt-0.5 shrink-0" />
                          {rec}
                        </p>
                      ))}
                    </div>
                  </div>
                )}

                {/* Selected regime detail */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className={`p-4 rounded-xl border-2 ${regimeColorMap[simulationData.selected.regime.id] || 'border-gray-200 bg-gray-50'} text-center`}>
                    <p className="text-lg font-bold text-gray-900">{formatEur(simulationData.selected.sorties.chargesSociales)}</p>
                    <p className="text-[10px] text-gray-500 mt-1">Charges sociales</p>
                  </div>
                  <div className="p-4 rounded-xl border-2 border-gray-200 bg-gray-50 text-center">
                    <p className="text-lg font-bold text-gray-900">{formatEur(simulationData.selected.sorties.impotEstime)}</p>
                    <p className="text-[10px] text-gray-500 mt-1">Impôt estimé</p>
                  </div>
                  <div className="p-4 rounded-xl border-2 border-gray-200 bg-gray-50 text-center">
                    <p className="text-lg font-bold text-gray-900">{formatEur(simulationData.selected.sorties.totalCharges)}</p>
                    <p className="text-[10px] text-gray-500 mt-1">Total des charges</p>
                  </div>
                  <div className="p-4 rounded-xl border-2 border-emerald-300 bg-emerald-50 text-center">
                    <p className="text-lg font-bold text-emerald-600">{formatEur(simulationData.selected.resultatNet)}</p>
                    <p className="text-[10px] text-gray-500 mt-1">Résultat net</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

// ====================== MARCHÉ TAB ======================
interface MarketFolder {
  id: string
  name: string
  color: string
  icon: string
  sortOrder: number
  createdAt: string
  _count?: { documents: number; segments: number }
  segments?: MarketSegment[]
}

interface MarketDocument {
  id: string
  folderId: string
  fileName: string
  fileType: string
  fileSize: number
  fileUrl: string
  category: string
  icon?: string
  fileSizeFormatted?: string
  tags: string[]
  notes?: string | null
  createdAt: string
}

interface MarketSegment {
  id: string
  folderId: string
  name: string
  description?: string | null
  customerType: string
  size?: string | null
  growth?: string | null
  region?: string | null
  priority: string
  status: string
  notes?: string | null
  createdAt: string
}

function DocumentIcon({ category, className }: { category: string; className?: string }) {
  const cls = className || 'w-5 h-5'
  switch (category) {
    case 'pdf': return <FileText className={`${cls} text-red-500`} />
    case 'word': return <FileText className={`${cls} text-blue-500`} />
    case 'spreadsheet': return <FileSpreadsheet className={`${cls} text-emerald-500`} />
    case 'image': return <FileImage className={`${cls} text-violet-500`} />
    default: return <File className={`${cls} text-gray-500`} />
  }
}

function MarcheTab() {
  const userId = useAppStore((s) => s.userId)
  const [loading, setLoading] = useState(!!userId)
  const [folders, setFolders] = useState<MarketFolder[]>([])
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null)
  const [documents, setDocuments] = useState<MarketDocument[]>([])
  const [segments, setSegments] = useState<MarketSegment[]>([])
  const [loadingFolder, setLoadingFolder] = useState(false)
  const [subTab, setSubTab] = useState<'documents' | 'segments'>('documents')

  // New folder dialog
  const [showNewFolder, setShowNewFolder] = useState(false)
  const [newFolderName, setNewFolderName] = useState('')
  const [newFolderColor, setNewFolderColor] = useState('#6366f1')
  const [creatingFolder, setCreatingFolder] = useState(false)

  // Rename folder dialog
  const [renamingFolderId, setRenamingFolderId] = useState<string | null>(null)
  const [renameFolderName, setRenameFolderName] = useState('')

  // New segment dialog
  const [showNewSegment, setShowNewSegment] = useState(false)
  const [newSegment, setNewSegment] = useState({
    name: '', description: '', customerType: 'B2C', size: '', growth: '', region: '', priority: 'medium', notes: '',
  })
  const [creatingSegment, setCreatingSegment] = useState(false)

  // Edit segment dialog
  const [editingSegmentId, setEditingSegmentId] = useState<string | null>(null)
  const [editSegment, setEditSegment] = useState({
    name: '', description: '', customerType: 'B2C', size: '', growth: '', region: '', priority: 'medium', notes: '',
  })

  // Upload state
  const [uploading, setUploading] = useState(false)
  const [isDragOver, setIsDragOver] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const FOLDER_COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#ef4444', '#f97316', '#eab308', '#22c55e', '#06b6d4', '#3b82f6', '#6b7280']

  // Load folders
  useEffect(() => {
    if (!userId) return
    setLoading(true)
    fetch(`/api/market-folders?userId=${encodeURIComponent(userId)}`)
      .then((r) => r.json())
      .then((data) => { setFolders(data.folders || []) })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [userId])

  // Load documents + segments when folder selected
  useEffect(() => {
    if (!selectedFolderId) { setDocuments([]); setSegments([]); return }
    setLoadingFolder(true)
    Promise.all([
      fetch(`/api/market-documents?folderId=${encodeURIComponent(selectedFolderId)}`).then((r) => r.json()),
      fetch(`/api/market-segments?folderId=${encodeURIComponent(selectedFolderId)}`).then((r) => r.json()),
    ])
      .then(([docs, segs]) => {
        setDocuments(docs.documents || [])
        setSegments(segs.segments || [])
      })
      .catch(() => {})
      .finally(() => setLoadingFolder(false))
  }, [selectedFolderId])

  // Create folder
  const handleCreateFolder = async () => {
    if (!userId || !newFolderName.trim()) return
    setCreatingFolder(true)
    try {
      const res = await fetch('/api/market-folders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, name: newFolderName.trim(), color: newFolderColor }),
      })
      const data = await res.json()
      if (data.folder) {
        setFolders((prev) => [...prev, { ...data.folder, _count: { documents: 0, segments: 0 } }])
        setShowNewFolder(false)
        setNewFolderName('')
      }
    } catch { /* silent */ }
    setCreatingFolder(false)
  }

  // Rename folder
  const handleRenameFolder = async () => {
    if (!renamingFolderId || !renameFolderName.trim()) return
    try {
      const res = await fetch('/api/market-folders', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: renamingFolderId, name: renameFolderName.trim() }),
      })
      const data = await res.json()
      if (data.folder) {
        setFolders((prev) => prev.map((f) => f.id === renamingFolderId ? { ...f, name: data.folder.name } : f))
      }
    } catch { /* silent */ }
    setRenamingFolderId(null)
  }

  // Delete folder
  const handleDeleteFolder = async (folderId: string) => {
    if (!confirm('Supprimer ce dossier et tous ses contenus ?')) return
    try {
      await fetch(`/api/market-folders?id=${encodeURIComponent(folderId)}`, { method: 'DELETE' })
      setFolders((prev) => prev.filter((f) => f.id !== folderId))
      if (selectedFolderId === folderId) setSelectedFolderId(null)
    } catch { /* silent */ }
  }

  // Upload file
  const handleUploadFile = async (file: File) => {
    if (!userId || !selectedFolderId) return
    setUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      formData.append('folderId', selectedFolderId)
      formData.append('userId', userId)
      const res = await fetch('/api/market-documents', { method: 'POST', body: formData })
      const data = await res.json()
      if (data.document) {
        setDocuments((prev) => [data.document, ...prev])
      }
    } catch { /* silent */ }
    setUploading(false)
  }

  // Delete document
  const handleDeleteDocument = async (docId: string) => {
    try {
      await fetch(`/api/market-documents?id=${encodeURIComponent(docId)}`, { method: 'DELETE' })
      setDocuments((prev) => prev.filter((d) => d.id !== docId))
    } catch { /* silent */ }
  }

  // Download document
  const handleDownloadDocument = (doc: MarketDocument) => {
    const a = document.createElement('a')
    a.href = doc.fileUrl
    a.download = doc.fileName
    a.click()
  }

  // Create segment
  const handleCreateSegment = async () => {
    if (!userId || !selectedFolderId || !newSegment.name.trim()) return
    setCreatingSegment(true)
    try {
      const res = await fetch('/api/market-segments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, folderId: selectedFolderId, ...newSegment }),
      })
      const data = await res.json()
      if (data.segment) {
        setSegments((prev) => [data.segment, ...prev])
        setShowNewSegment(false)
        setNewSegment({ name: '', description: '', customerType: 'B2C', size: '', growth: '', region: '', priority: 'medium', notes: '' })
      }
    } catch { /* silent */ }
    setCreatingSegment(false)
  }

  // Update segment
  const handleUpdateSegment = async () => {
    if (!editingSegmentId) return
    try {
      const res = await fetch('/api/market-segments', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: editingSegmentId, ...editSegment }),
      })
      const data = await res.json()
      if (data.segment) {
        setSegments((prev) => prev.map((s) => s.id === editingSegmentId ? data.segment : s))
      }
    } catch { /* silent */ }
    setEditingSegmentId(null)
  }

  // Delete segment
  const handleDeleteSegment = async (segId: string) => {
    try {
      await fetch(`/api/market-segments?id=${encodeURIComponent(segId)}`, { method: 'DELETE' })
      setSegments((prev) => prev.filter((s) => s.id !== segId))
    } catch { /* silent */ }
  }

  const selectedFolder = folders.find((f) => f.id === selectedFolderId)
  const priorityColor = (p: string) => {
    switch (p) {
      case 'high': return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
      case 'medium': return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
      default: return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
    }
  }
  const priorityLabel = (p: string) => p === 'high' ? 'Haute' : p === 'medium' ? 'Moyenne' : 'Basse'

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-4">
      {/* ==================== FOLDERS SIDEBAR + CONTENT ==================== */}
      <div className="flex gap-4 min-h-[600px]">

        {/* ─── Left: Folder Library ─── */}
        <motion.div variants={fadeIn} className="w-72 shrink-0 space-y-3">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FolderOpen className="w-4 h-4 text-violet-500" />
                  <CardTitle className="text-sm font-semibold">Bibliothèque de documents</CardTitle>
                </div>
                <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-violet-500 hover:text-violet-700 hover:bg-violet-50 dark:hover:bg-violet-900/20" onClick={() => setShowNewFolder(true)}>
                  <FolderPlus className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-0 space-y-1">
              {loading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => <Skeleton key={i} className="h-10 w-full rounded-lg" />)}
                </div>
              ) : folders.length === 0 ? (
                <div className="text-center py-6">
                  <FolderOpen className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                  <p className="text-xs text-gray-400">Aucun dossier</p>
                  <p className="text-[10px] text-gray-300 mt-0.5">Créez un dossier pour organiser vos documents</p>
                </div>
              ) : (
                folders.map((folder) => (
                  <div
                    key={folder.id}
                    className={`group flex items-center gap-2.5 px-3 py-2.5 rounded-xl cursor-pointer transition-all ${
                      selectedFolderId === folder.id
                        ? 'bg-violet-50 dark:bg-violet-900/20 border border-violet-200 dark:border-violet-800'
                        : 'hover:bg-gray-50 dark:hover:bg-gray-800/50 border border-transparent'
                    }`}
                    onClick={() => { setSelectedFolderId(folder.id); setSubTab('documents') }}
                  >
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: `${folder.color}15` }}>
                      <FolderOpen className="w-4 h-4" style={{ color: folder.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-xs font-medium truncate ${selectedFolderId === folder.id ? 'text-violet-700 dark:text-violet-300' : 'text-gray-700 dark:text-gray-300'}`}>
                        {renamingFolderId === folder.id ? (
                          <input
                            className="w-full bg-white dark:bg-gray-900 border border-violet-300 rounded px-1 py-0.5 text-xs focus:outline-none"
                            value={renameFolderName}
                            onChange={(e) => setRenameFolderName(e.target.value)}
                            onKeyDown={(e) => { if (e.key === 'Enter') handleRenameFolder(); if (e.key === 'Escape') setRenamingFolderId(null) }}
                            onBlur={handleRenameFolder}
                            autoFocus
                            onClick={(e) => e.stopPropagation()}
                          />
                        ) : folder.name}
                      </p>
                      <p className="text-[10px] text-gray-400">
                        {folder._count?.documents || 0} doc. &middot; {folder._count?.segments || 0} seg.
                      </p>
                    </div>
                    {selectedFolderId === folder.id && (
                      <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700"
                          onClick={(e) => { e.stopPropagation(); setRenamingFolderId(folder.id); setRenameFolderName(folder.name) }}
                        >
                          <Edit3 className="w-3 h-3 text-gray-400" />
                        </button>
                        <button
                          className="p-1 rounded hover:bg-red-100 dark:hover:bg-red-900/30"
                          onClick={(e) => { e.stopPropagation(); handleDeleteFolder(folder.id) }}
                        >
                          <Trash2 className="w-3 h-3 text-red-400" />
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* ─── Right: Folder Content ─── */}
        <motion.div variants={fadeIn} className="flex-1 min-w-0">
          {!selectedFolder ? (
            /* Empty state when no folder selected */
            <Card className="border-0 shadow-sm h-full flex items-center justify-center">
              <div className="text-center py-16">
                <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mx-auto mb-4">
                  <FolderOpen className="w-8 h-8 text-gray-300" />
                </div>
                <p className="text-sm font-medium text-gray-500">Sélectionnez un dossier</p>
                <p className="text-xs text-gray-400 mt-1">ou créez-en un pour commencer à organiser vos documents et segments de marché</p>
              </div>
            </Card>
          ) : (
            <div className="space-y-3">
              {/* Folder header */}
              <Card className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${selectedFolder?.color || '#6366f1'}15` }}>
                        <FolderOpen className="w-5 h-5" style={{ color: selectedFolder?.color || '#6366f1' }} />
                      </div>
                      <div>
                        <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">{selectedFolder?.name}</h3>
                        <p className="text-[10px] text-gray-400">{documents.length} document(s) &middot; {segments.length} segment(s) de marché</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button size="sm" variant="ghost" className="h-8 px-3 text-xs rounded-lg" onClick={() => setShowNewSegment(true)}>
                        <Target className="w-3.5 h-3.5 mr-1.5" />
                        Segment
                      </Button>
                    </div>
                  </div>

                  {/* Sub tabs */}
                  <div className="flex gap-1 mt-3 bg-gray-100 dark:bg-gray-800/50 rounded-lg p-0.5">
                    <button
                      className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-md text-xs font-medium transition-all ${
                        subTab === 'documents' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-gray-100' : 'text-gray-500 hover:text-gray-700'
                      }`}
                      onClick={() => setSubTab('documents')}
                    >
                      <FileText className="w-3.5 h-3.5" />
                      Documents ({documents.length})
                    </button>
                    <button
                      className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-md text-xs font-medium transition-all ${
                        subTab === 'segments' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-gray-100' : 'text-gray-500 hover:text-gray-700'
                      }`}
                      onClick={() => setSubTab('segments')}
                    >
                      <Target className="w-3.5 h-3.5" />
                      Segments ({segments.length})
                    </button>
                  </div>
                </CardContent>
              </Card>

              {/* ─── Documents sub-tab ─── */}
              {subTab === 'documents' && (
                <div className="space-y-3">
                  {/* Upload zone */}
                  <Card
                    className={`border-0 shadow-sm transition-colors ${isDragOver ? 'bg-violet-50 dark:bg-violet-900/10 border-2 border-dashed border-violet-300' : ''}`}
                    onDragOver={(e) => { e.preventDefault(); setIsDragOver(true) }}
                    onDragLeave={() => setIsDragOver(false)}
                    onDrop={(e) => {
                      e.preventDefault()
                      setIsDragOver(false)
                      const file = e.dataTransfer.files?.[0]
                      if (file) handleUploadFile(file)
                    }}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <button
                          className={`w-12 h-12 rounded-xl border-2 border-dashed flex items-center justify-center transition-all shrink-0 ${
                            isDragOver ? 'border-violet-400 bg-violet-100 dark:bg-violet-900/30' : 'border-gray-200 dark:border-gray-700 hover:border-violet-300 hover:bg-violet-50 dark:hover:bg-violet-900/20'
                          }`}
                          onClick={() => fileInputRef.current?.click()}
                          disabled={uploading}
                        >
                          {uploading ? <Loader2 className="w-5 h-5 text-violet-500 animate-spin" /> : <Upload className="w-5 h-5 text-gray-400" />}
                        </button>
                        <input
                          ref={fileInputRef}
                          type="file"
                          className="hidden"
                          accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.png,.jpg,.jpeg,.webp,.txt"
                          onChange={(e) => { const file = e.target.files?.[0]; if (file) handleUploadFile(file); e.target.value = '' }}
                        />
                        <div className="flex-1">
                          <p className="text-xs font-medium text-gray-700 dark:text-gray-300">
                            {uploading ? 'Envoi en cours...' : 'Glissez-déposez vos fichiers ici'}
                          </p>
                          <p className="text-[10px] text-gray-400 mt-0.5">
                            PDF, Word, Excel, CSV, images, texte — Max 10 Mo
                          </p>
                        </div>
                        <Button size="sm" variant="outline" className="h-8 px-3 text-xs rounded-lg border-violet-200 text-violet-700 dark:border-violet-800 dark:text-violet-400" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
                          <Plus className="w-3.5 h-3.5 mr-1.5" />
                          Importer
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Document list */}
                  {loadingFolder ? (
                    <Card className="border-0 shadow-sm"><CardContent className="p-4 space-y-2">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-12 w-full rounded-lg" />)}</CardContent></Card>
                  ) : documents.length === 0 ? (
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-8 text-center">
                        <FileText className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                        <p className="text-xs text-gray-400">Aucun document dans ce dossier</p>
                        <p className="text-[10px] text-gray-300 mt-0.5">Importez des fichiers pour les organiser ici</p>
                      </CardContent>
                    </Card>
                  ) : (
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-2">
                        <div className="space-y-0.5">
                          {documents.map((doc) => (
                            <div key={doc.id} className="group flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all">
                              <DocumentIcon category={doc.category} />
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-medium text-gray-800 dark:text-gray-200 truncate">{doc.fileName}</p>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <span className="text-[10px] text-gray-400">{doc.fileSizeFormatted}</span>
                                  {doc.tags.length > 0 && (
                                    <span className="flex items-center gap-1">
                                      {doc.tags.slice(0, 3).map((tag, i) => (
                                        <Badge key={i} variant="secondary" className="text-[9px] h-4 px-1.5 bg-gray-100 dark:bg-gray-700 text-gray-500">{tag}</Badge>
                                      ))}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onClick={() => handleDownloadDocument(doc)} title="Télécharger">
                                  <Download className="w-3.5 h-3.5 text-gray-400" />
                                </button>
                                <button className="p-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30" onClick={() => handleDeleteDocument(doc.id)} title="Supprimer">
                                  <Trash2 className="w-3.5 h-3.5 text-red-400" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}

              {/* ─── Segments sub-tab ─── */}
              {subTab === 'segments' && (
                <div className="space-y-3">
                  {loadingFolder ? (
                    <Card className="border-0 shadow-sm"><CardContent className="p-4 space-y-2">{[1, 2].map((i) => <Skeleton key={i} className="h-20 w-full rounded-lg" />)}</CardContent></Card>
                  ) : segments.length === 0 && !showNewSegment ? (
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-8 text-center">
                        <Target className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                        <p className="text-xs text-gray-400 font-medium">Aucun segment de marché défini</p>
                        <p className="text-[10px] text-gray-300 mt-1">Ajoutez vos segments de marché cibles pour votre projet.</p>
                        <Button size="sm" className="mt-3 h-8 text-xs bg-violet-600 hover:bg-violet-700" onClick={() => setShowNewSegment(true)}>
                          <Plus className="w-3.5 h-3.5 mr-1.5" />
                          Ajouter un segment
                        </Button>
                      </CardContent>
                    </Card>
                  ) : (
                    <>
                      {/* Segment cards */}
                      {segments.map((seg) => (
                        <Card key={seg.id} className="border-0 shadow-sm">
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1.5">
                                  <Target className="w-4 h-4 text-violet-500 shrink-0" />
                                  <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">{seg.name}</span>
                                  <Badge variant="secondary" className={`text-[10px] ${priorityColor(seg.priority)}`}>
                                    {priorityLabel(seg.priority)}
                                  </Badge>
                                  <Badge variant="outline" className="text-[10px] text-gray-500">
                                    {seg.customerType === 'B2B' ? 'B2B' : 'B2C'}
                                  </Badge>
                                </div>
                                {seg.description && (
                                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">{seg.description}</p>
                                )}
                                <div className="flex flex-wrap gap-3 text-[10px] text-gray-400">
                                  {seg.size && (
                                    <span className="flex items-center gap-1"><BarChart3 className="w-3 h-3" /> Taille : {seg.size}</span>
                                  )}
                                  {seg.growth && (
                                    <span className="flex items-center gap-1"><TrendingUp className="w-3 h-3" /> Croissance : {seg.growth}</span>
                                  )}
                                  {seg.region && (
                                    <span className="flex items-center gap-1"><Globe className="w-3 h-3" /> {seg.region}</span>
                                  )}
                                  {seg.notes && (
                                    <span className="flex items-center gap-1"><Tag className="w-3 h-3" /> {seg.notes}</span>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-0.5 shrink-0 ml-2">
                                <button className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700" onClick={() => { setEditingSegmentId(seg.id); setEditSegment({ name: seg.name, description: seg.description || '', customerType: seg.customerType, size: seg.size || '', growth: seg.growth || '', region: seg.region || '', priority: seg.priority, notes: seg.notes || '' }) }}>
                                  <Edit3 className="w-3.5 h-3.5 text-gray-400" />
                                </button>
                                <button className="p-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30" onClick={() => handleDeleteSegment(seg.id)}>
                                  <Trash2 className="w-3.5 h-3.5 text-red-400" />
                                </button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </>
                  )}
                </div>
              )}
            </div>
          )}
        </motion.div>
      </div>

      {/* ==================== NEW FOLDER DIALOG ==================== */}
      {showNewFolder && (
        <div className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center" onClick={() => setShowNewFolder(false)}>
          <Card className="w-96 border-0 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold">Nouveau dossier</CardTitle>
                <button className="p-1 rounded hover:bg-gray-100" onClick={() => setShowNewFolder(false)}><X className="w-4 h-4 text-gray-400" /></button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input placeholder="Nom du dossier..." value={newFolderName} onChange={(e) => setNewFolderName(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') handleCreateFolder() }} className="rounded-xl" autoFocus />
              <div>
                <label className="text-xs text-gray-500 mb-1.5 block">Couleur</label>
                <div className="flex gap-2 flex-wrap">
                  {FOLDER_COLORS.map((c) => (
                    <button
                      key={c}
                      className={`w-7 h-7 rounded-full transition-transform ${newFolderColor === c ? 'scale-125 ring-2 ring-offset-2 ring-gray-400' : 'hover:scale-110'}`}
                      style={{ backgroundColor: c }}
                      onClick={() => setNewFolderColor(c)}
                    />
                  ))}
                </div>
              </div>
              <Button onClick={handleCreateFolder} disabled={!newFolderName.trim() || creatingFolder} className="w-full bg-violet-600 hover:bg-violet-700 rounded-xl">
                {creatingFolder ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FolderPlus className="w-4 h-4 mr-2" />}
                Créer le dossier
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* ==================== NEW SEGMENT DIALOG ==================== */}
      {showNewSegment && (
        <div className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center" onClick={() => setShowNewSegment(false)}>
          <Card className="w-[480px] border-0 shadow-xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-violet-500" />
                  <CardTitle className="text-sm font-semibold">Nouveau segment de marché</CardTitle>
                </div>
                <button className="p-1 rounded hover:bg-gray-100" onClick={() => setShowNewSegment(false)}><X className="w-4 h-4 text-gray-400" /></button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input placeholder="Nom du segment *" value={newSegment.name} onChange={(e) => setNewSegment((s) => ({ ...s, name: e.target.value }))} className="rounded-xl" autoFocus />
              <Textarea placeholder="Description du segment..." value={newSegment.description} onChange={(e) => setNewSegment((s) => ({ ...s, description: e.target.value }))} className="rounded-xl resize-none min-h-[60px]" />
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-gray-500 mb-1 block">Type de client</label>
                  <select className="w-full h-9 px-3 text-xs rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900" value={newSegment.customerType} onChange={(e) => setNewSegment((s) => ({ ...s, customerType: e.target.value }))}>
                    <option value="B2C">B2C (Particuliers)</option>
                    <option value="B2B">B2B (Entreprises)</option>
                    <option value="B2B2C">B2B2C</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-gray-500 mb-1 block">Priorité</label>
                  <select className="w-full h-9 px-3 text-xs rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900" value={newSegment.priority} onChange={(e) => setNewSegment((s) => ({ ...s, priority: e.target.value }))}>
                    <option value="high">Haute</option>
                    <option value="medium">Moyenne</option>
                    <option value="low">Basse</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Input placeholder="Taille du marché" value={newSegment.size} onChange={(e) => setNewSegment((s) => ({ ...s, size: e.target.value }))} className="rounded-xl text-xs" />
                <Input placeholder="Croissance" value={newSegment.growth} onChange={(e) => setNewSegment((s) => ({ ...s, growth: e.target.value }))} className="rounded-xl text-xs" />
              </div>
              <Input placeholder="Région / Zone géographique" value={newSegment.region} onChange={(e) => setNewSegment((s) => ({ ...s, region: e.target.value }))} className="rounded-xl text-xs" />
              <Input placeholder="Notes additionnelles" value={newSegment.notes} onChange={(e) => setNewSegment((s) => ({ ...s, notes: e.target.value }))} className="rounded-xl text-xs" />
              <Button onClick={handleCreateSegment} disabled={!newSegment.name.trim() || creatingSegment} className="w-full bg-violet-600 hover:bg-violet-700 rounded-xl">
                {creatingSegment ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                Ajouter le segment
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* ==================== EDIT SEGMENT DIALOG ==================== */}
      {editingSegmentId && (
        <div className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center" onClick={() => setEditingSegmentId(null)}>
          <Card className="w-[480px] border-0 shadow-xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Edit3 className="w-4 h-4 text-violet-500" />
                  <CardTitle className="text-sm font-semibold">Modifier le segment</CardTitle>
                </div>
                <button className="p-1 rounded hover:bg-gray-100" onClick={() => setEditingSegmentId(null)}><X className="w-4 h-4 text-gray-400" /></button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input value={editSegment.name} onChange={(e) => setEditSegment((s) => ({ ...s, name: e.target.value }))} className="rounded-xl" />
              <Textarea value={editSegment.description} onChange={(e) => setEditSegment((s) => ({ ...s, description: e.target.value }))} className="rounded-xl resize-none min-h-[60px]" />
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-gray-500 mb-1 block">Type de client</label>
                  <select className="w-full h-9 px-3 text-xs rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900" value={editSegment.customerType} onChange={(e) => setEditSegment((s) => ({ ...s, customerType: e.target.value }))}>
                    <option value="B2C">B2C (Particuliers)</option>
                    <option value="B2B">B2B (Entreprises)</option>
                    <option value="B2B2C">B2B2C</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-gray-500 mb-1 block">Priorité</label>
                  <select className="w-full h-9 px-3 text-xs rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900" value={editSegment.priority} onChange={(e) => setEditSegment((s) => ({ ...s, priority: e.target.value }))}>
                    <option value="high">Haute</option>
                    <option value="medium">Moyenne</option>
                    <option value="low">Basse</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Input placeholder="Taille du marché" value={editSegment.size} onChange={(e) => setEditSegment((s) => ({ ...s, size: e.target.value }))} className="rounded-xl text-xs" />
                <Input placeholder="Croissance" value={editSegment.growth} onChange={(e) => setEditSegment((s) => ({ ...s, growth: e.target.value }))} className="rounded-xl text-xs" />
              </div>
              <Input placeholder="Région" value={editSegment.region} onChange={(e) => setEditSegment((s) => ({ ...s, region: e.target.value }))} className="rounded-xl text-xs" />
              <Input placeholder="Notes" value={editSegment.notes} onChange={(e) => setEditSegment((s) => ({ ...s, notes: e.target.value }))} className="rounded-xl text-xs" />
              <div className="flex gap-2">
                <Button onClick={handleUpdateSegment} className="flex-1 bg-violet-600 hover:bg-violet-700 rounded-xl">
                  <Save className="w-4 h-4 mr-2" />
                  Enregistrer
                </Button>
                <Button variant="outline" onClick={() => setEditingSegmentId(null)} className="rounded-xl">
                  Annuler
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </motion.div>
  )
}

// ====================== FINANCIER TAB (KPIs rapide) ======================
function FinancierTab() {
  const userId = useAppStore((s) => s.userId)
  const [monthlyRevenue, setMonthlyRevenue] = useState(0)
  const [monthlyCosts, setMonthlyCosts] = useState(0)
  const [loading, setLoading] = useState(!!userId)
  const [initialLoaded, setInitialLoaded] = useState(false)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Fetch existing financial data on mount
  useEffect(() => {
    if (!userId) return
    let cancelled = false

    const load = async () => {
      setLoading(true)
      const result = await fetchJson<{ data: { revenue: number; costs: number } } | null>(
        `/api/modules/financier?userId=${encodeURIComponent(userId)}`, null
      )
      if (cancelled) return
      if (result?.data) {
        setMonthlyRevenue(result.data.revenue || 0)
        setMonthlyCosts(result.data.costs || 0)
      }
      setInitialLoaded(true)
      setLoading(false)
    }
    load()
    return () => { cancelled = true }
  }, [userId])

  // Save to API on change (debounced)
  const handleRevenueChange = useCallback((value: number) => {
    setMonthlyRevenue(value)
    if (userId && initialLoaded) {
      if (debounceRef.current) clearTimeout(debounceRef.current)
      debounceRef.current = setTimeout(() => {
        fetch('/api/modules/financier', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId, revenue: value, costs: monthlyCosts }),
        }).catch(() => {})
      }, 800)
    }
  }, [userId, initialLoaded, monthlyCosts])

  const handleCostsChange = useCallback((value: number) => {
    setMonthlyCosts(value)
    if (userId && initialLoaded) {
      if (debounceRef.current) clearTimeout(debounceRef.current)
      debounceRef.current = setTimeout(() => {
        fetch('/api/modules/financier', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId, revenue: monthlyRevenue, costs: value }),
        }).catch(() => {})
      }, 800)
    }
  }, [userId, initialLoaded, monthlyRevenue])

  const profit = monthlyRevenue - monthlyCosts
  const margin = monthlyRevenue > 0 ? ((profit / monthlyRevenue) * 100).toFixed(1) : '0.0'

  if (loading) {
    return (
      <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
        <motion.div variants={fadeIn}>
          <Card className="border-0 shadow-sm"><CardContent className="p-6 space-y-6"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><Skeleton className="h-10 rounded-xl" /><Skeleton className="h-10 rounded-xl" /></div><div className="grid grid-cols-3 gap-4">{[1, 2, 3].map((i) => (<Skeleton key={i} className="h-20 rounded-xl" />))}</div></CardContent></Card>
        </motion.div>
      </motion.div>
    )
  }

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Landmark className="w-5 h-5 text-emerald-500" />
              <CardTitle className="text-base">Indicateurs financiers</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-medium text-gray-600">CA mensuel estimé (EUR)</label>
                <Input type="number" value={monthlyRevenue} onChange={(e) => handleRevenueChange(Number(e.target.value))} className="rounded-xl" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-gray-600">Charges mensuelles (EUR)</label>
                <Input type="number" value={monthlyCosts} onChange={(e) => handleCostsChange(Number(e.target.value))} className="rounded-xl" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-center">
                <p className="text-xl font-bold text-emerald-600">{profit.toLocaleString('fr-FR')} EUR</p>
                <p className="text-xs text-gray-500">Résultat mensuel</p>
              </div>
              <div className="p-4 rounded-xl bg-violet-50 border border-violet-200 text-center">
                <p className="text-xl font-bold text-violet-600">{margin}%</p>
                <p className="text-xs text-gray-500">Marge bénéficiaire</p>
              </div>
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-center">
                <p className="text-xl font-bold text-amber-600">{(profit * 12).toLocaleString('fr-FR')} EUR</p>
                <p className="text-xs text-gray-500">Résultat annuel</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

// ====================== COMPETENCES TAB ======================
function CompetencesTab() {
  const userId = useAppStore((s) => s.userId)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [cvFile, setCvFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [uploadResult, setUploadResult] = useState<{ success: boolean; fileName?: string; fileUrl?: string; analysisId?: string; error?: string } | null>(null)
  const [analysisData, setAnalysisData] = useState<{
    id: string
    cvFileName: string | null
    cvFileUrl: string | null
    acquiredSkills: unknown
    gapSkills: unknown
    recommendedPlan: unknown
    analyzedAt: string
  } | null>(null)
  const [isDragOver, setIsDragOver] = useState(false)
  const [loadingAnalysis, setLoadingAnalysis] = useState(!!userId)

  // Fetch existing analysis on mount
  useEffect(() => {
    if (!userId) return
    let cancelled = false

    const loadAnalysis = async () => {
      setLoadingAnalysis(true)
      const res = await fetchJson<{ analysis: typeof analysisData }>(
        `/api/upload/cv?userId=${encodeURIComponent(userId)}`, { analysis: null }
      )
      if (cancelled) return
      if (res.analysis) {
        setAnalysisData(res.analysis)
      }
      setLoadingAnalysis(false)
    }
    loadAnalysis()
    return () => { cancelled = true }
  }, [userId])

  const handleFileSelect = (file: File) => {
    setCvFile(file)
    setUploadResult(null)
    handleUpload(file)
  }

  const handleUpload = async (file: File) => {
    if (!userId) {
      setUploadResult({ success: false, error: 'Vous devez être connecté pour télécharger un CV.' })
      return
    }

    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    ]

    if (!allowedTypes.includes(file.type)) {
      setUploadResult({ success: false, error: 'Type de fichier non supporté. Utilisez PDF, DOC ou DOCX.' })
      return
    }

    if (file.size > 5 * 1024 * 1024) {
      setUploadResult({ success: false, error: 'Fichier trop volumineux. Maximum 5 Mo.' })
      return
    }

    setUploading(true)
    setUploadResult(null)

    try {
      const formData = new FormData()
      formData.append('file', file)
      formData.append('userId', userId)

      const res = await fetch('/api/upload/cv', {
        method: 'POST',
        body: formData,
      })

      const data = await res.json()

      if (!res.ok) {
        setUploadResult({ success: false, error: data.error || 'Erreur lors du téléchargement.' })
        return
      }

      setUploadResult({ success: true, fileName: data.fileName, fileUrl: data.fileUrl, analysisId: data.analysisId })

      // Fetch the latest analysis
      const analysisRes = await fetch(`/api/upload/cv?userId=${encodeURIComponent(userId)}`)
      const analysisJson = await analysisRes.json()
      if (analysisJson.analysis) {
        setAnalysisData(analysisJson.analysis)
      }
    } catch {
      setUploadResult({ success: false, error: 'Erreur réseau. Veuillez réessayer.' })
    } finally {
      setUploading(false)
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragOver(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragOver(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragOver(false)
    const droppedFile = e.dataTransfer.files?.[0]
    if (droppedFile) {
      handleFileSelect(droppedFile)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileSelect(file)
    }
  }

  // Derive career map data from analysis if available
  const acquiredSkillsArr = Array.isArray(analysisData?.acquiredSkills) ? (analysisData.acquiredSkills as string[]) : []
  const gapSkillsArr = Array.isArray(analysisData?.gapSkills) ? (analysisData.gapSkills as string[]) : []
  const recPlan = analysisData?.recommendedPlan && typeof analysisData.recommendedPlan === 'object' ? (analysisData.recommendedPlan as Record<string, unknown>) : {}

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-emerald-500" />
              <CardTitle className="text-base">Import du CV — Skill Gap Analysis</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {/* Hidden file input */}
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.doc,.docx"
              className="hidden"
              onChange={handleInputChange}
            />

            {/* Drop zone */}
            <div
              onClick={() => fileInputRef.current?.click()}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer group ${
                isDragOver
                  ? 'border-emerald-500 bg-emerald-50/50'
                  : uploadResult?.success
                  ? 'border-emerald-300 bg-emerald-50/30'
                  : uploadResult?.success === false
                  ? 'border-red-300 bg-red-50/20'
                  : 'border-gray-200 hover:border-emerald-400 hover:bg-emerald-50/30'
              }`}
            >
              {uploading ? (
                <>
                  <Loader2 className="w-10 h-10 text-emerald-500 mx-auto mb-3 animate-spin" />
                  <p className="text-sm font-medium text-gray-700 mb-1">Téléchargement en cours...</p>
                  <p className="text-xs text-gray-400">Analyse de votre CV par l&apos;IA</p>
                </>
              ) : uploadResult?.success ? (
                <>
                  <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-3" />
                  <p className="text-sm font-medium text-emerald-700 mb-1">CV téléchargé avec succès !</p>
                  <p className="text-xs text-gray-500">{uploadResult.fileName}</p>
                  <Button variant="outline" size="sm" className="mt-4 rounded-full">Remplacer le fichier</Button>
                </>
              ) : uploadResult?.success === false ? (
                <>
                  <Upload className="w-10 h-10 text-red-400 mx-auto mb-3" />
                  <p className="text-sm font-medium text-red-600 mb-1">Erreur</p>
                  <p className="text-xs text-red-500">{uploadResult.error}</p>
                  <Button variant="outline" size="sm" className="mt-4 rounded-full">Réessayer</Button>
                </>
              ) : (
                <>
                  <Upload className={`w-10 h-10 mx-auto mb-3 transition-colors ${isDragOver ? 'text-emerald-500' : 'text-gray-300 group-hover:text-emerald-500'}`} />
                  <p className="text-sm font-medium text-gray-700 mb-1">Glissez-déposez votre CV ici</p>
                  <p className="text-xs text-gray-400">PDF, DOC, DOCX — Maximum 5 Mo</p>
                  <Button variant="outline" size="sm" className="mt-4 rounded-full">Parcourir les fichiers</Button>
                </>
              )}
            </div>

            {/* Info banner */}
            <div className="mt-4 p-4 rounded-xl bg-blue-50 border border-blue-200">
              <p className="text-sm text-blue-700">
                <Sparkles className="w-4 h-4 inline mr-1" />
                L&apos;IA analysera votre CV pour identifier vos compétences acquises, les écarts par rapport à votre projet et recommander un plan de formation personnalisé.
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Career Map section */}
      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Cartographie de compétences (Career Map)</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingAnalysis ? (
              <div className="flex flex-col items-center py-12 space-y-3">
                <Skeleton className="w-64 h-32 rounded-xl" />
                <Skeleton className="w-64 h-32 rounded-xl" />
                <Skeleton className="w-64 h-32 rounded-xl" />
              </div>
            ) : (
              <div className="flex flex-col items-center py-6">
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }} className="flex items-center gap-4 mb-2">
                  <div className="w-14 h-14 rounded-xl bg-emerald-100 border-2 border-emerald-400 flex items-center justify-center"><CheckCircle2 className="w-7 h-7 text-emerald-600" /></div>
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex-1 max-w-xs">
                    <p className="font-semibold text-emerald-800 text-sm">Compétences acquises</p>
                    <p className="text-xs text-emerald-600 mt-1">
                      {acquiredSkillsArr.length > 0 ? acquiredSkillsArr.join(', ') : analysisData ? 'Aucune compétence identifiée' : 'Importez un CV pour analyser vos compétences'}
                    </p>
                  </div>
                </motion.div>
                <div className="flex flex-col items-center my-2"><div className="w-0.5 h-8 bg-gray-200" /><ArrowRight className="w-5 h-5 text-gray-300 rotate-90" /><div className="w-0.5 h-8 bg-gray-200" /></div>
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }} className="flex items-center gap-4 mb-2">
                  <div className="w-14 h-14 rounded-xl bg-amber-100 border-2 border-amber-400 flex items-center justify-center"><Target className="w-7 h-7 text-amber-600" /></div>
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex-1 max-w-xs">
                    <p className="font-semibold text-amber-800 text-sm">Écarts identifiés (Skill Gap)</p>
                    <p className="text-xs text-amber-600 mt-1">
                      {gapSkillsArr.length > 0 ? gapSkillsArr.join(', ') : analysisData ? 'Aucun écart identifié' : 'Importez un CV pour identifier les écarts'}
                    </p>
                  </div>
                </motion.div>
                <div className="flex flex-col items-center my-2"><div className="w-0.5 h-8 bg-gray-200" /><ArrowRight className="w-5 h-5 text-gray-300 rotate-90" /><div className="w-0.5 h-8 bg-gray-200" /></div>
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }} className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-xl bg-violet-100 border-2 border-violet-400 flex items-center justify-center"><TrendingUp className="w-7 h-7 text-violet-600" /></div>
                  <div className="bg-violet-50 border border-violet-200 rounded-xl p-4 flex-1 max-w-xs">
                    <p className="font-semibold text-violet-800 text-sm">Plan de développement recommandé</p>
                    <p className="text-xs text-violet-600 mt-1">
                      {Object.keys(recPlan).length > 0 ? Object.entries(recPlan).map(([k, v]) => `${k}: ${String(v)}`).join(', ') : analysisData ? 'Aucune recommandation' : 'Importez un CV pour obtenir un plan personnalisé'}
                    </p>
                  </div>
                </motion.div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

// ====================== TABLEAU DE BORD TAB ======================
function TableauDeBordTab() {
  const userId = useAppStore((s) => s.userId)
  const [loading, setLoading] = useState(!!userId)
  const [roadmapSteps, setRoadmapSteps] = useState<Array<{
    title: string; description: string; status: 'completed' | 'in_progress' | 'upcoming' | 'blocked'; date: string
  }>>([])
  const [progressInfo, setProgressInfo] = useState<{ completed: number; total: number } | null>(null)

  useEffect(() => {
    if (!userId) return
    let cancelled = false

    const load = async () => {
      setLoading(true)
      const data = await fetchJson<{
        steps: Array<{
          id: string; order: number; title: string; description: string;
          status: 'completed' | 'in_progress' | 'upcoming' | 'blocked';
          estimatedDuration: string; completedAt?: string;
        }>
        progress: { completed: number; total: number; percent: number }
      }>(
        `/api/roadmap?userId=${encodeURIComponent(userId)}`, null
      )

      if (cancelled) return

      if (data?.steps && data.steps.length > 0) {
        setRoadmapSteps(data.steps.map((step) => ({
          title: step.title,
          description: step.description,
          status: step.status,
          date: step.completedAt
            ? new Date(step.completedAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })
            : step.status === 'in_progress'
              ? 'En cours'
              : 'À venir',
        })))
        setProgressInfo({ completed: data.progress.completed, total: data.progress.total })
      } else {
        setRoadmapSteps([])
        setProgressInfo(null)
      }
      setLoading(false)
    }
    load()
    return () => { cancelled = true }
  }, [userId])

  const statusIcons: Record<string, LucideIcon> = { completed: CheckCircle2, in_progress: Loader2, upcoming: Circle }
  const statusColors: Record<string, string> = { completed: 'text-emerald-500', in_progress: 'text-violet-500', upcoming: 'text-gray-300' }
  const statusBg: Record<string, string> = { completed: 'bg-emerald-50 border-emerald-200', in_progress: 'bg-violet-50 border-violet-200', upcoming: 'bg-gray-50 border-gray-200' }

  if (loading) {
    return (
      <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
        <motion.div variants={fadeIn}>
          <Card className="border-0 shadow-sm"><CardContent className="p-6 space-y-6">{[1, 2, 3, 4, 5].map((i) => (<Skeleton key={i} className="h-20 rounded-xl" />))}</CardContent></Card>
        </motion.div>
      </motion.div>
    )
  }

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger} className="space-y-6">
      <motion.div variants={fadeIn}>
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base">Feuille de Route interactive</CardTitle>
                <p className="text-sm text-gray-500 mt-1">Suivez votre progression dans le parcours de diagnostic.</p>
              </div>
              {progressInfo && (
                <Badge variant="secondary" className="bg-emerald-50 text-emerald-700">
                  {progressInfo.completed}/{progressInfo.total} étapes
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {roadmapSteps.length > 0 ? (
              <div className="relative">
                <div className="absolute left-7 top-0 bottom-0 w-0.5 bg-gray-100" />
                <div className="space-y-6">
                  {roadmapSteps.map((step, i) => {
                    const StatusIcon = statusIcons[step.status]
                    return (
                      <motion.div key={i} initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }} className="relative flex items-start gap-4">
                        <div className="relative z-10 w-14 h-14 shrink-0 rounded-xl border flex items-center justify-center bg-white shadow-sm">
                          <StatusIcon className={`w-6 h-6 ${statusColors[step.status]} ${step.status === 'in_progress' ? 'animate-spin' : ''}`} />
                        </div>
                        <div className={`flex-1 p-4 rounded-xl border ${statusBg[step.status]} min-w-0`}>
                          <div className="flex items-start justify-between gap-2">
                            <div><p className="font-semibold text-gray-900 text-sm">{step.title}</p><p className="text-xs text-gray-500 mt-1">{step.description}</p></div>
                            <span className="text-xs text-gray-400 whitespace-nowrap">{step.date}</span>
                          </div>
                        </div>
                      </motion.div>
                    )
                  })}
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <LayoutDashboard className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-sm text-gray-500">Aucune étape de parcours définie</p>
                <p className="text-xs text-gray-400 mt-1">Commencez par compléter les modules pour construire votre feuille de route.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

// ====================== MAIN USER DASHBOARD ======================
export default function UserDashboard() {
  const userTab = useAppStore((s) => s.userTab)
  const setUserTab = useAppStore((s) => s.setUserTab)

  return (
    <Tabs value={userTab} onValueChange={(v) => setUserTab(v as typeof userTab)} className="space-y-6">
      <TabsList className="bg-gray-100 p-1 rounded-xl h-auto flex-wrap gap-1">
        {[
          { value: 'profil', icon: User, label: 'Profil' },
          { value: 'bilan', icon: FileSearch, label: 'Bilan' },
          { value: 'riasec', icon: Compass, label: 'RIASEC' },
          { value: 'pepite', icon: Gamepad2, label: 'Pépites' },
          { value: 'juridique', icon: Scale, label: 'Juridique' },
          { value: 'bp-questionnaire', icon: ClipboardList, label: 'BP Créer' },
          { value: 'bp-overview', icon: BookOpen, label: 'BP Vue' },
          { value: 'bp-market', icon: Search, label: 'BP Marché' },
          { value: 'bp-canvas', icon: LayoutTemplate, label: 'BP Canvas' },
          { value: 'bp-financials', icon: Landmark, label: 'BP Finance' },
          { value: 'bp-pitch', icon: Presentation, label: 'BP Pitch' },
          { value: 'bp-radar', icon: Radar, label: 'BP Veille' },
          { value: 'bp-guides', icon: BookMarked, label: 'BP Guides' },
          { value: 'marche', icon: ShoppingCart, label: 'Marché' },
          { value: 'financier', icon: Calculator, label: 'Financier' },
          { value: 'strategie', icon: Target, label: 'Stratégie' },
          { value: 'financement', icon: TrendingUp, label: 'Financement' },
          { value: 'changement-echelle', icon: TrendingUp, label: "Changement d'Échelle" },
          { value: 'agenda', icon: Calendar, label: 'Agenda' },
          { value: 'messages', icon: MessageCircle, label: 'Messagerie' },
          { value: 'ia-assistant', icon: Sparkles, label: 'Assistant IA' },
          { value: 'tableau-de-bord', icon: LayoutDashboard, label: 'Roadmap' },
        ].map((tab) => (
          <TabsTrigger key={tab.value} value={tab.value} className="rounded-lg gap-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm text-xs sm:text-sm px-3 py-2">
            <tab.icon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{tab.label}</span>
          </TabsTrigger>
        ))}
      </TabsList>

      <TabsContent value="profil"><ProfilTab /></TabsContent>
      <TabsContent value="bilan"><BilanTab /></TabsContent>
      <TabsContent value="riasec"><RiasecQuiz /></TabsContent>
      <TabsContent value="pepite"><TriptychSwipe /></TabsContent>
      <TabsContent value="juridique"><JuridiqueTab /></TabsContent>
      <TabsContent value="bp-questionnaire"><BpQuestionnaire /></TabsContent>
      <TabsContent value="bp-overview"><BpOverview /></TabsContent>
      <TabsContent value="bp-market"><BpMarketDashboard /></TabsContent>
      <TabsContent value="bp-canvas"><BpCanvas /></TabsContent>
      <TabsContent value="bp-financials"><BpFinancials /></TabsContent>
      <TabsContent value="bp-pitch"><BpPitch /></TabsContent>
      <TabsContent value="bp-radar"><BpRadar /></TabsContent>
      <TabsContent value="bp-guides"><BpGuides /></TabsContent>
      <TabsContent value="marche"><MarcheTab /></TabsContent>
      <TabsContent value="financier"><FinancierTab /></TabsContent>
      <TabsContent value="strategie"><StrategyPanel /></TabsContent>
      <TabsContent value="financement"><FinancingPanel /></TabsContent>
      <TabsContent value="changement-echelle"><ScaleChangePanel /></TabsContent>
      <TabsContent value="agenda"><AgendaPanel /></TabsContent>
      <TabsContent value="messages"><MessagingPanel /></TabsContent>
      <TabsContent value="ia-assistant"><AiAssistantPanel /></TabsContent>
      <TabsContent value="tableau-de-bord"><TableauDeBordTab /></TabsContent>
    </Tabs>
  )
}
