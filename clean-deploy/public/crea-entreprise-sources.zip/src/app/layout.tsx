import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Providers } from "@/components/providers";
import { ChatWidget } from "@/components/chat/chat-widget";
import { SocialProofToast } from "@/components/social-proof-toast";
import { PromoBanner } from "@/components/promo-banner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Créa Entreprise | Guides, Outils & Conseils pour Entrepreneurs",
  description:
    "Le media B2B de référence pour les entrepreneurs. Guides, comparatifs et outils pour créer, gérer et développer votre entreprise pas à pas. Banque pro, compta, assurances, legal.",
  keywords: [
    "entrepreneuriat",
    "création entreprise",
    "banque pro",
    "comptabilité",
    "assurance RC Pro",
    "SASU",
    "auto-entrepreneur",
    "freelance",
    "business plan",
    "création entreprise",
    "Qonto",
    "Indy",
    "Pennylane",
    "Legalstart",
  ],
  authors: [{ name: "Créa Entreprise" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Créa Entreprise | Le Media B2B de Référence",
    description:
      "Guides, comparatifs et outils pour créer, gérer et développer votre entreprise. Audit de lancement gratuit.",
    siteName: "Créa Entreprise",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <PromoBanner />
        <Providers>
          {children}
          <ChatWidget />
          <SocialProofToast />
        </Providers>
        <Toaster />
      </body>
    </html>
  );
}
