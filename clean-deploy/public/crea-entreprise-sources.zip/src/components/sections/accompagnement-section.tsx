"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  Megaphone,
  Users,
  Palette,
  Target,
  FileText,
  HandCoins,
  Compass,
  TrendingUp,
  Search,
  Globe,
  GraduationCap,
  Scale,
  ArrowRight,
  Check,
  ChevronRight,
  Rocket,
  Sparkles,
  Star,
  Zap,
  Package,
  MessageSquare,
  Phone,
  FileBarChart,
  Banknote,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

// ─── ICON MAP ─────────────────────────────────────────────────────

const iconMap: Record<string, LucideIcon> = {
  Megaphone,
  Users,
  Palette,
  Target,
  FileText,
  HandCoins,
  Compass,
  TrendingUp,
  Search,
  Globe,
  GraduationCap,
  Scale,
  FileBarChart,
  Banknote,
};

// ─── SERVICE DATA ─────────────────────────────────────────────────

type ServiceCategory = "marketing" | "finance" | "juridique" | "tech" | "formation" | "coaching";

interface Service {
  slug: string;
  shortTitle: string;
  description: string;
  icon: string;
  color: string;
  priceFrom: number;
  priceUnit: string;
  category: ServiceCategory;
  audience: string;
}

const services: Service[] = [
  { slug: "marketing-digital", shortTitle: "Marketing Digital", description: "Stratégie marketing complète : audit, réseaux sociaux, Google Ads, SEO basique et reporting pour attirer vos premiers clients.", icon: "Megaphone", color: "emerald", priceFrom: 290, priceUnit: "/mois", category: "marketing", audience: "TPE créées < 12 mois" },
  { slug: "community-management", shortTitle: "Community Management", description: "Gestion professionnelle de vos réseaux sociaux : contenu, engagement, stories, reels et stratégie de croissance.", icon: "Users", color: "amber", priceFrom: 229, priceUnit: "/mois", category: "marketing", audience: "TPE et indépendants" },
  { slug: "supports-communication", shortTitle: "Identité & Supports", description: "Création de votre identité visuelle complète : logo, charte graphique, cartes de visite et kit de lancement.", icon: "Palette", color: "violet", priceFrom: 169, priceUnit: "", category: "marketing", audience: "TPE en lancement" },
  { slug: "lead-generation", shortTitle: "Lead Gen B2B", description: "Génération de prospects qualifiés B2B via prospection LinkedIn, email outreach et campagnes ciblées.", icon: "Target", color: "rose", priceFrom: 469, priceUnit: "/mois", category: "tech", audience: "Prestataires B2B" },
  { slug: "business-plan", shortTitle: "Business Plan", description: "Rédaction professionnelle de votre business plan et prévisionnel financier pour convaincre banques et investisseurs.", icon: "FileText", color: "teal", priceFrom: 169, priceUnit: "", category: "finance", audience: "Créateurs en financement" },
  { slug: "recouvrement-creances", shortTitle: "Recouvrement", description: "Service professionnel de recouvrement amiable : relances, négociation et suivi jusqu'au paiement. Zéro frais avancés.", icon: "HandCoins", color: "orange", priceFrom: 5, priceUnit: "% au succès", category: "finance", audience: "TPE avec impayés" },
  { slug: "copilote-entreprise", shortTitle: "Copilote Entreprise", description: "Coaching opérationnel personnalisé pour dirigeants : sessions visio, support Slack illimité et KPIs.", icon: "Compass", color: "emerald", priceFrom: 290, priceUnit: "/mois", category: "coaching", audience: "Tous les dirigeants" },
  { slug: "daf-externalise", shortTitle: "DAF Externalisé", description: "Direction financière externalisée pour PME : reporting, trésorerie, optimisation fiscale et relation bancaire.", icon: "TrendingUp", color: "teal", priceFrom: 890, priceUnit: "/mois", category: "finance", audience: "PME 10-50 salariés" },
  { slug: "seo-referencement", shortTitle: "SEO & Référencement", description: "Optimisation de votre référencement naturel : audit SEO, stratégie de contenu, netlinking et suivi de positions.", icon: "Search", color: "amber", priceFrom: 290, priceUnit: "", category: "marketing", audience: "TPE avec site web" },
  { slug: "creation-site-web", shortTitle: "Site Web", description: "Conception et développement de sites web professionnels : vitrine, e-commerce et applications web.", icon: "Globe", color: "violet", priceFrom: 529, priceUnit: "", category: "tech", audience: "TPE sans site" },
  { slug: "formation", shortTitle: "Formation", description: "Formations pratiques et certifiantes pour entrepreneurs : marketing digital, finance, juridique et management.", icon: "GraduationCap", color: "rose", priceFrom: 29, priceUnit: "/session", category: "formation", audience: "Tous les stades" },
  { slug: "juridique-ongoing", shortTitle: "Juridique & Conformité", description: "Accompagnement juridique continu : rédaction de contrats, mise en conformité RGPD et veille réglementaire.", icon: "Scale", color: "teal", priceFrom: 53, priceUnit: "/doc", category: "juridique", audience: "TPE/PME" },
];

// ─── CATEGORY FILTER TABS ─────────────────────────────────────────

type FilterCategory = "all" | ServiceCategory;

interface CategoryTab {
  value: FilterCategory;
  label: string;
}

const categoryTabs: CategoryTab[] = [
  { value: "all", label: "Tous" },
  { value: "marketing", label: "Marketing & Visibilité" },
  { value: "finance", label: "Finance" },
  { value: "juridique", label: "Juridique" },
  { value: "tech", label: "Tech & Digital" },
  { value: "formation", label: "Formation" },
  { value: "coaching", label: "Coaching" },
];

// ─── COLOR HELPERS ────────────────────────────────────────────────

const colorGradients: Record<string, string> = {
  emerald: "from-emerald-400 to-teal-500",
  amber: "from-amber-400 to-orange-500",
  violet: "from-violet-400 to-purple-500",
  rose: "from-rose-400 to-pink-500",
  teal: "from-teal-400 to-cyan-500",
  orange: "from-orange-400 to-red-500",
};

const colorBadge: Record<string, string> = {
  emerald: "bg-emerald-100 text-emerald-700 border-emerald-200",
  amber: "bg-amber-100 text-amber-700 border-amber-200",
  violet: "bg-violet-100 text-violet-700 border-violet-200",
  rose: "bg-rose-100 text-rose-700 border-rose-200",
  teal: "bg-teal-100 text-teal-700 border-teal-200",
  orange: "bg-orange-100 text-orange-700 border-orange-200",
};

const colorBorder: Record<string, string> = {
  emerald: "hover:border-emerald-300",
  amber: "hover:border-amber-300",
  violet: "hover:border-violet-300",
  rose: "hover:border-rose-300",
  teal: "hover:border-teal-300",
  orange: "hover:border-orange-300",
};

// ─── BUNDLES DATA ─────────────────────────────────────────────────

interface Bundle {
  name: string;
  price: string;
  priceNum: string;
  duration: string;
  description: string;
  services: string[];
  features: string[];
  highlighted: boolean;
  color: string;
}

const bundles: Bundle[] = [
  {
    name: "Pack Startup",
    price: "2 990€",
    priceNum: "2 990",
    duration: "3 mois",
    description: "Tout ce qu'il faut pour lancer votre activité sur de bonnes bases.",
    services: ["Business Plan", "Site Web Vitrine", "Identité & Supports", "Marketing Digital"],
    features: ["Économisez 40% vs achats séparés", "Accompagnement dédié", "Kick-off stratégique inclus", "Reporting mensuel"],
    highlighted: false,
    color: "emerald",
  },
  {
    name: "Pack Croissance",
    price: "8 990€",
    priceNum: "8 990",
    duration: "6 mois",
    description: "Accélérez votre développement commercial et votre visibilité.",
    services: ["Copilote Entreprise", "Marketing Digital", "Lead Gen B2B", "Site Business", "Community Management"],
    features: ["Économisez 40% vs achats séparés", "Chef de projet dédié", "Sessions stratégiques mensuelles", "Dashboard KPI en temps réel"],
    highlighted: true,
    color: "violet",
  },
  {
    name: "Pack Enterprise",
    price: "17 990€",
    priceNum: "17 990",
    duration: "12 mois",
    description: "Pilotage complet pour une PME en forte croissance.",
    services: ["DAF Externalisé", "Copilote Entreprise", "SEO & Référencement", "Community Management", "Formation"],
    features: ["Économisez 40% vs achats séparés", "Directeur de mission dédié", "Revue stratégique hebdomadaire", "Formation équipes incluse"],
    highlighted: false,
    color: "amber",
  },
];

// ─── PARCOURS DATA ────────────────────────────────────────────────

interface ParcoursStep {
  label: string;
  icon: string;
}

interface Parcours {
  title: string;
  description: string;
  target: string;
  steps: ParcoursStep[];
  color: string;
}

const parcours: Parcours[] = [
  {
    title: "Parcours Startup Tech",
    description: "De l'idée aux premiers clients pour une startup technologique.",
    target: "Startups & Tech",
    steps: [
      { label: "Business Plan", icon: "FileText" },
      { label: "Site MVP", icon: "Globe" },
      { label: "Marketing", icon: "Megaphone" },
      { label: "Community", icon: "Users" },
      { label: "Lead Gen", icon: "Target" },
    ],
    color: "violet",
  },
  {
    title: "Parcours Artisan/Commerce",
    description: "La marche à suivre pour un artisan ou commerçant local.",
    target: "Artisans & Commerçants",
    steps: [
      { label: "Identité", icon: "Palette" },
      { label: "Site Vitrine", icon: "Globe" },
      { label: "SEO Local", icon: "Search" },
      { label: "Community", icon: "Users" },
      { label: "Recouvrement", icon: "HandCoins" },
    ],
    color: "emerald",
  },
  {
    title: "Parcours Consultant B2B",
    description: "Développez votre activité de conseil et expertise B2B.",
    target: "Consultants & Experts",
    steps: [
      { label: "Business Plan", icon: "FileText" },
      { label: "LinkedIn Pro", icon: "Users" },
      { label: "Lead Gen", icon: "Target" },
      { label: "Copilote", icon: "Compass" },
      { label: "DAF", icon: "TrendingUp" },
    ],
    color: "amber",
  },
  {
    title: "Parcours Reconversion",
    description: "Un accompagnement progressif pour une reconversion réussie.",
    target: "Reconversions",
    steps: [
      { label: "Formation", icon: "GraduationCap" },
      { label: "Copilote", icon: "Compass" },
      { label: "Community", icon: "Users" },
      { label: "Site Web", icon: "Globe" },
      { label: "Marketing", icon: "Megaphone" },
    ],
    color: "rose",
  },
];

// ─── FAQ DATA ─────────────────────────────────────────────────────

const faqItems = [
  {
    question: "Comment fonctionne l'accompagnement ?",
    answer: "Après un premier échange gratuit pour comprendre vos besoins, nous vous proposons un plan d'action personnalisé. Vous choisissez les services adaptés et êtes suivi par un expert dédié. Chaque mission commence par un audit initial et se termine par un bilan avec des livrables concrets.",
  },
  {
    question: "Peut-on combiner plusieurs services ?",
    answer: "Absolument ! C'est même recommandé. Nos packs (Startup, Croissance, Enterprise) combinent les services les plus complémentaires avec des réductions de 30 à 40%. Vous pouvez aussi créer un sur-mesure en combinant les services à la carte selon vos besoins.",
  },
  {
    question: "Y a-t-il un engagement minimum ?",
    answer: "Cela dépend du service. Les services ponctuels (Business Plan, Site Web, Identité) sont sans engagement. Les services récurrents (Marketing, CM, Copilote, DAF) nécessitent un engagement de 1 à 3 mois selon la formule pour garantir des résultats concrets.",
  },
  {
    question: "Quelles garanties proposez-vous ?",
    answer: "Nous garantissons la qualité de nos livrables avec des révisions incluses. Pour le SEO, nous garantissons des objectifs de positionnement sous 6 à 12 mois. Pour la Lead Gen B2B, nous garantissons un minimum de leads qualifiés par mois. Si les objectifs ne sont pas atteints, nous prolongeons gratuitement.",
  },
  {
    question: "Les tarifs sont-ils adaptés aux petites entreprises ?",
    answer: "Oui, nos tarifs sont conçus spécifiquement pour les TPE et PME. Nos offres commencent à 29€/session pour les formations et 169€ pour les services ponctuels. C'est 50 à 80% moins cher qu'un cabinet ou une agence traditionnelle, grâce à notre connaissance du tissu entrepreneurial et nos process optimisés.",
  },
];

// ─── ANIMATION VARIANTS ───────────────────────────────────────────

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

// ─── MAIN COMPONENT ───────────────────────────────────────────────

export function AccompagnementSection() {
  const [activeCategory, setActiveCategory] = useState<FilterCategory>("all");

  const filteredServices =
    activeCategory === "all"
      ? services
      : services.filter((s) => s.category === activeCategory);

  return (
    <section id="accompagnement" className="relative">
      {/* ── 1. HERO SECTION ────────────────────────────────── */}
      <div className="relative py-16 sm:py-20 bg-gradient-to-b from-white via-amber-50/30 to-white border-t overflow-hidden">
        {/* Background decorations */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute -top-40 -left-40 h-80 w-80 rounded-full bg-amber-500/5 blur-3xl" />
          <div className="absolute -bottom-40 -right-40 h-80 w-80 rounded-full bg-emerald-500/5 blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-96 w-96 rounded-full bg-violet-500/3 blur-3xl" />
        </div>

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            variants={staggerContainer}
            className="text-center max-w-3xl mx-auto"
          >
            <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
              <Badge
                variant="outline"
                className="mb-4 px-4 py-1.5 text-sm font-medium border-violet-500/30 text-violet-600 bg-violet-50"
              >
                <Sparkles className="h-3.5 w-3.5 mr-1.5" />
                12+ Services d&apos;Accompagnement
              </Badge>
            </motion.div>

            <motion.h2
              variants={fadeUp}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight"
            >
              Accélérez votre croissance
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 via-amber-500 to-rose-500">
                avec nos experts
              </span>
            </motion.h2>

            <motion.p
              variants={fadeUp}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mt-5 text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed"
            >
              Du marketing au juridique, en passant par la finance et le digital,
              découvrez nos services sur-mesure pour chaque étape de votre parcours entrepreneurial.
            </motion.p>

            {/* Stats */}
            <motion.div
              variants={fadeUp}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="mt-10 flex flex-wrap justify-center gap-8 sm:gap-12"
            >
              {[
                { value: "12+", label: "Services experts" },
                { value: "500+", label: "Entrepreneurs accompagnés" },
                { value: "4.8/5", label: "Satisfaction client" },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-2xl sm:text-3xl font-bold text-foreground">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    {stat.label}
                  </div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* ── 2. CATEGORY FILTER + 3. SERVICE CARDS GRID ─────── */}
      <div className="relative py-16 sm:py-20 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Category Tabs */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            variants={fadeUp}
            transition={{ duration: 0.5 }}
            className="flex flex-wrap justify-center gap-2 mb-10"
          >
            {categoryTabs.map((cat) => (
              <button
                key={cat.value}
                onClick={() => setActiveCategory(cat.value)}
                className={`
                  px-4 py-2 rounded-full text-sm font-medium transition-all duration-200
                  ${
                    activeCategory === cat.value
                      ? "bg-primary text-primary-foreground shadow-md shadow-primary/20"
                      : "bg-background text-muted-foreground hover:text-foreground hover:bg-accent border border-border"
                  }
                `}
              >
                {cat.label}
              </button>
            ))}
          </motion.div>

          {/* Service Cards Grid */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5"
            >
              {filteredServices.map((service, index) => (
                <motion.div
                  key={service.slug}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.06 }}
                >
                  <ServiceCard service={service} />
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* ── 4. BUNDLES SECTION ─────────────────────────────── */}
      <div className="relative py-16 sm:py-20 bg-gradient-to-b from-white via-violet-50/20 to-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            variants={staggerContainer}
            className="text-center mb-12"
          >
            <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
              <Badge
                variant="outline"
                className="mb-4 px-4 py-1.5 text-sm font-medium border-amber-500/30 text-amber-600 bg-amber-50"
              >
                <Package className="h-3.5 w-3.5 mr-1.5" />
                Packs Avantageux
              </Badge>
            </motion.div>
            <motion.h2
              variants={fadeUp}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-3xl font-bold tracking-tight sm:text-4xl"
            >
              Des packs pensés pour votre stade de croissance
            </motion.h2>
            <motion.p
              variants={fadeUp}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto"
            >
              Combinez nos services et économisez jusqu&apos;à 40% sur votre accompagnement.
            </motion.p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            variants={staggerContainer}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8"
          >
            {bundles.map((bundle) => (
              <motion.div
                key={bundle.name}
                variants={fadeUp}
                transition={{ duration: 0.5 }}
              >
                <BundleCard bundle={bundle} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* ── 5. PARCOURS TYPE SECTION ───────────────────────── */}
      <div className="relative py-16 sm:py-20 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            variants={staggerContainer}
            className="text-center mb-12"
          >
            <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
              <Badge
                variant="outline"
                className="mb-4 px-4 py-1.5 text-sm font-medium border-emerald-500/30 text-emerald-600 bg-emerald-50"
              >
                <Rocket className="h-3.5 w-3.5 mr-1.5" />
                Parcours Types
              </Badge>
            </motion.div>
            <motion.h2
              variants={fadeUp}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-3xl font-bold tracking-tight sm:text-4xl"
            >
              Un accompagnement progressif adapté à votre profil
            </motion.h2>
            <motion.p
              variants={fadeUp}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto"
            >
              Chaque entrepreneur est unique. Découvrez le parcours idéal selon votre activité.
            </motion.p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {parcours.map((p, index) => (
              <motion.div
                key={p.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <ParcoursCard parcours={p} />
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* ── 6. FAQ ACCORDION ───────────────────────────────── */}
      <div className="relative py-16 sm:py-20 bg-gradient-to-b from-white via-rose-50/15 to-white">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            variants={staggerContainer}
            className="text-center mb-12"
          >
            <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
              <Badge
                variant="outline"
                className="mb-4 px-4 py-1.5 text-sm font-medium border-rose-500/30 text-rose-600 bg-rose-50"
              >
                <MessageSquare className="h-3.5 w-3.5 mr-1.5" />
                Questions fréquentes
              </Badge>
            </motion.div>
            <motion.h2
              variants={fadeUp}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-3xl font-bold tracking-tight sm:text-4xl"
            >
              Tout ce que vous devez savoir
            </motion.h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Accordion type="single" collapsible className="w-full">
              {faqItems.map((item, index) => (
                <AccordionItem
                  key={index}
                  value={`faq-${index}`}
                  className="bg-white rounded-lg border border-border/60 px-6 mb-3"
                >
                  <AccordionTrigger className="text-base font-semibold hover:no-underline py-5">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </div>

      {/* ── 7. CTA SECTION ─────────────────────────────────── */}
      <div className="relative py-16 sm:py-20 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            variants={staggerContainer}
            className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-600 to-emerald-700 px-6 py-14 sm:px-12 sm:py-20 text-center"
          >
            {/* Background pattern */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-0 right-0 h-64 w-64 rounded-full bg-white/5 -translate-y-1/2 translate-x-1/2" />
              <div className="absolute bottom-0 left-0 h-48 w-48 rounded-full bg-white/5 translate-y-1/2 -translate-x-1/2" />
            </div>

            <div className="relative z-10 max-w-2xl mx-auto">
              <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
                <Zap className="h-10 w-10 text-amber-300 mx-auto mb-5" />
              </motion.div>
              <motion.h2
                variants={fadeUp}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white"
              >
                Prêt à accélérer votre croissance ?
              </motion.h2>
              <motion.p
                variants={fadeUp}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="mt-4 text-lg text-emerald-100/90 max-w-xl mx-auto"
              >
                Réservez un audit gratuit de 30 minutes pour identifier les services
                qui feront décoller votre activité.
              </motion.p>
              <motion.div
                variants={fadeUp}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4"
              >
                <Button
                  size="lg"
                  className="gap-2 bg-white text-emerald-700 hover:bg-emerald-50 font-semibold text-base shadow-lg shadow-emerald-900/20 px-8 h-12"
                >
                  <Star className="h-5 w-5" />
                  Audit Gratuit
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="gap-2 border-white/30 text-white hover:bg-white/10 hover:text-white font-semibold text-base px-8 h-12"
                >
                  <Phone className="h-5 w-5" />
                  Nous contacter
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// ─── SERVICE CARD ─────────────────────────────────────────────────

function ServiceCard({ service }: { service: Service }) {
  const IconComponent = iconMap[service.icon] || FileText;
  const gradient = colorGradients[service.color] || "from-gray-400 to-gray-500";
  const badgeColor = colorBadge[service.color] || "bg-gray-100 text-gray-700 border-gray-200";
  const borderHover = colorBorder[service.color] || "hover:border-gray-300";

  return (
    <Link href={`/accompagnement/${service.slug}`}>
      <Card
        className={`
          group flex flex-col rounded-2xl border-border/60 bg-white h-full
          transition-all duration-300 hover:shadow-lg hover:-translate-y-1 cursor-pointer
          ${borderHover}
        `}
      >
        <CardHeader className="pb-0">
          <div className="flex items-start gap-3">
            <div
              className={`flex-shrink-0 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${gradient} shadow-sm`}
            >
              <IconComponent className="h-6 w-6 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <CardTitle className="text-base font-bold leading-tight group-hover:text-primary transition-colors">
                {service.shortTitle}
              </CardTitle>
              <Badge
                variant="secondary"
                className={`text-[10px] px-1.5 py-0 h-5 mt-1.5 ${badgeColor}`}
              >
                {service.audience}
              </Badge>
            </div>
          </div>
        </CardHeader>

        <CardContent className="flex-1 pt-3">
          <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3">
            {service.description}
          </p>
        </CardContent>

        <CardFooter className="pt-0">
          <div className="flex items-center justify-between w-full">
            <span className="text-sm font-bold text-primary">
              {service.priceFrom}€{service.priceUnit ? ` ${service.priceUnit}` : ""}
            </span>
            <span className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground group-hover:text-primary transition-colors">
              Voir détails
              <ChevronRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
            </span>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}

// ─── BUNDLE CARD ──────────────────────────────────────────────────

function BundleCard({ bundle }: { bundle: Bundle }) {
  const gradientClass =
    bundle.color === "emerald"
      ? "from-emerald-500 to-teal-500"
      : bundle.color === "violet"
        ? "from-violet-500 to-purple-500"
        : "from-amber-500 to-orange-500";

  const borderColor =
    bundle.color === "emerald"
      ? "border-emerald-500/30"
      : bundle.color === "violet"
        ? "border-violet-500/30"
        : "border-amber-500/30";

  const bgBadge =
    bundle.color === "emerald"
      ? "bg-emerald-50 text-emerald-700"
      : bundle.color === "violet"
        ? "bg-violet-50 text-violet-700"
        : "bg-amber-50 text-amber-700";

  return (
    <Card
      className={`
        relative flex flex-col rounded-2xl h-full transition-all duration-300 hover:shadow-xl
        ${bundle.highlighted ? `border-2 ${borderColor} shadow-lg` : "border-border/60"}
      `}
    >
      {bundle.highlighted && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
          <Badge className={`${bgBadge} px-3 py-1 text-xs font-bold shadow-sm`}>
            <Zap className="h-3 w-3 mr-1" />
            Le plus populaire
          </Badge>
        </div>
      )}

      <CardHeader className="text-center pb-0">
        <CardTitle className="text-xl font-bold">{bundle.name}</CardTitle>
        <CardDescription className="text-sm mt-1">{bundle.description}</CardDescription>
      </CardHeader>

      <CardContent className="flex-1 text-center pt-4">
        <div className="mb-4">
          <span className="text-4xl font-bold text-foreground">{bundle.price}</span>
          <span className="text-sm text-muted-foreground ml-2">HT / {bundle.duration}</span>
        </div>

        {/* Included Services */}
        <div className="text-left space-y-2.5 mb-6">
          {bundle.services.map((svc) => (
            <div key={svc} className="flex items-center gap-2.5">
              <div
                className={`flex-shrink-0 flex h-5 w-5 items-center justify-center rounded-full bg-gradient-to-br ${gradientClass}`}
              >
                <Check className="h-3 w-3 text-white" />
              </div>
              <span className="text-sm text-foreground">{svc}</span>
            </div>
          ))}
        </div>

        {/* Features */}
        <div className="text-left space-y-1.5">
          {bundle.features.map((feat) => (
            <div key={feat} className="flex items-start gap-2">
              <Sparkles className="h-3.5 w-3.5 text-amber-500 mt-0.5 flex-shrink-0" />
              <span className="text-xs text-muted-foreground">{feat}</span>
            </div>
          ))}
        </div>
      </CardContent>

      <CardFooter className="pt-0">
        <Button
          className={`w-full gap-2 font-semibold h-11 ${
            bundle.highlighted
              ? `bg-gradient-to-r ${gradientClass} text-white shadow-md hover:opacity-90`
              : "bg-primary hover:bg-primary/90 text-primary-foreground"
          }`}
        >
          Choisir {bundle.name}
          <ArrowRight className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}

// ─── PARCOURS CARD ────────────────────────────────────────────────

function ParcoursCard({ parcours: p }: { parcours: Parcours }) {
  const bgGradient =
    p.color === "violet"
      ? "bg-gradient-to-r from-violet-500/5 to-purple-500/5"
      : p.color === "emerald"
        ? "bg-gradient-to-r from-emerald-500/5 to-teal-500/5"
        : p.color === "amber"
          ? "bg-gradient-to-r from-amber-500/5 to-orange-500/5"
          : "bg-gradient-to-r from-rose-500/5 to-pink-500/5";

  const accentBorder =
    p.color === "violet"
      ? "border-violet-500/20"
      : p.color === "emerald"
        ? "border-emerald-500/20"
        : p.color === "amber"
          ? "border-amber-500/20"
          : "border-rose-500/20";

  const accentBadge =
    p.color === "violet"
      ? "bg-violet-100 text-violet-700"
      : p.color === "emerald"
        ? "bg-emerald-100 text-emerald-700"
        : p.color === "amber"
          ? "bg-amber-100 text-amber-700"
          : "bg-rose-100 text-rose-700";

  return (
    <Card className={`rounded-2xl border ${accentBorder} ${bgGradient} overflow-hidden`}>
      <CardHeader className="pb-0">
        <div className="flex items-center justify-between mb-2">
          <CardTitle className="text-lg font-bold">{p.title}</CardTitle>
          <Badge variant="secondary" className={`text-[10px] px-2 py-0.5 h-5 ${accentBadge}`}>
            {p.target}
          </Badge>
        </div>
        <CardDescription className="text-sm">{p.description}</CardDescription>
      </CardHeader>
      <CardContent className="pt-4">
        {/* Step flow */}
        <div className="flex items-center gap-0 overflow-x-auto pb-2">
          {p.steps.map((step, i) => {
            const StepIcon = iconMap[step.icon] || FileText;
            return (
              <div key={step.label} className="flex items-center gap-0 flex-shrink-0">
                <div className="flex flex-col items-center gap-1.5 min-w-[64px]">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white border border-border/80 shadow-sm">
                    <StepIcon className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <span className="text-[11px] font-medium text-muted-foreground text-center leading-tight max-w-[72px]">
                    {step.label}
                  </span>
                </div>
                {i < p.steps.length - 1 && (
                  <ChevronRight className="h-4 w-4 text-muted-foreground/40 flex-shrink-0 mx-1 -mt-5" />
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
