import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// ─── UTILS ───────────────────────────────────────────────────
function randomInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomFloat(min: number, max: number, decimals = 2) {
  return parseFloat((Math.random() * (max - min) + min).toFixed(decimals));
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomDate(daysAgoMin: number, daysAgoMax: number): Date {
  const now = Date.now();
  const msDay = 86_400_000;
  return new Date(now - randomInt(daysAgoMin, daysAgoMax) * msDay + randomInt(0, msDay));
}

function daysAgo(n: number): Date {
  return new Date(Date.now() - n * 86_400_000 + randomInt(0, 86_400_000));
}

// ─── DATA POOLS ──────────────────────────────────────────────
const firstNames = [
  'Thomas', 'Marie', 'Lucas', 'Emma', 'Hugo', 'Léa', 'Nathan', 'Chloé',
  'Maxime', 'Julie', 'Alexandre', 'Camille', 'Nicolas', 'Sarah', 'Antoine',
  'Manon', 'Romain', 'Laura', 'Julien', 'Marine', 'Sébastien', 'Alice',
  'Benoît', 'Clara', 'David', 'Inès', 'Florian', 'Pauline', 'Guillaume',
  'Mathilde', 'Adrien', 'Anaïs', 'Pierre', 'Zoé', 'François', 'Léna',
  'Olivier', 'Eva', 'Christophe', 'Jade', 'Jean', 'Louise', 'Marc',
  'Margaux', 'Laurent', 'Clémence', 'Bruno', 'Lison', 'Fabien', 'Romane',
  'Thierry', 'Céline', 'Patrick', 'Amélie', 'Stéphane', 'Charlotte',
  'Philippe', 'Elise', 'Yannick', 'Justine', 'Grégoire', 'Sylvie',
  'Mickaël', 'Émilie', 'Damien', 'Alexia', 'Vincent', 'Ophélie',
  'Arnaud', 'Valérie', 'Cédric', 'Nathalie', 'Dylan', 'Morgane',
];

const lastNames = [
  'Martin', 'Bernard', 'Thomas', 'Petit', 'Robert', 'Richard', 'Durand',
  'Dubois', 'Moreau', 'Laurent', 'Simon', 'Michel', 'Garcia', 'Leroy',
  'Roux', 'Fournier', 'Morel', 'Girard', 'André', 'Lefèvre', 'Mercier',
  'Dupont', 'Lambert', 'Bonnet', 'François', 'Martinez', 'Legrand',
  'Garnier', 'Faure', 'Rousseau', 'Blanc', 'Guérin', 'Muller',
  'Henry', 'Roussel', 'Nicolas', 'Pierre', 'Fontaine', 'Chevalier',
];

const domains = [
  'gmail.com', 'orange.fr', 'free.fr', 'hotmail.fr', 'yahoo.fr',
  'outlook.com', 'laposte.net', 'sfr.fr', 'icloud.com', 'protonmail.com',
];

const profiles = ['etudiant', 'salarie', 'freelance', 'tpe-pme'];
const profileLabels: Record<string, string> = {
  etudiant: 'Étudiant / Jeune diplômé',
  salarie: 'Salarié en reconversion',
  freelance: 'Freelance / Indépendant',
  'tpe-pme': 'TPE / PME',
};

const phases = ['reflexion', 'creation', 'gestion', 'croissance'];
const phaseLabels: Record<string, string> = {
  reflexion: 'Réflexion / Idéation',
  creation: 'Création / Lancement',
  gestion: 'Gestion quotidienne',
  croissance: 'Croissance / Développement',
};

const painPoints = [
  'Choix du statut juridique',
  'Financement et business plan',
  'Gestion comptable',
  'Assurance professionnelle',
  'Trouver ses premiers clients',
  'Marketing digital',
  'Gestion de la trésorerie',
  'Charger sociales et fiscales',
  'Outils de facturation',
  'Création de site web',
  'Stratégie de prix',
  'Gestion du temps',
];

const statuses = ['new', 'contacted', 'converted', 'lost'];
const statusWeights = [50, 25, 15, 10]; // weighted distribution

const sources = ['audit-form', 'organic', 'referral', 'social', 'google-ads'];
const sourceWeights = [45, 25, 15, 10, 5];

function weightedPick<T>(items: T[], weights: number[]): T {
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < items.length; i++) {
    r -= weights[i];
    if (r <= 0) return items[i];
  }
  return items[items.length - 1];
}

function generateEmail(first: string, last: string): string {
  const separators = ['.', '_', ''];
  const sep = pick(separators);
  const prefix = (first + sep + last).toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z]/g, '');
  const suffix = randomInt(0, 100) > 85 ? String(randomInt(1, 99)) : '';
  return `${prefix}${suffix}@${pick(domains)}`;
}

// ─── TOOLS (Affiliation) ────────────────────────────────────
const toolsData = [
  { name: 'Shine', slug: 'shine', tagline: 'Le compte pro nouvelle génération', category: 'bank', pricing: 'gratuit', rating: 4.2, commission: 15, order: 1,
    pros: 'Interface moderne,Carte virtuelle gratuite,Catégories auto,Taux intéressants sur le solde', cons: 'Service client parfois lent,Limited options de crédit',
    features: 'Compte pro,Carte Mastercard,Catégories auto,Virements instantanés,Facturation' },
  { name: 'Qonto', slug: 'qonto', tagline: 'Le compte pro pour les PME et freelances', category: 'bank', pricing: 'freemium', rating: 4.5, commission: 25, order: 2,
    pros: 'Excellent service client,Intégrations comptables,Multi-utilisateurs,Export comptable automatique', cons: 'Plan premium cher,Pas de découvert autorisé',
    features: 'Compte pro,Cartes physiques et virtuelles,Export comptable,API,Multi-équipes' },
  { name: 'Shine Neo', slug: 'shine-neo', tagline: 'Banque pro accessible à tous', category: 'bank', pricing: 'gratuit', rating: 3.8, commission: 12, order: 3,
    pros: 'Gratuit,Simple à ouvrir,Cashback,Analytics intégrés', cons: 'Fonctionnalités limitées,Pas de virement international',
    features: 'Compte gratuit,Carte Visa,Analytics,Cashback,Factures' },
  { name: 'Indy', slug: 'indy', tagline: 'La compta auto pour les freelances', category: 'compta', pricing: 'freemium', rating: 4.4, commission: 20, order: 4,
    pros: 'Automatisation complète,Interface intuitive,Connectivité bancaire,I perfectionné au fil du temps', cons: 'Uniquement micro-entreprises,Pas de bilans',
    features: 'Compta automatique,Facturation,Notes de frais,TVA,Déclarations URSSAF' },
  { name: 'Freebe', slug: 'freebe', tagline: 'La compta intelligente pour auto-entrepreneurs', category: 'compta', pricing: 'gratuit', rating: 4.0, commission: 10, order: 5,
    pros: 'Totalement gratuit,Facturation intégrée,Rappel URSSAF,Bon UI', cons: 'Fonctionnalités basiques,Pas de conseiller dédié',
    features: 'Facturation,Déclarations,Tableau de bord,Rappels,Export' },
  { name: 'Shine Compta', slug: 'shine-compta', tagline: 'Comptabilité simplifiée', category: 'compta', pricing: 'payant', rating: 3.9, commission: 18, order: 6,
    pros: 'Intégré à Shine,Facturation,Catégories auto', cons: 'Moins complet que Indy,Pas de bilan',
    features: 'Compta,Facturation,Charges,Synthèse,Déclarations' },
  { name: 'Alan', slug: 'alan', tagline: 'Assurance santé et prévoyance pro', category: 'assurance', pricing: 'payant', rating: 4.6, commission: 35, order: 7,
    pros: 'Experience 100% digitale,Tarifs compétitifs,Sans engagement,Ajout/suppression facile', cons: 'Réseau de soins limité,Pas de mutuelle famille',
    features: 'Santé,Prévoyance,Responsabilité civile,Absences,Téléconsultation' },
  { name: 'Wenity', slug: 'wenity', tagline: 'Assurance décennale et RC Pro', category: 'assurance', pricing: 'payant', rating: 3.7, commission: 30, order: 8,
    pros: 'Spécialisé BTP/artisanat,Devis rapide,Adapté aux auto-entrepreneurs', cons: 'Niche limitée,Tarifs variables',
    features: 'Décennale,RC Pro,Biens professionnels,Cyber,Flotte auto' },
  { name: 'Hostinger', slug: 'hostinger', tagline: 'Créez votre site web facilement', category: 'marketing', pricing: 'freemium', rating: 4.3, commission: 40, order: 9,
    pros: 'Prix très bas,Hébergement rapide,Domaine inclus,Bon support', cons: 'Renouvellement plus cher,Fonctionnalités limitées bas de gamme',
    features: 'Hébergement,Constructeur site,Nom de domaine,SSL,Email pro' },
  { name: 'Mailchimp', slug: 'mailchimp', tagline: 'Email marketing pour les petites entreprises', category: 'marketing', pricing: 'freemium', rating: 4.1, commission: 15, order: 10,
    pros: 'Gratuit jusqu\'à 500 contacts,Templates pro,Automatisations,Analytics', cons: 'Limitations plan gratuit,Pas de SMS en bas de gamme',
    features: 'Newsletters,Automatisation,Forms,CRM,A/B Testing' },
  { name: 'Canva Pro', slug: 'canva-pro', tagline: 'Design professionnel sans compétence', category: 'marketing', pricing: 'payant', rating: 4.7, commission: 12, order: 11,
    pros: 'Super intuitif,Milliers de templates,Marque kit,Photos pro', cons: 'Export vectoriel limité,Encombrant pour des projets complexes',
    features: 'Templates,Photos,Icônes,Marque kit,Animation,Impression' },
  { name: 'Stripe', slug: 'stripe', tagline: 'Acceptez les paiements en ligne', category: 'other', pricing: 'payant', rating: 4.5, commission: 0, order: 12,
    pros: 'API puissante,Sécurité maximale,Support technique excellent,Multi-devises', cons: 'Commission par transaction,Setup technique requis',
    features: 'Paiements,Abonnements,Marketplace,Facturation,3D Secure' },
];

// ─── TASKS (100 jours) ──────────────────────────────────────
const tasksData = [
  // Réflexion
  { phase: 'reflexion', title: 'Valider son idée de business', description: 'Réaliser une étude de marché et valider la demande auprès de prospects réels.', order: 1 },
  { phase: 'reflexion', title: 'Définir son persona client', description: 'Identifier précisément le client idéal : besoins, motivations, comportements d\'achat.', order: 2 },
  { phase: 'reflexion', title: 'Analyser la concurrence', description: 'Cartographier les concurrents directs et indirects, identifier les opportunités de différenciation.', order: 3 },
  { phase: 'reflexion', title: 'Estimer son budget de départ', description: 'Lister toutes les dépenses nécessaires au lancement et prévoir une trésorerie de secours.', order: 4 },
  { phase: 'reflexion', title: 'Choisir son statut juridique', description: 'Comparer micro-entreprise, SASU, EURL, SARL en fonction de sa situation.', order: 5 },
  { phase: 'reflexion', title: 'Rédiger son business plan', description: 'Structurer son projet : executive summary, marché, offre, stratégie, prévisions financières.', order: 6 },
  // Création
  { phase: 'creation', title: 'Ouvrir son compte bancaire pro', description: 'Choisir une banque en ligne adaptée (Shine, Qonto) et ouvrir le compte.', order: 7 },
  { phase: 'creation', title: 'Immatriculer son entreprise', description: 'Déclarer son activité via le guichet unique ou un plateforme de création en ligne.', order: 8 },
  { phase: 'creation', title: 'Choisir sa solution comptable', description: 'Sélectionner un outil de compta (Indy, Freebe) ou un expert-comptable.', order: 9 },
  { phase: 'creation', title: 'Souscrire à une assurance pro', description: 'RC Pro obligatoire, décennale si BTP, mutuelle TNS.', order: 10 },
  { phase: 'creation', title: 'Créer son identité visuelle', description: 'Logo, charte graphique, cartes de visite avec Canva ou un designer.', order: 11 },
  { phase: 'creation', title: 'Créer son site web', description: 'Landing page, site vitrine ou e-commerce. Choisir la bonne solution technique.', order: 12 },
  { phase: 'creation', title: 'Configurer ses outils de facturation', description: 'Mettre en place ses modèles de facture et conditions de paiement.', order: 13 },
  // Gestion
  { phase: 'gestion', title: 'Mettre en place la gestion de la trésorerie', description: 'Suivi des encaissements, décaissements, prévisionnel de trésorerie.', order: 14 },
  { phase: 'gestion', title: 'Automatiser la facturation', description: 'Configurer les relances automatiques et les rappels de paiement.', order: 15 },
  { phase: 'gestion', title: 'Déclarer son CA régulièrement', description: 'URSSAF, impôts : ne pas oublier les échéances de déclaration.', order: 16 },
  { phase: 'gestion', title: 'Commencer le marketing digital', description: 'SEO, réseaux sociaux, Google My Business, publicité ciblée.', order: 17 },
  { phase: 'gestion', title: 'Développer son réseau professionnel', description: 'Participer à des événements, rejoindre des communautés, réseauter.', order: 18 },
  // Croissance
  { phase: 'croissance', title: 'Optimiser son site pour le SEO', description: 'Contenu régulier, backlinks, optimisation technique, Google Search Console.', order: 19 },
  { phase: 'croissance', title: 'Lancer des campagnes email', description: 'Constituer une liste, créer des séquences d\'emails automatisées.', order: 20 },
  { phase: 'croissance', title: 'Diversifier ses revenus', description: 'Produits complémentaires, formations, conseil, partenariats.', order: 21 },
  { phase: 'croissance', title: 'Recruter son premier collaborateur', description: 'Alternant, freelance, CDD : structurer l\'embauche et les processus.', order: 22 },
  { phase: 'croissance', title: 'Automatiser et déléguer', description: 'Identifier les tâches à automatiser et celles à déléguer.', order: 23 },
  { phase: 'croissance', title: 'Bilan à 100 jours', description: 'Analyser les résultats, ajuster la stratégie, planifier les 6 prochains mois.', order: 24 },
];

// ─── ADMIN USER ──────────────────────────────────────────────
const adminUser = {
  email: 'admin@100jourspourentreprendre.fr',
  name: 'Admin 100 Jours',
  password: '$2a$10$placeholder_hash_change_me',
  role: 'admin',
};

// ─── MAIN SEED ──────────────────────────────────────────────
async function main() {
  console.log('🌱 Starting seed...\n');

  // Clean existing data
  console.log('🗑️  Cleaning existing data...');
  await prisma.userProgress.deleteMany();
  await prisma.affiliateClick.deleteMany();
  await prisma.auditResult.deleteMany();
  await prisma.lead.deleteMany();
  await prisma.user.deleteMany();
  await prisma.task.deleteMany();
  await prisma.tool.deleteMany();
  await prisma.emailCampaign.deleteMany();

  // 1. Create Admin User
  console.log('👤 Creating admin user...');
  const admin = await prisma.user.create({ data: adminUser });
  console.log(`   ✅ Admin: ${admin.email}\n`);

  // 2. Create Tools
  console.log('🛠️  Creating tools...');
  const tools: Record<string, any> = {};
  for (const tool of toolsData) {
    const created = await prisma.tool.create({
      data: {
        ...tool,
        website: `https://www.${tool.slug}.com`,
        affiliateUrl: `https://www.${tool.slug}.com/?ref=100jours`,
        active: true,
        description: `${tool.tagline}. Découvrez ${tool.name} pour votre entreprise.`,
      },
    });
    tools[tool.slug] = created;
    console.log(`   ✅ ${created.name} (${created.category})`);
  }
  console.log(`   → ${Object.keys(tools).length} outils créés\n`);

  // 3. Create Tasks (100 jours checklist)
  console.log('📋 Creating tasks...');
  const tasks: any[] = [];
  for (const task of tasksData) {
    const created = await prisma.task.create({ data: task });
    tasks.push(created);
    console.log(`   ✅ ${created.title} [${task.phase}]`);
  }
  console.log(`   → ${tasks.length} tâches créées\n`);

  // 4. Generate Leads (120 over 45 days) — batch insert for performance
  console.log('👥 Generating leads...');
  const usedEmails = new Set<string>();
  const leadIds: string[] = [];
  const leadProfileMap: Map<string, string> = new Map();

  const leadBatch: any[] = [];
  for (let i = 0; i < 120; i++) {
    const firstName = pick(firstNames);
    const lastName = pick(lastNames);
    let email = generateEmail(firstName, lastName);
    let attempts = 0;
    while (usedEmails.has(email) && attempts < 20) {
      email = generateEmail(pick(firstNames), pick(lastNames));
      attempts++;
    }
    usedEmails.add(email);

    const profile = pick(profiles);
    const phase = pick(phases);
    const status = weightedPick(statuses, statusWeights);
    const source = weightedPick(sources, sourceWeights);
    const createdAt = randomDate(0, 45);

    leadBatch.push({
      email,
      firstName,
      lastName,
      phone: randomInt(0, 3) > 0 ? `06${randomInt(10, 99)}${randomInt(10, 99)}${randomInt(10, 99)}${randomInt(10, 99)}` : null,
      profile,
      phase,
      painPoint: pick(painPoints),
      projectName: randomInt(0, 100) > 60
        ? pick([
            'Conseil en stratégie digitale', 'Bakery artisanale', 'Coach sportif en ligne',
            'Agence de communication', 'E-commerce produits bio', 'Formation en ligne',
            'Développeur web freelance', 'Traiteur événementiel', 'Photographe professionnel',
            'Studio de yoga', 'Consulting RH', 'Application mobile',
            'Réparation informatique', 'Blogueur influenceur', 'Agence immobilière',
            'Salon de coiffure', 'Cours de cuisine', 'Transport de marchandises',
            'Nettoyage professionnel', 'Création de bijoux',
          ])
        : null,
      consent: true,
      status,
      source,
      createdAt,
      updatedAt: createdAt,
    });
  }

  // Batch insert (createMany doesn't return IDs, so we also do a findMany)
  await prisma.lead.createMany({ data: leadBatch });
  const leads = await prisma.lead.findMany({ orderBy: { createdAt: 'desc' } });
  console.log(`   ✅ ${leads.length} leads créés\n`);

  // 5. Create AuditResults — batch
  console.log('📊 Creating audit results...');
  const auditBatch: any[] = [];
  const auditableLeads = leads.filter((_, i) => i < 80);
  for (const lead of auditableLeads) {
    const score = randomInt(30, 95);
    auditBatch.push({
      leadId: lead.id,
      profile: lead.profile,
      phase: lead.phase || 'reflexion',
      painPoint: lead.painPoint || 'Gestion de la trésorerie',
      bankRec: pick([toolsData[0].name, toolsData[1].name, toolsData[2].name]),
      comptaRec: pick([toolsData[3].name, toolsData[4].name, toolsData[5].name]),
      insurRec: pick([toolsData[6].name, toolsData[7].name]),
      score,
      summary: `Profil ${profileLabels[lead.profile]}, en phase ${phaseLabels[lead.phase || 'reflexion']}. Score de maturité entrepreneurial: ${score}/100.`,
      createdAt: new Date(lead.createdAt.getTime() + randomInt(0, 2) * 86_400_000),
    });
  }
  await prisma.auditResult.createMany({ data: auditBatch });
  console.log(`   ✅ ${auditableLeads.length} résultats d'audit créés\n`);

  // 6. Generate AffiliateClicks — batch
  console.log('🔗 Generating affiliate clicks...');
  const clickBatch: any[] = [];
  let totalClicks = 0;
  let convertedClicks = 0;
  let totalRevenue = 0;

  for (const lead of leads) {
    const clickCount = randomInt(0, 4);
    for (let c = 0; c < clickCount; c++) {
      const tool = pick(Object.values(tools));
      const isConverted = randomInt(0, 100) < 12;
      const revenue = isConverted ? tool.commission * randomFloat(0.8, 1.2) : 0;

      clickBatch.push({
        toolId: tool.id,
        leadId: lead.id,
        sessionId: `sess_${randomInt(100000, 999999)}`,
        ip: `${randomInt(1, 255)}.${randomInt(1, 255)}.${randomInt(1, 255)}.${randomInt(1, 255)}`,
        referer: pick(['google', 'facebook', '100jours.fr', 'instagram', 'direct', 'linkedin', 'twitter']),
        converted: isConverted,
        revenue,
        createdAt: randomDate(0, 30),
      });

      totalClicks++;
      if (isConverted) {
        convertedClicks++;
        totalRevenue += revenue;
      }
    }
  }
  await prisma.affiliateClick.createMany({ data: clickBatch });
  console.log(`   ✅ ${totalClicks} clics affiliés (${convertedClicks} conversions, ${totalRevenue.toFixed(2)}€ revenue)\n`);

  // 7. Create email campaigns — batch
  console.log('📧 Creating email campaigns...');
  const campaignsBatch: any[] = [
    { name: 'Bienvenue Nouveaux Leads', subject: '🚀 Votre parcours entrepreneurial commence ici', segment: 'all', status: 'sent', sentCount: 85, openCount: 62, clickCount: 28, scheduledAt: daysAgo(30), sentAt: daysAgo(30) },
    { name: 'Guide Statut Juridique', subject: '📊 Quel statut choisir ? Le guide complet', segment: 'all', status: 'sent', sentCount: 92, openCount: 55, clickCount: 22, scheduledAt: daysAgo(25), sentAt: daysAgo(25) },
    { name: 'Offre Freelances - Compta', subject: '💡 Offre exclusive Indy pour les freelances', segment: 'freelance', status: 'sent', sentCount: 28, openCount: 19, clickCount: 11, scheduledAt: daysAgo(20), sentAt: daysAgo(20) },
    { name: 'Offre Étudiants - Banque', subject: '🏦 Shine : votre compte pro gratuit', segment: 'etudiant', status: 'sent', sentCount: 22, openCount: 15, clickCount: 8, scheduledAt: daysAgo(15), sentAt: daysAgo(15) },
    { name: 'Checklist 100 Jours', subject: '✅ La checklist de votre lancement en 100 jours', segment: 'all', status: 'scheduled', sentCount: 0, openCount: 0, clickCount: 0, scheduledAt: new Date(Date.now() + 2 * 86_400_000), sentAt: null },
    { name: 'TPE/PME - Assurance Pro', subject: '🛡️ Votre assurance pro à partir de 15€/mois', segment: 'tpe-pme', status: 'draft', sentCount: 0, openCount: 0, clickCount: 0, scheduledAt: null, sentAt: null },
  ];

  for (const camp of campaignsBatch) {
    camp.body = `Bonjour {{firstName}},\n\n${camp.subject}\n\nDécouvrez nos recommandations personnalisées pour votre projet entrepreneurial.\n\nCordialement,\nL'équipe 100 Jours Pour Entreprendre`;
  }
  await prisma.emailCampaign.createMany({ data: campaignsBatch });
  console.log(`   ✅ ${campaignsBatch.length} campagnes créées\n`);

  // 8. Create some UserProgress for demo
  console.log('📈 Creating user progress...');
  const demoUser = await prisma.user.create({
    data: {
      email: 'marie.dupont@example.com',
      name: 'Marie Dupont',
      role: 'user',
    },
  });

  const completedCount = randomInt(4, 10);
  for (let i = 0; i < completedCount && i < tasks.length; i++) {
    await prisma.userProgress.create({
      data: {
        userId: demoUser.id,
        taskId: tasks[i].id,
        completed: true,
        completedAt: daysAgo(randomInt(1, 30)),
      },
    });
  }
  console.log(`   ✅ ${completedCount}/${tasks.length} tâches complétées pour Marie Dupont\n`);

  // ─── SUMMARY ────────────────────────────────────────────────
  console.log('═══════════════════════════════════════════');
  console.log('  🎉 SEED COMPLETED SUCCESSFULLY');
  console.log('═══════════════════════════════════════════');
  console.log(`  👤 Users:       2 (1 admin + 1 demo)`);
  console.log(`  👥 Leads:       ${leads.length}`);
  console.log(`  📊 Audits:      ${auditableLeads.length}`);
  console.log(`  🛠️  Tools:       ${Object.keys(tools).length}`);
  console.log(`  📋 Tasks:       ${tasks.length}`);
  console.log(`  🔗 Clicks:      ${totalClicks} (${convertedClicks} converted)`);
  console.log(`  💰 Revenue:     ${totalRevenue.toFixed(2)}€`);
  console.log(`  📧 Campaigns:   ${campaignsBatch.length}`);
  console.log('═══════════════════════════════════════════\n');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
