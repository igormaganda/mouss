"use client";

import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, ShieldCheck, UserCog, Database, Target, Scale, Clock, Users, Cookie, ListChecks, Lock, RefreshCw, Mail } from "lucide-react";

export default function PolitiqueDeConfidentialitePage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1">
        {/* Hero Banner */}
        <section className="bg-gradient-to-br from-primary/5 via-primary/10 to-background border-b">
          <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <ShieldCheck className="h-5 w-5 text-primary" />
              </div>
              <span className="text-sm font-medium text-primary uppercase tracking-wider">
                Protection des données
              </span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-foreground">
              Politique de Confidentialité
            </h1>
            <p className="mt-3 text-base text-muted-foreground leading-relaxed max-w-2xl">
              GEORGES ERNEST CONSEIL (GEC) s&apos;engage à protéger la vie privée des utilisateurs de crearentreprise.fr. 
              La présente politique détaille les pratiques de collecte, d&apos;utilisation et de protection des données personnelles.
            </p>
          </div>
        </section>

        {/* Content */}
        <section className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          <p className="text-sm text-muted-foreground mb-10">
            Dernière mise à jour : 1<sup>er</sup> janvier 2025
          </p>

          {/* Introduction */}
          <div className="rounded-lg border bg-muted/20 p-5 sm:p-6 mb-10 text-base leading-relaxed text-muted-foreground">
            <p>
              La présente Politique de Confidentialité a pour objet d&apos;informer les utilisateurs du site crearentreprise.fr 
              sur la manière dont GEORGES ERNEST CONSEIL (GEC) collecte, utilise, conserve et protège leurs données personnelles, 
              conformément au Règlement Général sur la Protection des Données (RGPD – Règlement UE 2016/679) et à la loi 
              Informatique et Libertés du 6 janvier 1978 modifiée.
            </p>
          </div>

          {/* 1. Responsable du traitement */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <UserCog className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                1. Responsable du traitement
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                Le responsable du traitement des données personnelles collectées sur le site crearentreprise.fr est :
              </p>
              <div className="rounded-lg border bg-muted/20 p-5 sm:p-6 space-y-2">
                <p>
                  <span className="font-medium text-foreground">Dénomination :</span>{" "}
                  GEORGES ERNEST CONSEIL (GEC)
                </p>
                <p>
                  <span className="font-medium text-foreground">Forme juridique :</span>{" "}
                  SAS
                </p>
                <p>
                  <span className="font-medium text-foreground">SIREN :</span>{" "}
                  830 693 032
                </p>
                <p>
                  <span className="font-medium text-foreground">Siège social :</span>{" "}
                  12 chemin de la Prairie, 91230 MONTGERON, France
                </p>
                <p>
                  <span className="font-medium text-foreground">Contact :</span>{" "}
                  <a href="mailto:contact@crea-entreprise.fr" className="text-primary hover:underline">
                    contact@crea-entreprise.fr
                  </a>
                </p>
              </div>
            </div>
          </div>

          <Separator className="my-8" />

          {/* 2. Données collectées */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <Database className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                2. Données collectées
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                GEORGES ERNEST CONSEIL (GEC) peut collecter les données personnelles suivantes :
              </p>

              <h3 className="text-lg font-medium text-foreground mt-6">a) Données fournies volontairement par l&apos;utilisateur</h3>
              <ul className="list-disc list-inside space-y-1.5 pl-2">
                <li>Nom, prénom</li>
                <li>Adresse électronique</li>
                <li>Numéro de téléphone</li>
                <li>Entreprise ou projet entrepreneurial (nom, secteur d&apos;activité, statut juridique envisagé)</li>
                <li>Informations de paiement (pour les services payants, traitées par des prestataires sécurisés)</li>
              </ul>

              <h3 className="text-lg font-medium text-foreground mt-6">b) Données collectées automatiquement</h3>
              <ul className="list-disc list-inside space-y-1.5 pl-2">
                <li>Adresse IP</li>
                <li>Type et version du navigateur</li>
                <li>Système d&apos;exploitation</li>
                <li>Pages visitées, durée de la visite, date et heure de la consultation</li>
                <li>Source de trafic (site référent)</li>
                <li>Données de localisation approximative (pays, région)</li>
              </ul>

              <h3 className="text-lg font-medium text-foreground mt-6">c) Cookies et technologies similaires</h3>
              <p>
                Le site utilise des cookies pour améliorer l&apos;expérience utilisateur, mesurer l&apos;audience et proposer 
                des contenus adaptés. Pour plus de détails, consultez la section « Cookies et technologies similaires » 
                ci-dessous.
              </p>
            </div>
          </div>

          <Separator className="my-8" />

          {/* 3. Finalités du traitement */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <Target className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                3. Finalités du traitement
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                Les données personnelles sont collectées et traitées pour les finalités suivantes :
              </p>
              <ul className="list-disc list-inside space-y-1.5 pl-2">
                <li>
                  <span className="font-medium text-foreground">Gestion du compte utilisateur :</span> Création, authentification 
                  et gestion du compte personnel sur le site.
                </li>
                <li>
                  <span className="font-medium text-foreground">Fourniture des services :</span> Accès aux contenus, outils, 
                  guides et fonctionnalités du site, y compris les services premium.
                </li>
                <li>
                  <span className="font-medium text-foreground">Envoi de la newsletter :</span> Communication d&apos;informations 
                  éditoriales, conseils et actualités entrepreneuriales, avec le consentement préalable de l&apos;utilisateur.
                </li>
                <li>
                  <span className="font-medium text-foreground">Gestion de la relation client :</span> Réponse aux demandes de 
                  contact, support technique et suivi des échanges.
                </li>
                <li>
                  <span className="font-medium text-foreground">Analyse et amélioration du site :</span> Mesure d&apos;audience, 
                  analyse des comportements de navigation et amélioration de l&apos;ergonomie et des contenus.
                </li>
                <li>
                  <span className="font-medium text-foreground">Sécurité du site :</span> Prévention des fraudes, protection 
                  contre les attaques et garantie de la disponibilité du service.
                </li>
                <li>
                  <span className="font-medium text-foreground">Obligations légales :</span> Réponse aux obligations légales et 
                  réglementaires, exercice de droits de défense, recherche et constatation d&apos;infractions.
                </li>
              </ul>
            </div>
          </div>

          <Separator className="my-8" />

          {/* 4. Base légale */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <Scale className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                4. Base légale du traitement
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                Les traitements de données personnelles sont fondés sur les bases légales suivantes, conformément aux 
                articles 6 et 9 du RGPD :
              </p>
              <ul className="list-disc list-inside space-y-1.5 pl-2">
                <li>
                  <span className="font-medium text-foreground">Consentement (art. 6.1.a) :</span> Pour le traitement des 
                  données liées à la newsletter, aux cookies non essentiels et aux communications commerciales.
                </li>
                <li>
                  <span className="font-medium text-foreground">Exécution du contrat (art. 6.1.b) :</span> Pour la gestion 
                  du compte utilisateur et la fourniture des services souscrits.
                </li>
                <li>
                  <span className="font-medium text-foreground">Intérêt légitime (art. 6.1.f) :</span> Pour l&apos;analyse 
                  d&apos;audience, l&apos;amélioration du site, la sécurité et la prévention des fraudes.
                </li>
                <li>
                  <span className="font-medium text-foreground">Obligation légale (art. 6.1.c) :</span> Pour les traitements 
                  nécessités par des obligations légales ou réglementaires (facturation, lutte contre le blanchiment, etc.).
                </li>
              </ul>
            </div>
          </div>

          <Separator className="my-8" />

          {/* 5. Durée de conservation */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                5. Durée de conservation des données
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                Les données personnelles sont conservées pour une durée proportionnée à la finalité pour laquelle elles 
                ont été collectées :
              </p>
              <ul className="list-disc list-inside space-y-1.5 pl-2">
                <li>
                  <span className="font-medium text-foreground">Données de compte :</span> Conservées pendant toute la durée 
                  de la relation contractuelle, puis pendant 3 ans à compter de la fin de la relation commerciale.
                </li>
                <li>
                  <span className="font-medium text-foreground">Newsletter :</span> Les données liées à l&apos;inscription à la 
                  newsletter sont conservées jusqu&apos;au désabonnement de l&apos;utilisateur.
                </li>
                <li>
                  <span className="font-medium text-foreground">Données de contact :</span> Conservées pendant 2 ans à compter 
                  du dernier contact avec l&apos;utilisateur.
                </li>
                <li>
                  <span className="font-medium text-foreground">Données de navigation (cookies) :</span> Conservation maximale 
                  de 13 mois pour les cookies analytiques et publicitaires.
                </li>
                <li>
                  <span className="font-medium text-foreground">Données de facturation :</span> Conservées pendant 10 ans 
                  conformément aux obligations comptables (art. L123-22 du Code de commerce).
                </li>
                <li>
                  <span className="font-medium text-foreground">Logs de connexion :</span> Conservés pendant 12 mois.
                </li>
              </ul>
              <p>
                À l&apos;expiration des durées de conservation, les données sont supprimées ou anonymisées de manière 
                irréversible.
              </p>
            </div>
          </div>

          <Separator className="my-8" />

          {/* 6. Destinataires des données */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <Users className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                6. Destinataires des données
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                Les données personnelles peuvent être communiquées aux catégories de destinataires suivantes :
              </p>
              <ul className="list-disc list-inside space-y-1.5 pl-2">
                <li>
                  <span className="font-medium text-foreground">Personnel habilité de GEORGES ERNEST CONSEIL (GEC) :</span>{" "}
                  Employés et collaborateurs nécessitant l&apos;accès aux données dans le cadre de leurs fonctions.
                </li>
                <li>
                  <span className="font-medium text-foreground">Prestataires techniques :</span> Hébergeur, fournisseurs de 
                  services d&apos;analyse (Google Analytics), services d&apos;envoi d&apos;emails, prestataires de paiement sécurisé, 
                  sous réserve de contrats de sous-traitance conformes au RGPD.
                </li>
                <li>
                  <span className="font-medium text-foreground">Partenaires commerciaux :</span> Dans le cadre des programmes 
                  d&apos;affiliation, les données strictement nécessaires peuvent être transmises aux partenaires (nom, email) 
                  avec le consentement de l&apos;utilisateur.
                </li>
                <li>
                  <span className="font-medium text-foreground">Autorités compétentes :</span> En cas d&apos;obligation légale, 
                  de décision judiciaire ou de demande des autorités habilitées.
                </li>
              </ul>
              <p>
                GEORGES ERNEST CONSEIL (GEC) s&apos;engage à ne jamais vendre, louer ou échanger les données personnelles 
                de ses utilisateurs à des tiers à des fins commerciales.
              </p>
            </div>
          </div>

          <Separator className="my-8" />

          {/* 7. Cookies et technologies similaires */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <Cookie className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                7. Cookies et technologies similaires
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                Le site crearentreprise.fr utilise des cookies et technologies similaires (pixels, local storage) 
                pour les finalités suivantes :
              </p>

              <h3 className="text-lg font-medium text-foreground mt-6">a) Cookies strictement nécessaires</h3>
              <p>
                Ces cookies sont indispensables au bon fonctionnement du site et ne peuvent pas être désactivés. 
                Ils permettent notamment la navigation, l&apos;authentification et la sécurité du site.
              </p>

              <h3 className="text-lg font-medium text-foreground mt-6">b) Cookies analytiques</h3>
              <p>
                Ces cookies permettent de collecter des informations anonymisées sur la fréquentation du site 
                (nombre de visites, pages consultées, sources de trafic) afin d&apos;en améliorer les performances et 
                les contenus. Ils sont soumis au recueil de votre consentement préalable.
              </p>

              <h3 className="text-lg font-medium text-foreground mt-6">c) Cookies publicitaires et de fonctionnalités</h3>
              <p>
                Ces cookies permettent de proposer des contenus et publicités adaptés aux centres d&apos;intérêt de 
                l&apos;utilisateur. Ils sont soumis au recueil de votre consentement préalable.
              </p>

              <h3 className="text-lg font-medium text-foreground mt-6">Gestion des cookies</h3>
              <p>
                L&apos;utilisateur peut gérer ses préférences en matière de cookies à tout moment via les paramètres 
                de son navigateur. La désactivation de certains cookies peut affecter le fonctionnement du site. 
                Pour plus d&apos;informations sur la gestion des cookies, vous pouvez consulter le site de la CNIL :{" "}
                <a
                  href="https://www.cnil.fr/fr/cookies-et-autres-traceurs"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  https://www.cnil.fr/fr/cookies-et-autres-traceurs
                </a>
                .
              </p>
            </div>
          </div>

          <Separator className="my-8" />

          {/* 8. Droits des personnes concernées */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <ListChecks className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                8. Droits des personnes concernées
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                Conformément au RGPD (articles 15 à 22) et à la loi Informatique et Libertés, chaque utilisateur 
                dispose des droits suivants sur ses données personnelles :
              </p>
              <ul className="list-disc list-inside space-y-1.5 pl-2">
                <li>
                  <span className="font-medium text-foreground">Droit d&apos;accès (art. 15) :</span> Obtenir la confirmation 
                  que des données sont traitées et en recevoir une copie.
                </li>
                <li>
                  <span className="font-medium text-foreground">Droit de rectification (art. 16) :</span> Demander la 
                  correction de données inexactes ou incomplètes.
                </li>
                <li>
                  <span className="font-medium text-foreground">Droit à l&apos;effacement (art. 17) :</span> Demander la 
                  suppression de ses données dans les cas prévus par la réglementation.
                </li>
                <li>
                  <span className="font-medium text-foreground">Droit à la limitation du traitement (art. 18) :</span> 
                  Demander la suspension du traitement de ses données.
                </li>
                <li>
                  <span className="font-medium text-foreground">Droit à la portabilité (art. 20) :</span> Recevoir ses 
                  données dans un format structuré, couramment utilisé et lisible par machine, et les transmettre à un 
                  autre responsable de traitement.
                </li>
                <li>
                  <span className="font-medium text-foreground">Droit d&apos;opposition (art. 21) :</span> S&apos;opposer au 
                  traitement de ses données pour des raisons tenant à sa situation particulière, ou s&apos;opposer à la 
                  prospection commerciale.
                </li>
                <li>
                  <span className="font-medium text-foreground">Droit de retirer son consentement :</span> Retirer à tout 
                  moment son consentement au traitement de ses données, sans que cela ne compromette la licéité du 
                  traitement effectué avant le retrait.
                </li>
                <li>
                  <span className="font-medium text-foreground">Droit à définir des directives post-mortem :</span> Définir 
                  des directives relatives à la conservation, l&apos;effacement et la communication de ses données après son 
                  décès.
                </li>
              </ul>
              <p>
                Pour exercer ces droits, l&apos;utilisateur peut adresser sa demande par email à :{" "}
                <a href="mailto:contact@crea-entreprise.fr" className="text-primary hover:underline font-medium">
                  contact@crea-entreprise.fr
                </a>
                .
              </p>
              <p>
                GEORGES ERNEST CONSEIL (GEC) s&apos;engage à répondre à toute demande dans un délai maximum d&apos;un mois 
                à compter de sa réception. Ce délai peut être prolongé de deux mois supplémentaires pour les demandes 
                complexes, auquel cas l&apos;utilisateur en sera informé.
              </p>
              <p>
                En cas de réponse jugée insatisfaisante, l&apos;utilisateur dispose d&apos;un droit de recours auprès de la 
                Commission Nationale de l&apos;Informatique et des Libertés (CNIL) :{" "}
                <a
                  href="https://www.cnil.fr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  https://www.cnil.fr
                </a>
                .
              </p>
            </div>
          </div>

          <Separator className="my-8" />

          {/* 9. Sécurité des données */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <Lock className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                9. Sécurité des données
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                GEORGES ERNEST CONSEIL (GEC) met en œuvre des mesures techniques et organisationnelles appropriées 
                pour protéger les données personnelles contre la destruction accidentelle ou illicite, la perte, 
                l&apos;altération, la divulgation ou l&apos;accès non autorisé, conformément à l&apos;article 32 du RGPD.
              </p>
              <p>
                Parmi les mesures de sécurité mises en place :
              </p>
              <ul className="list-disc list-inside space-y-1.5 pl-2">
                <li>Chiffrement des données sensibles (notamment les mots de passe) ;</li>
                <li>Utilisation du protocole HTTPS (TLS) pour les échanges de données ;</li>
                <li>Restriction de l&apos;accès aux données aux seules personnes habilitées ;</li>
                <li>Sauvegardes régulières et sécurisées ;</li>
                <li>Mise à jour régulière des logiciels et systèmes de sécurité ;</li>
                <li>Sensibilisation du personnel à la protection des données.</li>
              </ul>
              <p>
                En cas de violation de données à caractère personnel susceptible d&apos;engendrer un risque pour les droits 
                et libertés des personnes, GEORGES ERNEST CONSEIL (GEC) s&apos;engage à notifier la CNIL dans un délai de 
                72 heures et à informer les personnes concernées si la violation présente un risque élevé pour leurs 
                droits et libertés.
              </p>
            </div>
          </div>

          <Separator className="my-8" />

          {/* 10. Modifications de la politique */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <RefreshCw className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                10. Modifications de la politique
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                GEORGES ERNEST CONSEIL (GEC) se réserve le droit de modifier la présente Politique de Confidentialité 
                à tout moment afin de l&apos;adapter aux évolutions légales, réglementaires ou techniques, ou de refléter 
                les modifications apportées aux traitements de données.
              </p>
              <p>
                Toute modification sera signalée par la mise à jour de la date de « Dernière mise à jour » figurant 
                en tête de cette page. L&apos;utilisateur est invité à consulter régulièrement cette page.
              </p>
              <p>
                En cas de modification substantielle, une notification pourra être envoyée aux utilisateurs par email 
                ou via une bannière d&apos;information sur le site.
              </p>
            </div>
          </div>

          <Separator className="my-8" />

          {/* 11. Contact DPO */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <Mail className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">
                11. Contact
              </h2>
            </div>
            <div className="space-y-3 text-base leading-relaxed text-muted-foreground">
              <p>
                Pour toute question relative à la présente Politique de Confidentialité, à l&apos;exercice de vos droits 
                ou au traitement de vos données personnelles, vous pouvez nous contacter par :
              </p>
              <div className="rounded-lg border bg-muted/20 p-5 sm:p-6 space-y-2">
                <p>
                  <span className="font-medium text-foreground">Email :</span>{" "}
                  <a href="mailto:contact@crea-entreprise.fr" className="text-primary hover:underline">
                    contact@crea-entreprise.fr
                  </a>
                </p>
                <p>
                  <span className="font-medium text-foreground">Courrier :</span>{" "}
                  GEORGES ERNEST CONSEIL (GEC)<br />
                  12 chemin de la Prairie<br />
                  91230 MONTGERON, France
                </p>
              </div>
              <p>
                Conformément à l&apos;article 37 du RGPD, GEORGES ERNEST CONSEIL (GEC) n&apos;est pas tenue de désigner un 
                Délégué à la Protection des Données (DPO) au sens du RGPD. Toutefois, les demandes relatives à la 
                protection des données sont traitées avec la plus grande attention par le responsable du traitement.
              </p>
            </div>
          </div>

          {/* Back to home link */}
          <div className="mt-12 pt-8 border-t">
            <a
              href="/"
              className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Retour à l&apos;accueil
            </a>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
