import { Header } from "@/components/header";
import { HeroSection } from "@/components/sections/hero-section";
import { RoadmapSection } from "@/components/sections/roadmap-section";
import { ProfileSection } from "@/components/sections/profile-section";
import { PainPointsSection } from "@/components/sections/pain-points-section";
import { ThematicSection } from "@/components/sections/thematic-section";
import { AuditSection } from "@/components/sections/audit-section";
import { OutilsSection } from "@/components/sections/outils-section";
import { HomeSections } from "@/components/sections/home-sections";
import { Footer } from "@/components/footer";
import { AccompagnementSection } from "@/components/sections/accompagnement-section";
import { ShieldCheck } from "lucide-react";

// ─── TYPES ────────────────────────────────────────────────────────

interface Tool {
  id: string;
  name: string;
  slug: string;
  tagline: string | null;
  description: string | null;
  logoUrl: string | null;
  website: string | null;
  affiliateUrl: string | null;
  commission: number;
  category: string;
  pricing: string;
  rating: number;
  pros: string | null;
  cons: string | null;
  features: string | null;
  active: boolean;
  order: number;
}

interface Pack {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  price: number;
  currency: string;
  features: string[];
  active: boolean;
  order: number;
}

interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string | null;
  coverImage: string | null;
  category: string | null;
  tags: string | null;
  createdAt: string;
  User?: { name: string | null; email: string };
}

// ─── DATA FETCHERS (Server-side) ─────────────────────────────────

async function getTools(): Promise<Tool[]> {
  try {
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const res = await fetch(`${baseUrl}/api/tools?limit=6`, {
      cache: "no-store",
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.tools || [];
  } catch {
    return [];
  }
}

async function getPacks(): Promise<Pack[]> {
  try {
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const res = await fetch(`${baseUrl}/api/packs`, {
      cache: "no-store",
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.packs || [];
  } catch {
    return [];
  }
}

async function getPosts(): Promise<{ posts: Post[]; total: number }> {
  try {
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const res = await fetch(`${baseUrl}/api/posts?limit=3`, {
      cache: "no-store",
    });
    if (!res.ok) return { posts: [], total: 0 };
    const data = await res.json();
    return { posts: data.posts || [], total: data.total || 0 };
  } catch {
    return { posts: [], total: 0 };
  }
}

// ─── PAGE ────────────────────────────────────────────────────────

export default async function Home() {
  const [{ posts, total: totalPosts }, tools, packs] = await Promise.all([
    getPosts(),
    getTools(),
    getPacks(),
  ]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* TOUJOURS VISIBLE — Hero principal */}
        <section id="accueil">
          <HeroSection />
        </section>

        {/* CACHÉ SUR MOBILE — Roadmap (non prioritaire) */}
        <section id="roadmap" className="hidden md:block">
          <RoadmapSection />
        </section>

        {/* CACHÉ SUR MOBILE — Profils entrepreneurs (non prioritaire) */}
        <section id="profils" className="hidden lg:block">
          <ProfileSection />
        </section>

        {/* CACHÉ SUR MOBILE — Pain Points + Solutions thématiques */}
        <section id="solutions" className="hidden md:block">
          <PainPointsSection />
          <ThematicSection />
        </section>

        {/* TOUJOURS VISIBLE — Outils (prioritaire) */}
        <section id="outils">
          <OutilsSection initialTools={tools} />
        </section>

        {/* CACHÉ SUR MOBILE — Tarifs + Blog (via HomeSections) */}
        <div className="hidden md:block">
          <HomeSections
            initialPacks={packs}
            initialPosts={posts}
            totalPosts={totalPosts}
          />
        </div>

        {/* TOUJOURS VISIBLE — Audit CTA (prioritaire) */}
        <section id="audit">
          <AuditSection />
        </section>

        {/* TOUJOURS VISIBLE — Métiers Réglementés Preview */}
        <section className="py-16 sm:py-20 border-t bg-gradient-to-b from-white via-rose-50/20 to-white">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-rose-500/20 bg-rose-50 px-4 py-1.5 text-sm font-medium text-rose-600 mb-4">
                <ShieldCheck className="h-3.5 w-3.5" />
                Secteurs réglementés
              </span>
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Votre métier est réglementé ?
              </h2>
              <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
                Diplômes, autorisations, obligations spécifiques... Découvrez les démarches pour 25 métiers réglementés
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              {[
                { name: "Médecin", href: "/metiers-reglementes/medecin", icon: "🏥" },
                { name: "Avocat", href: "/metiers-reglementes/avocat", icon: "⚖️" },
                { name: "Restaurateur", href: "/metiers-reglementes/restaurateur", icon: "🍽️" },
                { name: "Agent immobilier", href: "/metiers-reglementes/agent-immobilier", icon: "🏠" },
                { name: "Taxi / VTC", href: "/metiers-reglementes/taxi-vtc", icon: "🚗" },
                { name: "Infirmier", href: "/metiers-reglementes/infirmier", icon: "❤️" },
                { name: "Expert-comptable", href: "/metiers-reglementes/expert-comptable", icon: "🧮" },
                { name: "BTP Artisan", href: "/metiers-reglementes/btp-artisan", icon: "🏗️" },
                { name: "Coiffeur", href: "/metiers-reglementes/coiffeur", icon: "✂️" },
                { name: "Coach sportif", href: "/metiers-reglementes/coach-sportif", icon: "💪" },
              ].map((profession) => (
                <a
                  key={profession.name}
                  href={profession.href}
                  className="group flex flex-col items-center gap-2 rounded-xl border border-border/60 bg-white p-4 transition-all duration-300 hover:shadow-md hover:-translate-y-1 text-center"
                >
                  <span className="text-3xl">{profession.icon}</span>
                  <span className="text-sm font-medium text-foreground group-hover:text-rose-600 transition-colors">
                    {profession.name}
                  </span>
                </a>
              ))}
            </div>

            <div className="mt-10 text-center">
              <a
                href="/metiers-reglementes"
                className="inline-flex items-center gap-2 text-base font-semibold text-rose-600 hover:text-rose-700 transition-colors"
              >
                Découvrir les 25 métiers réglementés →
              </a>
            </div>
          </div>
        </section>

        {/* TOUJOURS VISIBLE — Accompagnement Catalogue */}
        <AccompagnementSection />
      </main>
      <Footer />
    </div>
  );
}
