import { PrismaClient } from '@prisma/client'

// Force PostgreSQL URL (system env overrides .env with SQLite path)
process.env.DATABASE_URL = "postgresql://admin_100jours:J0urs%212026%2ACent@109.123.249.114:5432/100jours"

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
