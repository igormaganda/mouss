"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  FileQuestion,
  Wallet,
  Calculator,
  ShieldAlert,
  ArrowRight,
  CheckCircle2,
  Eye,
  TrendingUp,
  Banknote,
  Users,
  AlertTriangle,
  BarChart3,
} from "lucide-react";

type Severity = "high" | "medium" | "low";

const painPoints: {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  color: string;
  solutions: string[];
  affiliatePartners: string[];
  severity: Severity;
}[] = [
  {
    id: "administratif",
    icon: FileQuestion,
    title: "Je suis perdu dans l'administratif",
    description:
      "Trop de demarches, trop de jargon, trop de Paperasse. Trouvez votre chemin avec notre guide structuré.",
    color: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
    solutions: [
      "Création clé en main en ligne",
      "Guides pas-a-pas par statut",
      "Assistance juridique illimitee",
      "Templates de documents",
    ],
    affiliatePartners: ["Legalstart", "Captain Contrat"],
    severity: "high",
  },
  {
    id: "frais-bancaires",
    icon: Wallet,
    title: "Mes frais bancaires sont trop eleves",
    description:
      "Les banques traditionnelles prélèvent des frais disproportionnés. Comparez les offres gratuites et sans conditions.",
    color: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
    solutions: [
      "Comparatif des banques pro gratuites",
      "Carte CB sans frais a l'etranger",
      "Virements SEPA gratuits et illimites",
      "Sous-comptes et budget intelligent",
    ],
    affiliatePartners: ["Qonto", "Shine", "N26 Business"],
    severity: "medium",
  },
  {
    id: "compta",
    icon: Calculator,
    title: "Je n'ai pas le temps pour ma compta",
    description:
      "La compta vous fait perdre des heures precieuses. Automatisez-la grace a la synchronisation bancaire intelligente.",
    color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400",
    solutions: [
      "Synchronisation bancaire automatique",
      "Categorisation intelligente des ecritures",
      "Declarations URSSAF automatiques",
      "Bilan et compte de resultat en 1 clic",
    ],
    affiliatePartners: ["Indy", "Tiime", "Freebe"],
    severity: "medium",
  },
  {
    id: "juridique",
    icon: ShieldAlert,
    title: "Je crains les risques juridiques",
    description:
      "Une erreur juridique peut couter cher. Protégez votre activité avec les assurances adaptées a votre métier.",
    color: "bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-400",
    solutions: [
      "RC Pro par métier (VTC, IT, Artisan)",
      "Mutuelle TNS & prévoyance",
      "Assurance décennale obligatoire",
      "Protection juridique entreprise",
    ],
    affiliatePartners: ["Hiscox", "Simplit", "Abeille Assurances"],
    severity: "high",
  },
  {
    id: "visibilite",
    icon: Eye,
    title: "Je n'arrive pas à trouver des clients",
    description:
      "Vous avez un produit/service de qualité mais personne ne vous trouve. Sans stratégie d'acquisition, même le meilleur produit ne se vend pas.",
    color: "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-400",
    solutions: [
      "Stratégie SEO référencement Google",
      "Publicité ciblée Google Ads & Meta Ads",
      "Community management réseaux sociaux",
      "Landing pages optimisées conversion",
    ],
    affiliatePartners: ["Google Ads", "Meta", "Canva Pro"],
    severity: "high",
  },
  {
    id: "perennite",
    icon: TrendingUp,
    title: "Je crains pour la pérennité de mon entreprise",
    description:
      "25% des entreprises échouent avant leur 3ème année. Sans pilotage financier et accompagnement stratégique, vous naviguez à vue.",
    color: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
    solutions: [
      "Business plan prévisionnel",
      "Copilote entreprise coaching",
      "DAF externalisé pilotage",
      "Tableau de bord KPIs",
    ],
    affiliatePartners: ["Pennylane", "Qonto"],
    severity: "high",
  },
  {
    id: "impayes",
    icon: Banknote,
    title: "Mes factures ne sont pas payées",
    description:
      "Les retards de paiement menacent votre trésorerie. En France, le délai moyen de paiement est de 45 jours et les impayés représentent 25% des défaillances de TPE.",
    color: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400",
    solutions: [
      "Relances automatisées",
      "Recouvrement amiable au succès",
      "Scoring clients préventif",
      "Conditions de vente renforcées",
    ],
    affiliatePartners: ["Hiscox"],
    severity: "high",
  },
  {
    id: "isolement",
    icon: Users,
    title: "Je suis seul et je perds le nord",
    description:
      "Diriger une entreprise seul, c'est épuisant. Sans réseau, sans mentor, sans soutien, les décisions sont plus difficiles et les erreurs plus fréquentes.",
    color: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400",
    solutions: [
      "Copilote entreprise sur-mesure",
      "Formations dirigeants",
      "Communauté d'entrepreneurs",
      "Mise en relation partenaires",
    ],
    affiliatePartners: [],
    severity: "medium",
  },
];

const severityConfig: Record<Severity, { label: string; className: string }> = {
  high: {
    label: "Impact critique",
    className: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400 border-rose-200",
  },
  medium: {
    label: "Impact modéré",
    className: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200",
  },
  low: {
    label: "Impact faible",
    className: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-emerald-200",
  },
};

const socialProofStats = [
  { icon: AlertTriangle, text: "57% des créateurs abandonnent à cause de l'administratif", color: "text-rose-500" },
  { icon: Wallet, text: "3 200€/an de frais bancaires en moyenne pour une TPE", color: "text-amber-500" },
  { icon: Banknote, text: "25% des faillites causées par des impayés clients", color: "text-rose-500" },
  { icon: BarChart3, text: "Seul 1 entrepreneur sur 4 a un business plan", color: "text-violet-500" },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

function AnimatedCounter({ target, duration = 2000 }: { target: number; duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [inView, target, duration]);

  return <span ref={ref}>{count.toLocaleString("fr-FR")}</span>;
}

export function PainPointsSection() {
  return (
    <section id="solutions" className="hidden md:block py-10 sm:py-14 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          {/* Urgency Badge */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Badge
              variant="outline"
              className="mb-4 px-4 py-2 text-sm font-semibold border-primary/40 text-primary bg-primary/5 animate-pulse"
            >
              🔍 Audit gratuit — résultats personnalisés en 2 min
            </Badge>
          </motion.div>

          <Badge
            variant="outline"
            className="mb-4 px-4 py-1.5 text-sm font-medium border-primary/30 text-primary"
          >
            Vos Frustrations
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Quelle est votre plus grande difficulte ?
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Cibler votre frustration nous permet de vous orienter vers la
            solution la plus pertinente. Pas de perte de temps, juste des
            resultats concrets.
          </p>
        </div>

        {/* Social Proof Stats Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-10"
        >
          {socialProofStats.map((stat, idx) => (
            <div
              key={idx}
              className="flex items-center gap-3 rounded-xl border bg-muted/30 px-4 py-3"
            >
              <stat.icon className={`h-5 w-5 shrink-0 ${stat.color}`} />
              <p className="text-xs font-medium text-muted-foreground leading-snug">
                {stat.text}
              </p>
            </div>
          ))}
        </motion.div>

        {/* Pain Point Cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {painPoints.map((pain) => {
            const sev = severityConfig[pain.severity];
            return (
              <motion.div key={pain.id} variants={itemVariants}>
                <Card className="group h-full transition-all duration-300 hover:shadow-xl hover:border-primary/20 hover:-translate-y-1.5 hover:scale-[1.02] relative overflow-hidden">
                  {/* Severity Badge */}
                  <div className="absolute top-3 right-3 z-10">
                    <Badge
                      variant="outline"
                      className={`text-[10px] font-semibold px-2 py-0.5 border ${sev.className}`}
                    >
                      {sev.label}
                    </Badge>
                  </div>

                  <CardHeader className="pb-3">
                    <div className="flex items-start gap-4">
                      <div
                        className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${pain.color}`}
                      >
                        <pain.icon className="h-6 w-6" />
                      </div>
                      <div className="flex-1 pr-20">
                        <CardTitle className="text-lg leading-snug">
                          {pain.title}
                        </CardTitle>
                        <CardDescription className="text-sm mt-1.5 leading-relaxed">
                          {pain.description}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Solutions list */}
                    <div className="space-y-2">
                      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        Ce que nous vous proposons
                      </p>
                      {pain.solutions.map((sol) => (
                        <div
                          key={sol}
                          className="flex items-start gap-2.5 text-sm"
                        >
                          <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                          <span className="text-foreground/80">{sol}</span>
                        </div>
                      ))}
                    </div>

                    {/* Partners */}
                    {pain.affiliatePartners.length > 0 && (
                      <div className="pt-3 border-t flex items-center justify-between">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs text-muted-foreground">
                            Partenaires :
                          </span>
                          <div className="flex gap-1.5 flex-wrap">
                            {pain.affiliatePartners.map((partner) => (
                              <Badge
                                key={partner}
                                variant="secondary"
                                className="text-xs font-normal"
                              >
                                {partner}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <a href="#audit" className="shrink-0">
                          <span className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:gap-2 transition-all">
                            Comparer
                            <ArrowRight className="h-4 w-4" />
                          </span>
                        </a>
                      </div>
                    )}
                    {pain.affiliatePartners.length === 0 && (
                      <div className="pt-3 border-t flex items-center justify-end">
                        <a href="#audit" className="shrink-0">
                          <span className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:gap-2 transition-all">
                            Comparer
                            <ArrowRight className="h-4 w-4" />
                          </span>
                        </a>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-12"
        >
          <a href="#audit">
            <motion.div
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center gap-3 rounded-2xl bg-primary px-8 py-4 text-lg font-semibold text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-shadow"
            >
              Identifiez vos points faibles
              <ArrowRight className="h-5 w-5" />
              <span className="opacity-90">Commencer l&apos;audit gratuit</span>
            </motion.div>
          </a>
          <p className="mt-3 text-sm text-muted-foreground">
            <AnimatedCounter target={12847} /> entrepreneurs ont déjà identifié leurs points faibles
          </p>
        </motion.div>
      </div>
    </section>
  );
}
