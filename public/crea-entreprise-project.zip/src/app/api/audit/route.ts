import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { z } from "zod";

const auditSchema = z.object({
  email: z.string().email("Email invalide"),
  firstName: z.string().min(1, "Le prenom est requis"),
  lastName: z.string().optional(),
  profile: z.enum(["etudiant", "salarie", "freelance", "tpe-pme"]),
  phase: z.enum(["reflexion", "creation", "gestion", "croissance"]),
  painPoint: z.string().min(1),
  projectName: z.string().optional(),
  phone: z.string().optional(),
  consent: z.boolean().default(true),
});

// Profile-based tool recommendations mapped by category
const RECOMMENDATIONS: Record<
  string,
  { bank: string[]; compta: string[]; insur: string[] }
> = {
  etudiant: {
    bank: ["shine", "n26", "lydia"],
    compta: ["indy", "abby"],
    insur: ["alan", "wam"],
  },
  salarie: {
    bank: ["hellobank", "boursorama", "fortuneo"],
    compta: ["shine", "qonto"],
    insur: ["alan", "luko"],
  },
  freelance: {
    bank: ["shine", "qonto", "blank"],
    compta: ["abby", "indie-ccounting", "dext"],
    insur: ["alan", "wam", "hippo"],
  },
  "tpe-pme": {
    bank: ["qonto", "blank", "shinhan"],
    compta: ["penelope", "abby", "sellsy"],
    insur: ["hiscox", "simply-business"],
  },
};

// Score calculation based on phase maturity
const PHASE_SCORES: Record<string, number> = {
  reflexion: 30,
  creation: 50,
  gestion: 70,
  croissance: 90,
};

function generateRecommendations(profile: string, phase: string) {
  const recs = RECOMMENDATIONS[profile] || RECOMMENDATIONS.etudiant;
  const baseScore = PHASE_SCORES[phase] || 40;

  // Add some randomness (±10)
  const score = Math.min(100, Math.max(0, baseScore + Math.floor(Math.random() * 21) - 10));

  const summaries: Record<string, Record<string, string>> = {
    reflexion: {
      etudiant:
        "Vous etes en phase de réflexion. Nous vous recommandons de commencer par ouvrir un compte bancaire adapté et de comprendre vos obligations comptables de base.",
      salarie:
        "En réflexion sur l'entrepreneuriat, prenez le temps de comparer les offres bancaires professionnelles et d'évaluer vos besoins d'assurance.",
      freelance:
        "Votre projet freelance nécessite une base solide. Choisissez une banque et une solution comptable adaptées avant de vous lancer.",
      "tpe-pme":
        "En phase de réflexion pour votre TPE/PME, évaluez les outils bancaires et comptables qui faciliteront votre démarrage.",
    },
    creation: {
      etudiant:
        "Votre projet est en création ! Il est temps de choisir vos outils bancaires et comptables pour démarrer sur de bonnes bases.",
      salarie:
        "Vous passez a l'action ! Sélectionnez une banque pro et une assurance pour protéger votre nouvelle activité.",
      freelance:
        "Bienvenue dans la création ! Optez pour des outils simples et efficaces pour gérer votre activité freelance au quotidien.",
      "tpe-pme":
        "Phase de création active. Structurez votre TPE/PME avec les bons partenaires bancaires et comptables.",
    },
    gestion: {
      etudiant:
        "Votre activité est lancée. Optimisez votre gestion quotidienne avec les bons outils comptables et bancaires.",
      salarie:
        "En phase de gestion, assurez-vous d'avoir les bons outils pour suivre votre activite et vos finances.",
      freelance:
        "Votre activite freelance tourne. Concentrez-vous sur l'optimisation de votre compta et la couverture assurance.",
      "tpe-pme":
        "Phase de gestion pour votre PME. Structurez vos processus financiers et optimisez vos couts.",
    },
    croissance: {
      etudiant:
        "Votre activité grandit ! Pensez à passer a des outils plus avancés pour accompagner votre croissance.",
      salarie:
        "En phase de croissance, il est temps d'optimiser vos outils et de rechercher des solutions plus complètes.",
      freelance:
        "Félicitations, votre freelance grandit ! Passez à l'échelle supérieure avec des outils adaptes a votre volume.",
      "tpe-pme":
        "Votre PME est en croissance ! Investissez dans des outils bancaires et comptables de niveau entreprise.",
    },
  };

  const summary =
    summaries[phase]?.[profile] ||
    "Analyse complète de votre profil entrepreneurial.";

  return {
    bankRec: recs.bank[0] || null,
    comptaRec: recs.compta[0] || null,
    insurRec: recs.insur[0] || null,
    score,
    summary,
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Validate input
    const result = auditSchema.safeParse(body);
    if (!result.success) {
      return NextResponse.json(
        { error: "Donnees invalides", details: result.error.flatten() },
        { status: 400 }
      );
    }

    const data = result.data;

    // Generate audit recommendations
    const recommendations = generateRecommendations(data.profile, data.phase);

    // Check if lead already exists by email
    const existingLead = await db.lead.findUnique({
      where: { email: data.email },
      include: { auditResult: true },
    });

    if (existingLead) {
      // Update existing lead with new data
      await db.lead.update({
        where: { email: data.email },
        data: {
          firstName: data.firstName,
          lastName: data.lastName || null,
          profile: data.profile,
          phase: data.phase,
          painPoint: data.painPoint,
          projectName: data.projectName || null,
          consent: data.consent,
        },
      });

      // Update or create audit result
      if (existingLead.auditResult) {
        await db.auditResult.update({
          where: { leadId: existingLead.id },
          data: {
            profile: data.profile,
            phase: data.phase,
            painPoint: data.painPoint,
            bankRec: recommendations.bankRec,
            comptaRec: recommendations.comptaRec,
            insurRec: recommendations.insurRec,
            score: recommendations.score,
            summary: recommendations.summary,
          },
        });
      } else {
        await db.auditResult.create({
          data: {
            leadId: existingLead.id,
            profile: data.profile,
            phase: data.phase,
            painPoint: data.painPoint,
            bankRec: recommendations.bankRec,
            comptaRec: recommendations.comptaRec,
            insurRec: recommendations.insurRec,
            score: recommendations.score,
            summary: recommendations.summary,
          },
        });
      }

      return NextResponse.json({
        success: true,
        message: "Audit mis à jour avec succès",
        isNew: false,
        auditResult: recommendations,
      });
    }

    // Create new lead
    const lead = await db.lead.create({
      data: {
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName || null,
        profile: data.profile,
        phase: data.phase,
        painPoint: data.painPoint,
        projectName: data.projectName || null,
        phone: data.phone || null,
        consent: data.consent,
      },
    });

    // Create audit result
    await db.auditResult.create({
      data: {
        leadId: lead.id,
        profile: data.profile,
        phase: data.phase,
        painPoint: data.painPoint,
        bankRec: recommendations.bankRec,
        comptaRec: recommendations.comptaRec,
        insurRec: recommendations.insurRec,
        score: recommendations.score,
        summary: recommendations.summary,
      },
    });

    return NextResponse.json(
      {
        success: true,
        message: "Audit créé avec succès",
        isNew: true,
        leadId: lead.id,
        auditResult: recommendations,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Audit API error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const leads = await db.lead.findMany({
      orderBy: { createdAt: "desc" },
      take: 50,
      include: { auditResult: true },
    });

    return NextResponse.json({
      success: true,
      count: leads.length,
      leads,
    });
  } catch (error) {
    console.error("Audit GET error:", error);
    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}
