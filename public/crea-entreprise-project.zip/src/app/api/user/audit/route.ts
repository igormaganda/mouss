import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Non autorise" }, { status: 401 });
    }

    const userEmail = session.user.email;

    // Find the lead with this email that has an audit result
    const lead = await db.lead.findUnique({
      where: { email: userEmail! },
      include: { auditResult: true },
    });

    if (!lead || !lead.auditResult) {
      return NextResponse.json({ auditResult: null });
    }

    // Also fetch the recommended tools details
    const toolSlugs = [
      lead.auditResult.bankRec,
      lead.auditResult.comptaRec,
      lead.auditResult.insurRec,
    ].filter(Boolean) as string[];

    const tools = toolSlugs.length > 0
      ? await db.tool.findMany({
          where: { slug: { in: toolSlugs } },
        })
      : [];

    return NextResponse.json({
      auditResult: lead.auditResult,
      lead: {
        id: lead.id,
        email: lead.email,
        firstName: lead.firstName,
        lastName: lead.lastName,
        profile: lead.profile,
        phase: lead.phase,
      },
      tools,
    });
  } catch (error) {
    console.error("User audit fetch error:", error);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
