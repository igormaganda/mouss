import { Header } from "@/components/header";
import { HeroSection } from "@/components/sections/hero-section";
import { RoadmapSection } from "@/components/sections/roadmap-section";
import { ProfileSection } from "@/components/sections/profile-section";
import { PainPointsSection } from "@/components/sections/pain-points-section";
import { ThematicSection } from "@/components/sections/thematic-section";
import { AuditSection } from "@/components/sections/audit-section";
import { OutilsSection } from "@/components/sections/outils-section";
import { HomeSections } from "@/components/sections/home-sections";
import { Footer } from "@/components/footer";

// ─── TYPES ────────────────────────────────────────────────────────

interface Tool {
  id: string;
  name: string;
  slug: string;
  tagline: string | null;
  description: string | null;
  logoUrl: string | null;
  website: string | null;
  affiliateUrl: string | null;
  commission: number;
  category: string;
  pricing: string;
  rating: number;
  pros: string | null;
  cons: string | null;
  features: string | null;
  active: boolean;
  order: number;
}

interface Pack {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  price: number;
  currency: string;
  features: string[];
  active: boolean;
  order: number;
}

interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string | null;
  coverImage: string | null;
  category: string | null;
  tags: string | null;
  createdAt: string;
  User?: { name: string | null; email: string };
}

// ─── DATA FETCHERS (Server-side) ─────────────────────────────────

async function getTools(): Promise<Tool[]> {
  try {
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const res = await fetch(`${baseUrl}/api/tools?limit=6`, {
      cache: "no-store",
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.tools || [];
  } catch {
    return [];
  }
}

async function getPacks(): Promise<Pack[]> {
  try {
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const res = await fetch(`${baseUrl}/api/packs`, {
      cache: "no-store",
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.packs || [];
  } catch {
    return [];
  }
}

async function getPosts(): Promise<{ posts: Post[]; total: number }> {
  try {
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const res = await fetch(`${baseUrl}/api/posts?limit=3`, {
      cache: "no-store",
    });
    if (!res.ok) return { posts: [], total: 0 };
    const data = await res.json();
    return { posts: data.posts || [], total: data.total || 0 };
  } catch {
    return { posts: [], total: 0 };
  }
}

// ─── PAGE ────────────────────────────────────────────────────────

export default async function Home() {
  const [{ posts, total: totalPosts }, tools, packs] = await Promise.all([
    getPosts(),
    getTools(),
    getPacks(),
  ]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* TOUJOURS VISIBLE — Hero principal */}
        <section id="accueil">
          <HeroSection />
        </section>

        {/* CACHÉ SUR MOBILE — Roadmap (non prioritaire) */}
        <section id="roadmap" className="hidden md:block">
          <RoadmapSection />
        </section>

        {/* CACHÉ SUR MOBILE — Profils entrepreneurs (non prioritaire) */}
        <section id="profils" className="hidden lg:block">
          <ProfileSection />
        </section>

        {/* CACHÉ SUR MOBILE — Pain Points + Solutions thématiques */}
        <section id="solutions" className="hidden md:block">
          <PainPointsSection />
          <ThematicSection />
        </section>

        {/* TOUJOURS VISIBLE — Outils (prioritaire) */}
        <section id="outils">
          <OutilsSection initialTools={tools} />
        </section>

        {/* CACHÉ SUR MOBILE — Tarifs + Blog (via HomeSections) */}
        <div className="hidden md:block">
          <HomeSections
            initialPacks={packs}
            initialPosts={posts}
            totalPosts={totalPosts}
          />
        </div>

        {/* TOUJOURS VISIBLE — Audit CTA (prioritaire) */}
        <section id="audit">
          <AuditSection />
        </section>
      </main>
      <Footer />
    </div>
  );
}
