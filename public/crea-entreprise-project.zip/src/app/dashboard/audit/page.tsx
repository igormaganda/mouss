"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ArrowRight,
  Building2,
  Calculator,
  Shield,
  ClipboardCheck,
  Target,
  AlertCircle,
  ExternalLink,
  TrendingUp,
} from "lucide-react";

interface AuditData {
  auditResult: {
    id: string;
    profile: string;
    phase: string;
    painPoint: string;
    score: number;
    summary: string | null;
    bankRec: string | null;
    comptaRec: string | null;
    insurRec: string | null;
    createdAt: string;
  } | null;
  lead: {
    id: string;
    email: string;
    firstName: string | null;
    lastName: string | null;
    profile: string;
    phase: string;
  } | null;
  tools: Array<{
    id: string;
    name: string;
    slug: string;
    tagline: string | null;
    description: string | null;
    category: string;
    affiliateUrl: string | null;
    website: string | null;
    rating: number;
    pricing: string;
  }>;
}

const PROFILE_LABELS: Record<string, string> = {
  etudiant: "Etudiant",
  salarie: "Salarié",
  freelance: "Freelance",
  "tpe-pme": "TPE / PME",
};

const PHASE_LABELS: Record<string, string> = {
  reflexion: "Phase 1 — Réflexion",
  creation: "Phase 2 — Création",
  gestion: "Phase 3 — Gestion",
  croissance: "Phase 4 — Croissance",
};

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.1 } },
};
const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
};

function CircularScore({ score }: { score: number }) {
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  const color =
    score >= 70
      ? "text-emerald-500"
      : score >= 40
        ? "text-amber-500"
        : "text-red-500";

  return (
    <div className="relative flex items-center justify-center">
      <svg width="130" height="130" className="-rotate-90">
        <circle
          cx="65"
          cy="65"
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth="8"
          className="text-muted/20"
        />
        <circle
          cx="65"
          cy="65"
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth="8"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className={color}
          style={{ transition: "stroke-dashoffset 1s ease" }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-3xl font-bold">{score}</span>
        <span className="text-xs text-muted-foreground">/ 100</span>
      </div>
    </div>
  );
}

export default function AuditPage() {
  const router = useRouter();
  const [data, setData] = useState<AuditData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchAudit() {
      try {
        const res = await fetch("/api/user/audit");
        if (res.ok) {
          const json = await res.json();
          setData(json);
        }
      } catch (err) {
        console.error("Audit fetch error:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchAudit();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-64 bg-muted rounded" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-48 bg-muted rounded-lg" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!data?.auditResult) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Aucun audit trouvé</h2>
            <p className="text-muted-foreground mb-6">
              Complétez votre audit depuis la page d&apos;accueil pour obtenir vos recommandations personnalisées.
            </p>
            <Button
              className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
              onClick={() => router.push("/#audit")}
            >
              <ClipboardCheck className="h-4 w-4" />
              Commencer l&apos;audit
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const auditResult = data.auditResult;
  const tools = data.tools || [];

  const categoryConfig: Record<string, { icon: React.ReactNode; label: string; color: string }> = {
    bank: {
      icon: <Building2 className="h-6 w-6" />,
      label: "Banque",
      color: "text-blue-600 bg-blue-50 dark:text-blue-400 dark:bg-blue-950/30",
    },
    compta: {
      icon: <Calculator className="h-6 w-6" />,
      label: "Comptabilité",
      color: "text-purple-600 bg-purple-50 dark:text-purple-400 dark:bg-purple-950/30",
    },
    assurance: {
      icon: <Shield className="h-6 w-6" />,
      label: "Assurance",
      color: "text-orange-600 bg-orange-50 dark:text-orange-400 dark:bg-orange-950/30",
    },
  };

  const handleDiscover = async (tool: (typeof tools)[0]) => {
    try {
      const res = await fetch("/api/click", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ toolSlug: tool.slug }),
      });
      const result = await res.json();
      if (result.redirectUrl) {
        window.open(result.redirectUrl, "_blank");
      }
    } catch {
      if (tool.website) window.open(tool.website, "_blank");
    }
  };

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="space-y-8">
      <motion.div variants={item}>
        <h1 className="text-2xl sm:text-3xl font-bold">Mon Audit</h1>
        <p className="text-muted-foreground mt-1">
          Résultats et recommandations personnalisées
        </p>
      </motion.div>

      {/* Profile & Score */}
      <motion.div variants={item} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Profile info */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-emerald-600" />
              Votre profil
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Profil</p>
                <Badge variant="secondary" className="mt-1">
                  {PROFILE_LABELS[auditResult.profile] || auditResult.profile}
                </Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Phase</p>
                <p className="font-medium mt-1">
                  {PHASE_LABELS[auditResult.phase] || auditResult.phase}
                </p>
              </div>
              <div className="col-span-2">
                <p className="text-sm text-muted-foreground">Point de douleur principal</p>
                <p className="font-medium mt-1">{auditResult.painPoint}</p>
              </div>
            </div>
            {auditResult.summary && (
              <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-4 dark:bg-emerald-950/20 dark:border-emerald-800">
                <p className="text-sm leading-relaxed">{auditResult.summary}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Right: Score */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-emerald-600" />
              Score
            </CardTitle>
            <CardDescription>Maturite entrepreneuriale</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-4">
            <CircularScore score={auditResult.score} />
            <p className="text-sm text-muted-foreground mt-3 text-center">
              {auditResult.score >= 70
                ? "Vous etes sur la bonne voie !"
                : auditResult.score >= 40
                  ? "De bons progres, continuez !"
                  : "Debut prometteur, beaucoup de potentiel !"}
            </p>
          </CardContent>
        </Card>
      </motion.div>

      {/* Recommendations */}
      <motion.div variants={item}>
        <h2 className="text-xl font-bold mb-4">Recommandations personnalisées</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {tools.map((tool) => {
            const config = categoryConfig[tool.category] || {
              icon: <ExternalLink className="h-6 w-6" />,
              label: "Outil",
              color: "text-gray-600 bg-gray-50",
            };

            return (
              <Card key={tool.id} className="group hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${config.color}`}>
                      {config.icon}
                    </div>
                    <div>
                      <Badge variant="outline" className="text-xs mb-1">
                        {config.label}
                      </Badge>
                      <CardTitle className="text-lg">{tool.name}</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {tool.tagline && (
                    <p className="text-sm text-muted-foreground">{tool.tagline}</p>
                  )}
                  {tool.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {tool.description}
                    </p>
                  )}
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary" className="text-xs">
                      {tool.pricing === "gratuit" ? "Gratuit" : tool.pricing}
                    </Badge>
                    {tool.rating > 0 && (
                      <span className="text-xs text-muted-foreground">
                        ⭐ {tool.rating.toFixed(1)}
                      </span>
                    )}
                  </div>
                  <Button
                    size="sm"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
                    onClick={() => handleDiscover(tool)}
                  >
                    Decouvrir
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </motion.div>
    </motion.div>
  );
}
