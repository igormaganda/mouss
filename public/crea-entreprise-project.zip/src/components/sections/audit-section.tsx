"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  ClipboardCheck,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Mail,
  User,
  Briefcase,
  Lightbulb,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";

const profileOptions = [
  {
    value: "etudiant",
    label: "Etudiant Entrepreneur",
    icon: User,
    description: "Etudier et entreprendre en parallele",
  },
  {
    value: "salarie",
    label: "Salarie en Transition",
    icon: Briefcase,
    description: "Securiser le lancement avant de quitter",
  },
  {
    value: "freelance",
    label: "Freelance / Auto-entrepreneur",
    icon: Lightbulb,
    description: "Simplicité et gratuité pour démarrer",
  },
  {
    value: "tpe-pme",
    label: "TPE / PME",
    icon: Briefcase,
    description: "Gestion d'equipe et flux complexes",
  },
];

const phaseOptions = [
  {
    value: "reflexion",
    label: "Réflexion (J1-J15)",
    description: "Je cherche mon idee ou valide mon business model",
  },
  {
    value: "creation",
    label: "Création (J31-J60)",
    description: "Je lance les demarches administratives",
  },
  {
    value: "gestion",
    label: "Gestion (J61-J80)",
    description: "J'optimise mon organisation et ma compta",
  },
  {
    value: "croissance",
    label: "Croissance (J81-J100)",
    description: "Je veux accelerer mon impact",
  },
];

const painPointOptions = [
  { value: "administratif", label: "Perdu dans l'administratif" },
  { value: "frais-bancaires", label: "Frais bancaires trop eleves" },
  { value: "compta", label: "Pas le temps pour la compta" },
  { value: "juridique", label: "Risques juridiques" },
  { value: "autre", label: "Autre preoccupation" },
];

const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 300 : -300,
    opacity: 0,
  }),
  center: {
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => ({
    x: direction < 0 ? 300 : -300,
    opacity: 0,
  }),
};

export function AuditSection() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);
  const [direction, setDirection] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const [formData, setFormData] = useState({
    profile: "",
    phase: "",
    painPoint: "",
    email: "",
    firstName: "",
    lastName: "",
    projectName: "",
    consent: true,
  });

  const totalSteps = 4;
  const canGoNext = () => {
    switch (step) {
      case 0:
        return formData.profile !== "";
      case 1:
        return formData.phase !== "";
      case 2:
        return formData.painPoint !== "";
      case 3:
        return (
          formData.email !== "" &&
          formData.email.includes("@") &&
          formData.firstName !== ""
        );
      default:
        return false;
    }
  };

  const goNext = () => {
    if (step < totalSteps - 1 && canGoNext()) {
      setDirection(1);
      setStep(step + 1);
    }
  };

  const goPrev = () => {
    if (step > 0) {
      setDirection(-1);
      setStep(step - 1);
    }
  };

  const handleSubmit = async () => {
    if (!canGoNext()) return;
    setIsSubmitting(true);

    try {
      const res = await fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!res.ok) {
        throw new Error("Erreur lors de l'envoi");
      }

      setIsSubmitted(true);
      toast.success("Votre audit a ete généré avec succès !");
    } catch {
      toast.error("Une erreur est survenue. Veuillez reessayer.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && canGoNext() && step < totalSteps - 1) {
      goNext();
    }
    if (e.key === "Enter" && step === totalSteps - 1 && canGoNext()) {
      handleSubmit();
    }
  };

  const resetForm = () => {
    setStep(0);
    setIsSubmitted(false);
    setFormData({
      profile: "",
      phase: "",
      painPoint: "",
      email: "",
      firstName: "",
      lastName: "",
      projectName: "",
      consent: true,
    });
    setOpen(false);
  };

  return (
    <section id="audit" className="py-10 sm:py-14 bg-background relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 h-96 w-96 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute bottom-0 right-1/4 h-96 w-96 rounded-full bg-amber-500/5 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge className="mb-4 px-4 py-1.5 text-sm font-medium bg-primary text-primary-foreground">
            <Sparkles className="h-3.5 w-3.5 mr-1.5" />
            Gratuit & Personnalisé
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
            Générez votre Audit de Lancement Gratuit
          </h2>
          <p className="mt-5 text-lg sm:text-xl text-muted-foreground leading-relaxed">
            En 2 minutes, nous analysons votre situation et vous recommandons
            le pack optimal (Banque + Compta + Assurance) adapte a votre profil.
          </p>
        </div>

        {/* Features */}
        <div className="flex flex-wrap justify-center gap-4 sm:gap-8 mb-12">
          {[
            {
              icon: ClipboardCheck,
              title: "Analyse personnalisée",
              desc: "Basee sur votre profil",
            },
            {
              icon: Sparkles,
              title: "Recommandations ciblees",
              desc: "Banque + Compta + Assurance",
            },
            {
              icon: Mail,
              title: "Resultats par email",
              desc: "Audit complet en PDF",
            },
          ].map((feat) => (
            <div key={feat.title} className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <feat.icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold">{feat.title}</p>
                <p className="text-xs text-muted-foreground">{feat.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Dialog */}
        <div className="flex justify-center">
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button
                size="lg"
                className="gap-2 bg-primary hover:bg-primary/90 font-semibold text-base px-10 h-14 shadow-lg shadow-primary/20"
              >
                <ClipboardCheck className="h-5 w-5" />
                Commencer mon audit gratuit
              </Button>
            </DialogTrigger>

            <DialogContent className="sm:max-w-lg p-0 overflow-hidden">
              <DialogHeader className="sr-only">
                <DialogTitle>Audit de Lancement Personnalisé</DialogTitle>
                <DialogDescription>
                  Répondez à 4 questions pour recevoir votre audit personnalisé
                </DialogDescription>
              </DialogHeader>

              <AnimatePresence mode="wait" custom={direction}>
                {!isSubmitted ? (
                  <motion.div
                    key={step}
                    custom={direction}
                    variants={slideVariants}
                    initial="enter"
                    animate="center"
                    exit="exit"
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    onKeyDown={handleKeyDown}
                  >
                    {/* Progress Bar */}
                    <div className="bg-muted px-6 pt-5 pb-3">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-medium text-muted-foreground">
                          Question {step + 1} sur {totalSteps}
                        </span>
                        <span className="text-xs font-medium text-primary">
                          {Math.round(((step + 1) / totalSteps) * 100)}%
                        </span>
                      </div>
                      <div className="h-2 bg-background rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-primary rounded-full"
                          animate={{
                            width: `${((step + 1) / totalSteps) * 100}%`,
                          }}
                          transition={{ duration: 0.3 }}
                        />
                      </div>
                    </div>

                    <div className="p-6">
                      {/* Step 0: Profile */}
                      {step === 0 && (
                        <div className="space-y-4">
                          <div className="text-center mb-6">
                            <div className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 mb-3">
                              <User className="h-7 w-7 text-primary" />
                            </div>
                            <h3 className="text-xl font-bold">
                              Quel est votre profil ?
                            </h3>
                            <p className="text-sm text-muted-foreground mt-1">
                              Cela nous aide a adapter nos recommandations
                            </p>
                          </div>
                          <RadioGroup
                            value={formData.profile}
                            onValueChange={(val) =>
                              setFormData({ ...formData, profile: val })
                            }
                            className="space-y-3"
                          >
                            {profileOptions.map((opt) => (
                              <label
                                key={opt.value}
                                className={`flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                                  formData.profile === opt.value
                                    ? "border-primary bg-primary/5"
                                    : "border-border hover:border-primary/30 hover:bg-muted/50"
                                }`}
                              >
                                <RadioGroupItem value={opt.value} />
                                <opt.icon className="h-5 w-5 text-muted-foreground" />
                                <div>
                                  <p className="text-sm font-semibold">
                                    {opt.label}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {opt.description}
                                  </p>
                                </div>
                              </label>
                            ))}
                          </RadioGroup>
                        </div>
                      )}

                      {/* Step 1: Phase */}
                      {step === 1 && (
                        <div className="space-y-4">
                          <div className="text-center mb-6">
                            <div className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 mb-3">
                              <Lightbulb className="h-7 w-7 text-primary" />
                            </div>
                            <h3 className="text-xl font-bold">
                              Ou en etes-vous dans votre projet ?
                            </h3>
                            <p className="text-sm text-muted-foreground mt-1">
                              Selectionnez la phase qui correspond le mieux
                            </p>
                          </div>
                          <RadioGroup
                            value={formData.phase}
                            onValueChange={(val) =>
                              setFormData({ ...formData, phase: val })
                            }
                            className="space-y-3"
                          >
                            {phaseOptions.map((opt) => (
                              <label
                                key={opt.value}
                                className={`flex items-start gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                                  formData.phase === opt.value
                                    ? "border-primary bg-primary/5"
                                    : "border-border hover:border-primary/30 hover:bg-muted/50"
                                }`}
                              >
                                <RadioGroupItem
                                  value={opt.value}
                                  className="mt-0.5"
                                />
                                <div>
                                  <p className="text-sm font-semibold">
                                    {opt.label}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {opt.description}
                                  </p>
                                </div>
                              </label>
                            ))}
                          </RadioGroup>
                        </div>
                      )}

                      {/* Step 2: Pain Point */}
                      {step === 2 && (
                        <div className="space-y-4">
                          <div className="text-center mb-6">
                            <div className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 mb-3">
                              <ClipboardCheck className="h-7 w-7 text-primary" />
                            </div>
                            <h3 className="text-xl font-bold">
                              Quelle est votre plus grande difficulte ?
                            </h3>
                            <p className="text-sm text-muted-foreground mt-1">
                              Nous ciblerons nos recommandations en consequence
                            </p>
                          </div>
                          <RadioGroup
                            value={formData.painPoint}
                            onValueChange={(val) =>
                              setFormData({ ...formData, painPoint: val })
                            }
                            className="space-y-3"
                          >
                            {painPointOptions.map((opt) => (
                              <label
                                key={opt.value}
                                className={`flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                                  formData.painPoint === opt.value
                                    ? "border-primary bg-primary/5"
                                    : "border-border hover:border-primary/30 hover:bg-muted/50"
                                }`}
                              >
                                <RadioGroupItem value={opt.value} />
                                <p className="text-sm font-medium">{opt.label}</p>
                              </label>
                            ))}
                          </RadioGroup>
                        </div>
                      )}

                      {/* Step 3: Contact */}
                      {step === 3 && (
                        <div className="space-y-5">
                          <div className="text-center mb-6">
                            <div className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 mb-3">
                              <Mail className="h-7 w-7 text-primary" />
                            </div>
                            <h3 className="text-xl font-bold">
                              Recevez votre audit personnalisé
                            </h3>
                            <p className="text-sm text-muted-foreground mt-1">
                              Entrez vos coordonnees pour recevoir vos
                              recommandations
                            </p>
                          </div>

                          <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="firstName">Prenom *</Label>
                                <Input
                                  id="firstName"
                                  placeholder="Jean"
                                  value={formData.firstName}
                                  onChange={(e) =>
                                    setFormData({
                                      ...formData,
                                      firstName: e.target.value,
                                    })
                                  }
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="lastName">Nom</Label>
                                <Input
                                  id="lastName"
                                  placeholder="Dupont"
                                  value={formData.lastName}
                                  onChange={(e) =>
                                    setFormData({
                                      ...formData,
                                      lastName: e.target.value,
                                    })
                                  }
                                />
                              </div>
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="email">Email *</Label>
                              <Input
                                id="email"
                                type="email"
                                placeholder="jean@exemple.com"
                                value={formData.email}
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    email: e.target.value,
                                  })
                                }
                              />
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="projectName">
                                Nom de votre projet (optionnel)
                              </Label>
                              <Input
                                id="projectName"
                                placeholder="Mon projet de..."
                                value={formData.projectName}
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    projectName: e.target.value,
                                  })
                                }
                              />
                            </div>

                            <p className="text-xs text-muted-foreground leading-relaxed">
                              En soumettant ce formulaire, vous acceptez de
                              recevoir nos recommandations personnalisées par
                              email. Vos données sont protégées et ne seront
                              jamais partagees.
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Navigation Buttons */}
                      <div className="flex justify-between mt-8 pt-4 border-t">
                        {step > 0 ? (
                          <Button
                            variant="ghost"
                            onClick={goPrev}
                            className="gap-1"
                          >
                            <ArrowLeft className="h-4 w-4" />
                            Precedent
                          </Button>
                        ) : (
                          <div />
                        )}

                        {step < totalSteps - 1 ? (
                          <Button
                            onClick={goNext}
                            disabled={!canGoNext()}
                            className="gap-1"
                          >
                            Suivant
                            <ArrowRight className="h-4 w-4" />
                          </Button>
                        ) : (
                          <Button
                            onClick={handleSubmit}
                            disabled={!canGoNext() || isSubmitting}
                            className="gap-2 bg-primary hover:bg-primary/90"
                          >
                            {isSubmitting ? (
                              <>
                                <Loader2 className="h-4 w-4 animate-spin" />
                                Analyse en cours...
                              </>
                            ) : (
                              <>
                                <Sparkles className="h-4 w-4" />
                                Recevoir mon audit
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-8 text-center"
                  >
                    <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 mb-5">
                      <CheckCircle2 className="h-10 w-10 text-primary" />
                    </div>
                    <h3 className="text-2xl font-bold mb-2">
                      Audit généré avec succès !
                    </h3>
                    <p className="text-muted-foreground mb-2">
                      Votre audit personnalisé est en cours de préparation.
                    </p>
                    <p className="text-sm text-muted-foreground mb-6">
                      Vous le recevrez a l&apos;adresse{" "}
                      <strong className="text-foreground">{formData.email}</strong>{" "}
                      dans les prochaines minutes.
                    </p>

                    <div className="bg-muted/50 rounded-xl p-4 mb-6 text-left space-y-2">
                      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        Votre profil
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        <Badge variant="secondary">
                          {profileOptions.find((p) => p.value === formData.profile)?.label}
                        </Badge>
                        <Badge variant="secondary">
                          {phaseOptions.find((p) => p.value === formData.phase)?.label}
                        </Badge>
                        <Badge variant="secondary">
                          {painPointOptions.find((p) => p.value === formData.painPoint)?.label}
                        </Badge>
                      </div>
                    </div>

                    <Button onClick={resetForm} variant="outline">
                      Fermer
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </section>
  );
}
