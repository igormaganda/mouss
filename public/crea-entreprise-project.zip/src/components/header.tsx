"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  UserCircle,
  Menu,
  Wrench,
  CreditCard,
  ClipboardCheck,
  BarChart3,
  Sparkles,
} from "lucide-react";

const navLinks = [
  { href: "/creer-mon-entreprise", label: "Créer mon entreprise", icon: Sparkles },
  { href: "/outils", label: "Outils", icon: Wrench },
  { href: "/comparatifs", label: "Comparatifs", icon: BarChart3 },
  { href: "/tarifs", label: "Tarifs", icon: CreditCard },
  { href: "/audit", label: "Audit Gratuit", icon: ClipboardCheck },
];

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-lg">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <a href="/" className="flex items-center gap-2 group">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold text-lg">
            CE
          </div>
          <div className="hidden sm:block">
            <span className="text-lg font-bold tracking-tight text-foreground">
              Créa
            </span>
            <span className="text-xs block -mt-1 text-muted-foreground">
              Entreprise
            </span>
          </div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-primary rounded-md hover:bg-primary/5"
            >
              <link.icon className="h-4 w-4" />
              {link.label}
            </a>
          ))}
        </nav>

        {/* CTA + Mobile Menu */}
        <div className="flex items-center gap-3">
          <a href="/login" className="hidden sm:flex">
            <Button className="gap-2 bg-primary hover:bg-primary/90">
              <UserCircle className="h-4 w-4" />
              Mon Compte
            </Button>
          </a>

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <nav className="flex flex-col gap-2 mt-8">
                {navLinks.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="flex items-center gap-3 px-3 py-3 text-base font-medium text-foreground rounded-lg hover:bg-primary/5 transition-colors"
                  >
                    <link.icon className="h-5 w-5 text-primary" />
                    {link.label}
                  </a>
                ))}
                <div className="pt-4 border-t mt-2">
                  <a href="/login" onClick={() => setOpen(false)}>
                    <Button className="w-full gap-2 bg-primary hover:bg-primary/90">
                      <UserCircle className="h-4 w-4" />
                      Mon Compte
                    </Button>
                  </a>
                </div>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
